# Airflow

[![hackmd-github-sync-badge](https://hackmd.io/6Hl_wlI4QTmUaae_n-l2gA/badge)](https://hackmd.io/6Hl_wlI4QTmUaae_n-l2gA)


docker [tutorial](https://airflow.apache.org/docs/apache-airflow/stable/start/docker.html)  
docker-compose official [file](https://airflow.apache.org/docs/apache-airflow/stable/docker-compose.yaml)

### Develop
* Add environment into **tags**; PRO, VENUS, CHAMP  

### Tips
* Airflow context [list](https://airflow.apache.org/docs/apache-airflow/stable/templates-ref.html)
* Upgrade [docs](https://airflow.apache.org/docs/apache-airflow/stable/installation/upgrading.html#)  
  `airflow db upgrade`  

### Test

Buils [environment](https://medium.com/ninjavan-tech/setting-up-a-complete-local-development-environment-for-airflow-docker-pycharm-and-tests-3577ddb4ca94)  
PyTest [testing](https://www.astronomer.io/events/recaps/testing-airflow-to-bulletproof-your-code/)  
* test task
    ```bash=
    # help
    airflow tasks test [dag_id] [task_id] [execution_date]
    
    airflow tasks test qtech_etl extract_games 2022-08-01T00
    
    airflow tasks test qtech_etl get_bets_by_game 2022-08-01T00 -t '{"game_code":"220"}' --map-index 0
    ```
* test dags
    ```bash=
    # help
    airflow dags test [dag_id] [execution_date]
    
    airflow dags test qtech_etl 2022-08-01T00
    ```

### Customized docker
[doc](https://airflow.apache.org/docs/docker-stack/index.html)  
* The **AIRFLOW_HOME** is set by default to `/opt/airflow`  
* The *working directory* is `/opt/airflow` by default  
* If no **AIRFLOW__DATABASE__SQL_ALCHEMY_CONN** variable is set then SQLite database is created in `${AIRFLOW_HOME}/airflow.db`  
* Route [modification](https://airflow.apache.org/docs/apache-airflow/stable/howto/run-behind-proxy.html)  
* Trigger docker [command](https://github.com/fclesio/airflow-docker-operator-with-compose)
* Enable Airflow [API](https://brocktibert.com/post/trigger-airflow-dags-via-the-rest-api/)
* Migration path [setup](https://stackoverflow.com/questions/70910208/moving-local-python-modules-to-airflow)
* Or folder structure [suggestion](https://airflow.apache.org/docs/apache-airflow/stable/modules_management.html)

### Trigger rm-sys
Use Airflow to receive message from Git-hook to trigger the system updating


