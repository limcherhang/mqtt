### Description
> 請提供**螢幕截圖**, 或詳細說明在什麼**狀況**下會發生.  
> Please provide a **screenshot**, or describe the **situation** in detail.  



### Suggestion
> 如有修改建議請提供在這.  
> Suggestion for the issue.  



---
Asign:  
/assign @  

Label:  
/label ~"bug"  
