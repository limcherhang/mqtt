import logging
import pytest

from pendulum.datetime import DateTime as pendulum_datetime
from datetime import datetime
import pendulum
from pymongo import MongoClient

from dags.tracker.crud.mongo import order

logger = logging.getLogger(__name__)


@pytest.fixture
def end_time(utc_today: pendulum_datetime) -> pendulum_datetime:
    return pendulum.datetime(
        utc_today.year,
        utc_today.month,
        utc_today.day,
        utc_today.hour,
        utc_today.minute,
        tz=utc_today.tz,
    )


def test_get_motivation_bettype_info(
    mongo_read_client: MongoClient,
    end_time: pendulum_datetime,
):
    start_time = end_time.add(minutes=-60)
    _res = order.get_motivation_bettype_info(mongo_read_client, start_time, end_time)
    logger.debug(_res)


@pytest.fixture
def interval_minute():
    return 5


def test_get_by_bettime(
    mongo_read_client: MongoClient, end_time: datetime, interval_minute
):
    collection_by_bettime = order.get_by_bettime(
        mongo_read_client, end_time, interval_minute
    )
    logger.debug(collection_by_bettime)


def test_get_by_createtime(
    mongo_read_client: MongoClient, end_time: datetime, interval_minute: int = 5
):
    collection_by_createtime = order.get_by_createtime(
        mongo_read_client, end_time, interval_minute
    )
    logger.debug(collection_by_createtime)


def test_get_specific_bettype_hedge(
    mongo_read_client: MongoClient,
    end_time: pendulum_datetime,
):
    start_time = end_time.add(minutes=-60)
    table_types = ["1", "4"]
    for table_type in table_types:
        _res = order.get_specific_bettype_hedge(
            mongo_read_client, start_time, end_time, table_type
        )
        logger.debug(_res[:10])


def test_get_motivation_order(
    mongo_read_client: MongoClient, end_time: pendulum_datetime
):
    start_time = end_time.add(minutes=-60 * 24 * 7)

    _res = order.get_motivation_order(mongo_read_client, start_time, end_time)

    logger.debug(_res)


def test_get_motivation_order_sort_by_createtime(
    mongo_read_client: MongoClient, end_time: pendulum_datetime
):
    start_time = end_time.add(minutes=-60 * 24 * 7)

    _res = order.get_motivation_order_sort_by_createtime(
        mongo_read_client, start_time, end_time
    )

    logger.debug(_res)


def test_get_player_daily_bet_win(
    mongo_read_client: MongoClient,
    end_time: pendulum_datetime,
    playerid="5a17782623552a00019d3c3a",
):
    start_time = end_time.add(minutes=-60 * 24 * 7)

    _res = order.get_player_daily_bet_win(
        mongo_read_client, start_time, end_time, playerid
    )

    logger.debug(_res)
