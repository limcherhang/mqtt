import logging
import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from mysql.connector.cursor import MySQLCursor

from dags.tracker.crud import summary

logger = logging.getLogger(__name__)


def test_get_newAB3_summary(
    mysql_master_read_cursor: MySQLCursor,
    utc_today: pendulum_datetime,
):
    check_date = pendulum.datetime(utc_today.year, utc_today.month, utc_today.day).add(
        days=-1
    )
    result = summary.get_newAB3_summary(
        mysql_master_read_cursor, check_date.format("YYYY-MM-DD")
    )
    logger.debug(result)


def test_get_lego_summary(
    mysql_master_read_cursor: MySQLCursor,
    utc_today: pendulum_datetime,
):
    check_date = pendulum.datetime(utc_today.year, utc_today.month, utc_today.day).add(
        days=-1
    )
    result = summary.get_lego_summary(
        mysql_master_read_cursor, check_date.format("YYYY-MM-DD"), "qt"
    )
    logger.debug(result)
    result = summary.get_lego_summary(
        mysql_master_read_cursor,
        check_date.format("YYYY-MM-DD"),
        "qt",
        day_opt="cumonth",
    )
    logger.debug(result)


def test_get_game_owner_summary_by_code(
    mysql_master_read_cursor: MySQLCursor,
    utc_today: pendulum_datetime,
):
    check_date = pendulum.datetime(utc_today.year, utc_today.month, utc_today.day).add(
        days=-1
    )
    result = summary.get_game_owner_summary_by_code(
        mysql_master_read_cursor,
        check_date.format("YYYY-MM-DD"),
        "CA01",
        "table",
    )
    logger.debug(result)


def test_get_daily_by_currency(
    mysql_master_read_cursor: MySQLCursor, utc_today: pendulum_datetime
):
    check_date = pendulum.datetime(utc_today.year, utc_today.month, utc_today.day).add(
        days=-1
    )
    result = summary.get_daily_by_currency(
        mysql_master_read_cursor,
        check_date.format("YYYY-MM-DD"),
        "cq9",
        "CNY",
        day_opt="premonth",
    )
    logger.debug(result)


def test_get_played_registered_user_count(
    mysql_master_read_cursor: MySQLCursor, utc_today: pendulum_datetime
):
    check_date = pendulum.datetime(utc_today.year, utc_today.month, utc_today.day).add(
        days=-1
    )
    result = summary.get_played_registered_user_count(
        mysql_master_read_cursor, check_date.format("YYYY-MM-DD"), "cq9"
    )
    logger.debug(result)


def test_get_daily_of_currencys(
    mysql_master_read_cursor: MySQLCursor, utc_today: pendulum_datetime
):
    check_date = pendulum.datetime(utc_today.year, utc_today.month, utc_today.day).add(
        days=-1
    )
    result = summary.get_daily_of_currencys(
        mysql_master_read_cursor, check_date.format("YYYY-MM-DD"), "cq9"
    )
    logger.debug(result)


def test_get_daily(mysql_master_read_cursor: MySQLCursor, utc_today: pendulum_datetime):
    check_date = pendulum.datetime(utc_today.year, utc_today.month, utc_today.day).add(
        days=-1
    )
    result = summary.get_daily(
        mysql_master_read_cursor, check_date.format("YYYY-MM-DD"), "cq9"
    )
    logger.debug(result)
