import logging
from mysql.connector.cursor import MySQLCursor

from dags.tracker.crud import agent

logger = logging.getLogger(__name__)


def test_get_news_with_high_net_win(
    mysql_master_read_cursor: MySQLCursor,
):
    _res = agent.get_info(mysql_master_read_cursor)
    logger.debug(_res[:5])
    assert _res is not None
