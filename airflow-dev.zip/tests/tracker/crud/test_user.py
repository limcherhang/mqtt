import logging
import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from mysql.connector.cursor import MySQLCursor
from pymongo import MongoClient

from dags.tracker.crud import user

logger = logging.getLogger(__name__)


def test_get_news_with_high_net_win(
    mysql_master_read_cursor: MySQLCursor,
    utc_today: pendulum_datetime,
):
    reg_after_dt = pendulum.datetime(
        utc_today.year, utc_today.month, utc_today.day
    ).add(days=-7)
    end_time = pendulum.datetime(
        utc_today.year, utc_today.month, utc_today.day, utc_today.hour
    )
    start_time = end_time.add(hours=-2)
    result = user.get_news_with_high_net_win(
        mysql_master_read_cursor,
        start_time.format("YYYY-MM-DD HH"),
        end_time.format("YYYY-MM-DD HH"),
        reg_after_dt.format("YYYY-MM-DD"),
        0,
    )
    logger.debug(result)
    result_by_game = user.get_news_with_high_net_win_n_game(
        mysql_master_read_cursor,
        start_time.format("YYYY-MM-DD HH"),
        end_time.format("YYYY-MM-DD HH"),
        reg_after_dt.format("YYYY-MM-DD"),
        0,
    )
    logger.debug(result_by_game)
