import logging
from mysql.connector.cursor import MySQLCursor

from dags.tracker.crud.mysql import game

logger = logging.getLogger(__name__)


def test_get_info(mysql_master_read_cursor: MySQLCursor):
    result = game.get_info(mysql_master_read_cursor)
    logger.debug(result)
