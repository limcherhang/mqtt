import pytest
from pytest_mock import MockerFixture

import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
import logging
from mysql.connector.cursor import MySQLCursor

from tests.utils import utils
from dags.tracker.crud import summary

logger = logging.getLogger(__name__)

_CFG = {
    "LEGO_TEAMPLUS_CHAT": [832],
    "LEGO_BRANDS": {"QTech": "qt"},
}


@pytest.fixture
def data_interval_start(utc_today: pendulum_datetime) -> pendulum_datetime:
    utc_yesterday = utc_today.add(days=-1)
    return pendulum.datetime(
        utc_yesterday.year,
        utc_yesterday.month,
        utc_yesterday.day,
        0,
        10,
        tz=utc_yesterday.tz,
    )


def test_add_and_update_to_api(
    mocker: MockerFixture,
    data_interval_start: pendulum_datetime,
    mysql_master_read_cursor: MySQLCursor,
):
    teamplus_message = mocker.Mock(side_effect=utils.side_effect_teamplus_message)
    DAAPIHook = mocker.MagicMock(return_value=utils.MockDAAPIHook)
    from dags import schemas

    check_date_str = data_interval_start.format("YYYY-MM-DD")
    brand = "Lego"
    teamplus_chats = _CFG.get("LEGO_TEAMPLUS_CHAT", [832])
    cursor = mysql_master_read_cursor

    hook = DAAPIHook()
    for project_name, project in _CFG.get("LEGO_BRANDS", {}).items():
        bet_infos = summary.get_lego_summary(cursor, check_date_str, project)
        player_count = 0
        bets = 0
        rounds = 0
        net_wins = 0
        logger.info(bet_infos)
        if bet_infos:
            bets, net_wins, rounds, player_count = bet_infos

        msg = f"日期: {check_date_str} \n"
        msg += f"品牌: {brand} \n"
        msg += f"專案: {project_name} \n"
        msg += f"總碼量(CNY): {bets:,.0f} \n"
        msg += f"不重複人數: {player_count:,d} \n"

        teamplus_message(teamplus_chats, msg)
        performance_in = schemas.SalesSpecifyProject.parse_obj(
            dict(
                date=check_date_str,
                brand="lego",
                currency="ALL",
                project=project,
                span="day",
                bet=bets,
                net_win=net_wins,
                player=player_count,
                rounds=rounds,
            )
        )
        logger.debug(performance_in)
        hook.add_specify_project(performance_in.json(), check_response=False)
        if bets == 0:
            continue

        bet_infos = summary.get_lego_summary(
            cursor, check_date_str, project, day_opt="cumonth"
        )
        bets = 0
        if bet_infos:
            bets, net_wins, rounds, player_count = bet_infos
        if bets == 0:
            continue

        key = schemas.SalesSpecifyProjectKey.parse_obj(
            dict(
                date=check_date_str[:8] + "01",
                brand="lego",
                currency="ALL",
                project=project,
                span="month",
            )
        )
        info = hook.get_specify_project(key.dict(), check_response=False)
        performance_in = {
            "bet": bets,
            "net_win": net_wins,
            "player": player_count,
            "rounds": rounds,
        }
        if 299 > info.status_code >= 200:
            hook.update_specify_project(
                key.json(),
                schemas.SalesSpecifyProjectUpdate.parse_obj(performance_in).json(
                    exclude_unset=True, exclude_none=True
                ),
                check_response=False,
            )
        else:
            performance_in.update(key.dict())
            hook.add_specify_project(
                schemas.SalesSpecifyProject.parse_obj(performance_in).json(),
                check_response=False,
            )

    logger.info(f"DA-API call-count: {DAAPIHook.call_count}")
