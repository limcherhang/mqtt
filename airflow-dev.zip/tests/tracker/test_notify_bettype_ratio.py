import pytest
from pytest_mock import MockerFixture

import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
import logging
from pymongo import MongoClient

from tests.utils import utils
from tests.utils.define import TABLETYPE_INFO
from dags.tracker.crud.mongo import order

logger = logging.getLogger(__name__)

_CFG = {
    "BETTYPE_RATIO": {"TG_CHAT": [-1001899761231], "CHECK_INTERVAL": 144, "ENV": "CQ9"}
}


@pytest.fixture
def data_interval_end(utc_today: pendulum_datetime) -> pendulum_datetime:
    return pendulum.datetime(
        utc_today.year,
        utc_today.month,
        utc_today.day,
        utc_today.hour,
        15,
        tz=utc_today.tz,
    )


def test_notify(
    mocker: MockerFixture,
    data_interval_end: pendulum_datetime,
    mongo_read_client: MongoClient,
):
    telegram_message = mocker.Mock(side_effect=utils.side_effect_telegram_message)

    _BT_CFG = _CFG.get("BETTYPE_RATIO", {})
    check_interval = _BT_CFG.get("CHECK_INTERVAL", 1)
    infos = order.get_motivation_bettype_info(
        mongo_read_client,
        data_interval_end.add(hours=-1 * check_interval),
        data_interval_end,
    )
    counter = {}
    for info in infos:
        _tabletype = info.get("tabletype")
        _tableid = info.get("tableid")
        _bettypes = info.get("bettype", [])
        table_counter = counter.setdefault(_tableid, {"tabletype": _tabletype})
        for _bettype in _bettypes:
            if _bettype in table_counter:
                table_counter[_bettype] += 1
            else:
                table_counter[_bettype] = 1

    ENV = _BT_CFG.get("ENV", "")
    msg = ""
    logger.debug(ENV)
    if ENV and counter:
        msg = f"環境: {ENV}\n"
    for table, info in sorted(counter.items(), key=lambda k: k[0]):
        tabletype = info.pop("tabletype")
        the_type_info = TABLETYPE_INFO[tabletype]
        tabletype_name = the_type_info["NAME"]
        msg += f"{tabletype_name}桌號: {table} 場次比例<"
        total = sum(info.values())
        for _bettype, _count in sorted(info.items(), key=lambda k: int(k[0])):
            msg += (
                f"{the_type_info['BETTYPE'][_bettype]}: {(_count / total) * 100 :.2f}% "
            )
        msg += ">\n"

    if msg:
        telegram_message([1], msg)
