import pytest

import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
import logging
from mysql.connector.cursor import MySQLCursor
from datetime import datetime

from dags.tracker.crud import summary
from dags.utils.tools import get_excel_timestamp

logger = logging.getLogger(__name__)


@pytest.fixture
def data_interval_start(utc_today: pendulum_datetime) -> pendulum_datetime:
    return pendulum.datetime(
        utc_today.year,
        utc_today.month,
        utc_today.day,
        10,
        tz=utc_today.tz,
    ).add(days=-1)


def test_get_summary(
    OauthGSheetHook,
    data_interval_start: pendulum_datetime,
    mysql_master_read_cursor: MySQLCursor,
):
    check_date_str = data_interval_start.format("YYYY-MM-DD")

    _summary = summary.get_newAB3_summary(mysql_master_read_cursor, check_date_str)

    gsheet_hook = OauthGSheetHook(gcp_conn_id="google_report")
    range_ = "sheet1"
    values_ = [
        [
            get_excel_timestamp(datetime.strptime(check_date_str, "%Y-%m-%d")),
            "AB3",
            round(float(_summary[0]), 2),
            round(float(_summary[1]), 0),
            round(float(_summary[2]), 0),
            round(float(_summary[3]), 2),
        ]
    ]
    gsheet_hook.append_values(
        spreadsheet_id="1O_LiYXWOwm5PdkLB_P_LtGYF_imi-alnBvDyx3Y6fW0",
        range_=range_,
        values=values_,
    )
