import pytest
from pytest_mock import MockerFixture

import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
import logging
from mysql.connector.cursor import MySQLCursor

from tests.utils import utils
from dags.tracker.crud import user

logger = logging.getLogger(__name__)

_CFG = {
    "NEW_PLAYER": {
        "HIGH_TOTAL_NET_WIN": [832],
        "HIGH_GAME_NET_WIN": [832],
        "REGISTER_FROM_HOURS": 720,
        "TOTAL_NET_WIN_THRESHOLD": 100_000,
        "GAME_NET_WIN_THRESHOLD": 100_000,
    }
}


@pytest.fixture
def data_interval_end(utc_today: pendulum_datetime) -> pendulum_datetime:
    return pendulum.datetime(
        utc_today.year,
        utc_today.month,
        utc_today.day,
        utc_today.hour,
        50,
        tz=utc_today.tz,
    )


def test_alert_high_net_win(
    mocker: MockerFixture,
    data_interval_end: pendulum_datetime,
    mysql_master_read_cursor: MySQLCursor,
):
    _NEWS_CFG = _CFG.get("NEW_PLAYER", {})
    reg_from_hour = _NEWS_CFG.get("REGISTER_FROM_HOURS", 720)
    teamplus_message = mocker.Mock(side_effect=utils.side_effect_teamplus_message)
    check_to_time_str = data_interval_end.format("YYYY-MM-DD HH")
    check_from_time_str = data_interval_end.add(hours=-1).format("YYYY-MM-DD HH")
    reg_from_time_str = data_interval_end.add(hours=-1 * reg_from_hour).format(
        "YYYY-MM-DD HH"
    )
    logger.info(f"Track range from {check_from_time_str} to {check_to_time_str}")

    total_net_win_threshold = _NEWS_CFG.get("TOTAL_NET_WIN_THRESHOLD", 100_000)
    infos = user.get_news_with_high_net_win(
        mysql_master_read_cursor,
        check_from_time_str,
        check_to_time_str,
        reg_from_time_str,
        total_net_win_threshold,
    )

    high_total_net_win_chat = _NEWS_CFG.get("HIGH_TOTAL_NET_WIN", [832])
    if infos:
        for (_owner, _parent, _user, _userid, _bets, _rounds, _net_wins) in infos:
            msg = "    HIGH GAME NET WIN!\n"
            msg += f"owner: {_owner}\n"
            msg += f"prent: {_parent}\n"
            msg += f"player: {_user}\n"
            msg += f"playerSSID: {_userid}\n"
            msg += f"bets: {_bets:,.2f}\n"
            msg += f"rounds: {_rounds:,}\n"
            msg += f"netWins: {_net_wins:,.2f}\n"
            teamplus_message(high_total_net_win_chat, msg)
    else:
        msg = "There is not any high TOTAL net-win players!"
        teamplus_message(high_total_net_win_chat, msg)

    game_net_win_threshold = _NEWS_CFG.get("GAME_NET_WIN_THRESHOLD", 50_000)
    infos = user.get_news_with_high_net_win_n_game(
        mysql_master_read_cursor,
        check_from_time_str,
        check_to_time_str,
        reg_from_time_str,
        game_net_win_threshold,
    )

    high_game_net_win_chat = _NEWS_CFG.get("HIGH_GANE_NET_WIN", [832])
    if infos:
        for (
            _owner,
            _parent,
            _user,
            _userid,
            _game,
            _bets,
            _rounds,
            _net_wins,
        ) in infos:
            msg = "    HIGH GAME NET WIN!\n"
            msg += f"owner: {_owner}\n"
            msg += f"prent: {_parent}\n"
            msg += f"player: {_user}\n"
            msg += f"playerSSID: {_userid}\n"
            msg += f"game: {_game}\n"
            msg += f"bets: {_bets:,.2f}\n"
            msg += f"rounds: {_rounds:,}\n"
            msg += f"netWins: {_net_wins:,.2f}\n"
            teamplus_message(high_total_net_win_chat, msg)
    else:
        msg = "There is not any high GANE net-win players!"
        teamplus_message(high_game_net_win_chat, msg)
