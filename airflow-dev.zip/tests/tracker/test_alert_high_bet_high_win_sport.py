import logging
import pytest
from pytest_mock import MockerFixture

from datetime import datetime, timedelta
import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from mysql.connector.cursor import MySQLCursor
from pymongo import MongoClient

from tests.utils import utils
from dags.tracker.crud import agent
from dags.tracker.crud.mysql import game
from dags.tracker.crud.mongo import order

logger = logging.getLogger(__name__)

_CFG = {
    "ALERT_HIGHBET_N_HIGHWIN": {
        "HIGHBET_CHAT": [3708],
        "HIGHWIN_CHAT": [3708],
        "HIGHBET_THRESHOLD": 10000,
        "MULTIPLE_THRESHOLD": 5,
    }
}


@pytest.fixture
def data_interval_end(utc_today: pendulum_datetime) -> pendulum_datetime:
    return pendulum.datetime(
        utc_today.year,
        utc_today.month,
        utc_today.day,
        utc_today.hour,
        50,
        tz=utc_today.tz,
    )


@pytest.fixture
def data_interval():
    return 5


def test_alert_high_bet_high_win(
    mocker: MockerFixture,
    mysql_master_read_cursor: MySQLCursor,
    mongo_read_client: MongoClient,
    data_interval_end: pendulum_datetime,
    data_interval: int,
):
    HIGHBET_THRESHOLD = _CFG.get("HIGHBET_THRESHOLD", 10000)
    MULTIPLE_THRESHOLD = _CFG.get("MULTIPLE_THRESHOLD", 5)
    HIGHBET_CHAT = _CFG.get("HIGHBET_CHAT", [3708])
    HIGHWIN_CHAT = _CFG.get("HIGHWIN_CHAT", [3708])
    teamplus_message = mocker.Mock(side_effect=utils.side_effect_teamplus_message)

    insert_date = datetime.fromtimestamp(
        pendulum.datetime(
            data_interval_end.year,
            data_interval_end.month,
            data_interval_end.day,
            data_interval_end.hour,
            data_interval_end.minute,
            tz=data_interval_end.tz,
        ).timestamp(),
        tz=pendulum.tz.UTC,
    )

    logger.info(
        f"Alert tracking from {insert_date-timedelta(minutes=data_interval)} to {insert_date}"
    )

    parent_list = {}
    for (ssid, _parent, _owner, _rate) in agent.get_info(mysql_master_read_cursor):
        parent_list[ssid] = {"parent": _parent, "owner": _owner, "rate": float(_rate)}
    game_info = {}
    for (game_name_en, gamecode) in game.get_info(mysql_master_read_cursor):
        game_info[gamecode] = game_name_en

    collection_by_bettime = order.get_by_bettime(
        mongo_read_client, insert_date, data_interval
    )

    for res in collection_by_bettime:
        parentid = res.get("parentid")
        gamecode = res.get("gamecode")
        rate = parent_list[parentid].get("rate")
        if res["bets"] / rate > HIGHBET_THRESHOLD and parent_list.get(parentid):
            msg = f"type : bet >= {HIGHBET_THRESHOLD:,}\n"
            msg += f"owner : {parent_list[parentid].get('owner')}\n"
            msg += f"parent : {parent_list[parentid].get('parent')}\n"
            msg += f"account : {res['account']}\n"
            msg += f"gametype : {res['gametype']}\n"
            msg += f"genre : {res.get('genre')}\n"
            msg += f"game : {game_info.get(gamecode)}\n"
            msg += f"roundid : {res.get('roundid')}\n"
            msg += f"bets : {res.get('bets', 0)/rate:,.2f}\n"
            msg += f"wins : {res.get('wins', 0)/rate:,.2f}\n"
            msg += f"bettime : {res.get('bettime')}"

            teamplus_message(HIGHBET_CHAT, msg)

    collection_by_createtime = order.get_by_createtime(
        mongo_read_client, insert_date, data_interval
    )

    for res in collection_by_createtime:
        parentid = res.get("parentid")
        gamecode = res.get("gamecode")
        rate = parent_list[parentid].get("rate")
        if res["wins"] / res["bets"] >= MULTIPLE_THRESHOLD and parent_list.get(
            parentid
        ):
            msg = f"type : win >= bet * {MULTIPLE_THRESHOLD}\n"
            msg += f"owner : {parent_list[parentid].get('owner')}\n"
            msg += f"parent : {parent_list[parentid].get('parent')}\n"
            msg += f"account : {res.get('account')}\n"
            msg += f"gametype : {res.get('gametype')}\n"
            msg += f"genre : {res.get('genre')}\n"
            msg += f"game : {game_info.get(gamecode)}\n"
            msg += f"roundid : {res.get('roundid')}\n"
            msg += f"bets : {res.get('bets', 0)/rate:,.2f}\n"
            msg += f"wins : {res.get('wins', 0)/rate:,.2f}\n"
            msg += f"createtime : {res.get('createtime')}"

            teamplus_message(HIGHWIN_CHAT, msg)
