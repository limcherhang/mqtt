import logging
import pytest
from pytest_mock import MockerFixture

import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from pendulum.tz.timezone import Timezone
from mysql.connector.cursor import MySQLCursor
from pymongo import MongoClient

from tests.utils import utils
from tracker.crud import agent
from tracker.crud.mongo import order

logger = logging.getLogger(__name__)

_CFG = {
    "ALERT_HIGHBET_N_HIGHWIN_MOTIVATION": {
        "TELEGRAM_CHAT": [-709742679],
        "HIGHBET_THRESHOLD": 10,
        "MULTIPLE_THRESHOLD": 2,
    }
}


@pytest.fixture
def data_interval_end(utc_today: pendulum_datetime) -> pendulum_datetime:
    return pendulum.datetime(
        utc_today.year,
        utc_today.month,
        utc_today.day,
        utc_today.hour,
        50,
        tz=utc_today.tz,
    )


@pytest.fixture
def data_interval():
    return 60 * 24 * 7


def test_alert_high_bet_n_high_win_motivation(
    mocker: MockerFixture,
    mysql_master_read_cursor: MySQLCursor,
    mongo_read_client: MongoClient,
    data_interval_end: pendulum_datetime,
    data_interval: int,
):
    _NEW_CFG = _CFG.get("ALERT_HIGHBET_N_HIGHWIN_MOTIVATION", {})
    HIGHBET_THRESHOLD = _NEW_CFG.get("HIGHBET_THRESHOLD")
    MULTIPLE_THRESHOLD = _NEW_CFG.get("MULTIPLE_THRESHOLD")
    TELEGRAM_CHAT = _NEW_CFG.get("TELEGRAM_CHAT")
    telegram_message = mocker.Mock(side_effect=utils.side_effect_telegram_message)

    end_time = data_interval_end

    start_time = end_time.add(minutes=-data_interval)
    if end_time.hour < 16:
        start_time_cal_daily_win = end_time.add(
            hours=-end_time.hour - 8, minutes=-end_time.minute
        )
    else:
        start_time_cal_daily_win = pendulum.datetime(
            year=end_time.year, month=end_time.month, day=end_time.day, hour=16
        )

    logger.info(f"Alert tracking from {start_time} to {end_time}")

    parent_list = {}
    for (ssid, _parent, _owner, _) in agent.get_info(mysql_master_read_cursor):
        parent_list[ssid] = {"parent": _parent, "owner": _owner}

    infos = order.get_motivation_order(mongo_read_client, start_time, end_time)

    logger.info(f"infos:{infos}")

    for info in infos:
        parentid = info.get("parentid")
        bets = info["bets"]
        wins = info["wins"]
        account = info.get("account")
        playerid = info.get("playerid")
        if (
            bets >= HIGHBET_THRESHOLD
            and wins > bets * MULTIPLE_THRESHOLD
            and parent_list.get(parentid)
        ):
            msg = f"type : bets >= {HIGHBET_THRESHOLD} & wins > bets * {MULTIPLE_THRESHOLD} :\n"
            msg += f"owner : {parent_list[parentid].get('owner')}\n"
            msg += f"parent : {parent_list[parentid].get('parent')}\n"
            msg += f"account : {account}\n"
            msg += f"tableid : {info['tableid']}\n"
            msg += f"roundid : {info['roundid']}\n"
            msg += f"currency : {info['currency']}\n"

            daily_order = order.get_player_daily_bet_win(
                mongo_read_client, start_time_cal_daily_win, end_time, playerid
            )
            msg += f"總投注額 : {sum(value.get('bets') for value in daily_order):,.2f}\n"
            msg += f"總輸贏 : {sum(value.get('wins') for value in daily_order):,.2f}\n"
            msg += f"玩家損益金額 :{sum(value.get('wins') for value in daily_order):,.2f}"

            telegram_message(TELEGRAM_CHAT, msg)
