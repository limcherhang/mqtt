import logging
import pytest

import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from pymongo import MongoClient

from dags.dictator.crud.mongo import float_rtp

logger = logging.getLogger(__name__)


@pytest.fixture
def end_time(utc_today: pendulum_datetime) -> pendulum_datetime:
    return pendulum.datetime(
        utc_today.year,
        utc_today.month,
        utc_today.day,
        utc_today.hour,
        utc_today.minute,
        tz=utc_today.tz,
    )


def test_get_specific_bettype_hedge(
    mongo_read_client: MongoClient,
    end_time: pendulum_datetime,
):
    start_time = end_time.add(years=-1)
    _res = float_rtp.get_records(mongo_read_client, start_time, end_time)
    logger.debug(_res[:10])
