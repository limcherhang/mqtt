import logging
from mysql.connector.cursor import MySQLCursor

from dags.dictator.crud import user

logger = logging.getLogger(__name__)


def test_get_info_by_ssid(
    mysql_master_read_cursor: MySQLCursor,
):
    user_ssid = "597f456d8dfc0f0001dcd3f7"
    _res = user.get_info_by_ssid(mysql_master_read_cursor, user_ssid)
    logger.debug(_res)
    assert _res["ssid"] == user_ssid
