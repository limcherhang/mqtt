import pytest
from pytest_mock import MockerFixture

import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
import logging
from mysql.connector.cursor import MySQLCursor
from pymongo import MongoClient
from itertools import groupby

from dags.dictator.crud.mongo import float_rtp
from dags.dictator.crud import rtp_record
from dags.dictator.crud import user

logger = logging.getLogger(__name__)


@pytest.fixture
def data_interval_end(utc_today: pendulum_datetime) -> pendulum_datetime:
    return pendulum.datetime(
        utc_today.year,
        utc_today.month,
        utc_today.day,
        utc_today.hour,
        utc_today.minute,
        tz=utc_today.tz,
    )


@pytest.fixture
def data_interval_start(utc_today: pendulum_datetime) -> pendulum_datetime:
    return pendulum.datetime(
        utc_today.year,
        utc_today.month,
        utc_today.day,
        utc_today.hour,
        utc_today.minute,
        tz=utc_today.tz,
    ).add(years=-1)


def test_alert(
    mocker: MockerFixture,
    mysql_master_write_cursor: MySQLCursor,
    mongo_read_client: MongoClient,
    data_interval_start: pendulum_datetime,
    data_interval_end: pendulum_datetime,
):
    def side_effect_rtp_record_insert_with_update(*args, **kwargs):
        logger.info(f"rtp_record.insert_with_update args: {args}; kwargs: {kwargs}")

    rtp_record.insert_with_update = mocker.Mock(
        side_effect=side_effect_rtp_record_insert_with_update,
    )
    new_records = float_rtp.get_records(
        mongo_read_client, data_interval_start, data_interval_end
    )
    logger.debug(new_records[:10])

    if not new_records:
        return

    key_fn = lambda value: value["playerid"]
    for player_ssid, _records in groupby(sorted(new_records, key=key_fn), key=key_fn):
        user_info = user.get_info_by_ssid(mysql_master_write_cursor, player_ssid)

        if user_info is None:
            logger.error(f"Player {player_ssid} FAILED to find information!")
            continue

        logger.debug(user_info)
        record1st = list(_records)[0]
        create_time = record1st["created_at"]
        update_time = record1st["updated_at"]

        if float(record1st["rtps"]) >= 100:
            insert_value = (
                user_info["oid"],
                user_info["pid"],
                user_info["id"],
                user_info["account"],
                float(record1st["rtps"]),
                create_time.strftime("%Y-%m-%d %H-%M-%S"),
                update_time.strftime("%Y-%m-%d %H-%M-%S"),
                "updated",
            )
        else:
            insert_value = (
                user_info["oid"],
                user_info["pid"],
                user_info["id"],
                user_info["account"],
                float(record1st["rtps"]),
                create_time.strftime("%Y-%m-%d %H-%M-%S"),
                update_time.strftime("%Y-%m-%d %H-%M-%S"),
                None,
            )

        rtp_record.insert_with_update(mysql_master_write_cursor, insert_value)
    logger.info("Finish transferring RTP records!")
