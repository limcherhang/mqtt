import logging
import pytest

import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from pymongo import MongoClient

from dags.report.crud.mongo import order

logger = logging.getLogger(__name__)


@pytest.fixture
def check_to_time(utc_today: pendulum_datetime) -> pendulum_datetime:
    return pendulum.datetime(
        utc_today.year, utc_today.month, utc_today.day, utc_today.hour, tz=utc_today.tz
    )


def test_get_interval_orders_4report(
    mongo_read_client: MongoClient,
    check_to_time: pendulum_datetime,
):
    test_parentid = "598d70548235480001d97be8"  # id = 161
    orders = order.get_interval_orders_4report(
        mongo_read_client, check_to_time.add(hours=-24), check_to_time, test_parentid
    )
    lotto_orders = order.get_interval_orders_4report(
        mongo_read_client,
        check_to_time.add(hours=-24),
        check_to_time,
        test_parentid,
        is_lotto=True,
    )
    logger.debug(orders[:10])
    logger.debug(lotto_orders[:10])
    assert orders is not None


def test_get_interval_unique_parents(
    mongo_read_client: MongoClient,
    check_to_time: pendulum_datetime,
):
    parents = order.get_interval_unique_parents(
        mongo_read_client, check_to_time.add(hours=-1), check_to_time
    )
    lotto_parents = order.get_interval_unique_parents(
        mongo_read_client, check_to_time.add(hours=-1), check_to_time, is_lotto=True
    )
    logger.debug(set(parents).union(set(lotto_parents)))
    createtime_parents = order.get_interval_unique_parents(
        mongo_read_client,
        check_to_time.add(hours=-1),
        check_to_time,
        use_createtime=True,
    )
    logger.debug(createtime_parents)
    assert parents is not None
    assert parents == createtime_parents
