import logging
import pytest

import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from mysql.connector.cursor import MySQLCursor

from dags.report.crud.mysql import parent

logger = logging.getLogger(__name__)


@pytest.fixture
def check_to_time(utc_today: pendulum_datetime) -> pendulum_datetime:
    return pendulum.datetime(
        utc_today.year, utc_today.month, utc_today.day, utc_today.hour, tz=utc_today.tz
    )


def test_get_no_test_parents(mysql_master_read_cursor: MySQLCursor):
    parents = parent.get_not_test_parents(mysql_master_read_cursor)
    logger.debug(parents[:3])
    assert parents is not []
