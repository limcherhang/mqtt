import logging
import pytest

import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from mysql.connector.cursor import MySQLCursor
from pymongo import MongoClient

from dags.report.crud.mongo import order
from dags.report.crud.mysql import parent

logger = logging.getLogger(__name__)


@pytest.fixture
def airflow_data_interval_start(utc_today: pendulum_datetime) -> pendulum_datetime:
    return pendulum.datetime(
        utc_today.year, utc_today.month, utc_today.day, utc_today.hour, tz=utc_today.tz
    ).add(hours=-1)


def test_collect_playtime_n_round(
    mongo_read_client: MongoClient,
    airflow_data_interval_start: pendulum_datetime,
    mysql_master_read_cursor: MySQLCursor,
):
    all_parents = parent.get_not_test_parents(mysql_master_read_cursor)
    _unique_playing_parents = order.get_interval_unique_parents(
        mongo_read_client,
        airflow_data_interval_start,
        airflow_data_interval_start.add(hours=1),
    )
    _unique_lotto_playing_parents = order.get_interval_unique_parents(
        mongo_read_client,
        airflow_data_interval_start,
        airflow_data_interval_start.add(hours=1),
        is_lotto=True,
    )
    unique_playing_parents = set(_unique_playing_parents).union(
        set(_unique_lotto_playing_parents)
    )
    query_parents = unique_playing_parents.intersection(set(all_parents))
    logger.info(
        f"Start collecting from {len(query_parents)} parents on {airflow_data_interval_start}."
    )
