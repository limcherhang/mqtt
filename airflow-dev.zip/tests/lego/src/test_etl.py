import logging
from mysql.connector.cursor import MySQLCursor
import pendulum
from pytest_mock import MockerFixture
from mysql.connector.cursor import MySQLCursor
import pytest

from dags.lego.src import etl

logger = logging.getLogger(__name__)


@pytest.mark.skip("Not ready")
def test_transform_docs2summary(
    mysql_master_write_cursor: MySQLCursor, mocker: MockerFixture
):
    _datetime = pendulum.now("UTC")
    docs = [
        {
            "round": "test0",
            "id": "pytestuser",
            "gid": 0,
            "currency": "CNY",
            "gameToken": "pytesttoken",
            "datetime": _datetime.format("YYYY-MM-DD HH:mm:ss"),
            "amount": 0,
            "win_amount": 0,
        }
    ]

    def side_effect_show_params(*args, **kwargs):
        logger.info(f"Args: {args}; Kwargs: {kwargs}")

    mocker.patch.object(MySQLCursor, "execute", side_effect=side_effect_show_params)
    mocker.patch.object(MySQLCursor, "fetchone", return_value=None)

    etl.transform_docs2summary(docs, mysql_master_write_cursor, _datetime)
