import pytest
from pytest_mock import MockerFixture

import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
import logging
from mysql.connector.cursor import MySQLCursor
from pymongo import MongoClient

from dags.analysis.crud.bet_win_statistics import (
    insert_bet_distribution,
    insert_win_multiple_stats,
)
from dags.analysis.crud.mongo import gamedetail
from dags.analysis.crud import game, agent

logger = logging.getLogger(__name__)


def side_effect_insert(*_, **kwargs):
    logger.info(
        f"Insert total {len(kwargs.get('values', []))} with values(top10): {kwargs.get('values', [])[:10]}"
    )


@pytest.fixture
def data_interval_end(utc_today: pendulum_datetime) -> pendulum_datetime:
    return pendulum.datetime(
        utc_today.year,
        utc_today.month,
        utc_today.day,
        tz=utc_today.tz,
    )


def test_win_mutiple_stats(
    mocker: MockerFixture,
    mongo_read_client: MongoClient,
    mysql_master_write_cursor: MySQLCursor,
    mysql_master_read_cursor: MySQLCursor,
    data_interval_end: pendulum_datetime,
):
    """
    Insert grouped win-multiple-stats.
    """
    insert_win_multiple_stats = mocker.Mock(side_effect=side_effect_insert)

    to_time = data_interval_end
    from_time = to_time.add(days=-1)
    # startDate, ownerID, parentID, gameCode, mulRange, rounds, bets, wins
    win_stats = gamedetail.get_win_multiple_stat(mongo_read_client, from_time, to_time)

    if not win_stats:
        logger.error("Get Nothing from win multiple stats.")

    gid_finder = game.code2id(mysql_master_read_cursor)
    pid_finder = agent.ssid2id(mysql_master_read_cursor)
    logger.info(f"Win mutiple stats amount:{len(win_stats)}.")

    values = list()
    for win_stat in win_stats:
        # date, oid, pid, gid, mulRange, rounds, bets, wins
        values.append(
            (
                win_stat.get("startDate"),
                pid_finder.get(win_stat.get("ownerID"), ""),
                pid_finder.get(win_stat.get("parentID"), ""),
                gid_finder.get(str(win_stat.get("gameCode", "0")), 0),
                win_stat.get("mulRange"),
                win_stat.get("playerCount"),
                win_stat.get("rounds"),
                win_stat.get("bets"),
                win_stat.get("wins"),
            )
        )
    insert_win_multiple_stats(mysql_master_write_cursor, values=values)


def test_bet_distribution(
    mocker: MockerFixture,
    mongo_read_client: MongoClient,
    mysql_master_write_cursor: MySQLCursor,
    mysql_master_read_cursor: MySQLCursor,
    data_interval_end: pendulum_datetime,
):
    """
    Insert grouped bet-distribution.
    """
    insert_bet_distribution = mocker.Mock(side_effect=side_effect_insert)

    to_time = data_interval_end
    from_time = to_time.add(days=-1)
    # startDate, ownerID, parentID, gameCode, bet, rounds, bets, wins
    bet_distris = gamedetail.get_bet_distribution(mongo_read_client, from_time, to_time)

    if not bet_distris:
        logger.error("Get Nothing from bet distribution.")

    gid_finder = game.code2id(mysql_master_read_cursor)
    pid_finder = agent.ssid2id(mysql_master_read_cursor)
    logger.info(f"Bet distribution amount:{len(bet_distris)}.")

    values = list()
    for bet_distri in bet_distris:
        # date, oid, pid, gid, bet, rounds, bets, wins
        values.append(
            (
                bet_distri.get("startDate"),
                pid_finder.get(bet_distri.get("ownerID"), ""),
                pid_finder.get(bet_distri.get("parentID"), ""),
                gid_finder.get(str(bet_distri.get("gameCode", "0")), 0),
                bet_distri.get("bet"),
                bet_distri.get("rounds"),
                bet_distri.get("bets"),
                bet_distri.get("wins"),
            )
        )
    insert_bet_distribution(mysql_master_write_cursor, values=values)
