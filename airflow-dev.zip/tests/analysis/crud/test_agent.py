import logging
from mysql.connector.cursor import MySQLCursor

from dags.analysis.crud import agent

logger = logging.getLogger(__name__)


def test_ssid2id(
    mysql_master_read_cursor: MySQLCursor,
):
    pid_finder = agent.ssid2id(mysql_master_read_cursor)
    _pid = pid_finder.get("597eaf501895ab000159ced2")
    assert pid_finder is not None
    assert _pid == 132
