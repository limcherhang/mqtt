import logging
from mysql.connector.cursor import MySQLCursor
from pendulum.datetime import DateTime as pendulum_datetime

from dags.analysis.crud import grade_resources

logger = logging.getLogger(__name__)


def test_get_owner_info(
    mysql_master_read_cursor: MySQLCursor,
    utc_today: pendulum_datetime,
):
    to_time = utc_today.format("YYYY-MM-DD")
    from_time = utc_today.add(days=-7).format("YYYY-MM-DD")

    _res = grade_resources.get_owner_info(mysql_master_read_cursor, from_time, to_time)
    logger.debug(_res)
