import logging
from mysql.connector.cursor import MySQLCursor

from dags.analysis.crud import game

logger = logging.getLogger(__name__)


def test_code2id(
    mysql_master_read_cursor: MySQLCursor,
):
    gid_finder = game.code2id(mysql_master_read_cursor)
    _gid = gid_finder.get("1", 0)
    assert gid_finder is not None
    assert _gid == 268


def test_get_online_gid(
    mysql_master_read_cursor: MySQLCursor,
):
    _res = game.get_online_gid(mysql_master_read_cursor)
    logger.debug(_res)
    assert _res
