import logging
from mysql.connector.cursor import MySQLCursor
from pendulum.datetime import DateTime as pendulum_datetime

from dags.analysis.crud import summary, game

logger = logging.getLogger(__name__)


def test_get_vip_info_with_games(
    mysql_master_read_cursor: MySQLCursor,
    utc_today: pendulum_datetime,
):
    to_time = utc_today.format("YYYY-MM-DD")
    from_time = utc_today.add(days=-7).format("YYYY-MM-DD")
    gids = game.get_online_gid(mysql_master_read_cursor)
    _res = summary.get_vip_info_with_games(
        mysql_master_read_cursor,
        from_time,
        to_time,
        0,
        "CNY",
        [str(gid) for gid in gids],
    )
    logger.debug(_res[:10])


def test_get_player_bet_by_game(
    mysql_master_read_cursor: MySQLCursor,
    utc_today: pendulum_datetime,
):
    to_time = utc_today.format("YYYY-MM-DD")
    from_time = utc_today.add(days=-7).format("YYYY-MM-DD")
    gids = game.get_online_gid(mysql_master_read_cursor)
    _dur_res = summary.get_duration_n_play_times_with_games(
        mysql_master_read_cursor, from_time, to_time, "CNY", [str(gid) for gid in gids]
    )
    for (_, gid, uid, _, _) in _dur_res[:5]:
        _res = summary.get_users_bet_with_games(
            mysql_master_read_cursor, from_time, to_time, [str(uid)], gid
        )
        logger.debug(_res)


def test_get_duration_n_play_times_with_games(
    mysql_master_read_cursor: MySQLCursor,
    utc_today: pendulum_datetime,
):
    to_time = utc_today.format("YYYY-MM-DD")
    from_time = utc_today.add(days=-7).format("YYYY-MM-DD")
    gids = game.get_online_gid(mysql_master_read_cursor)
    _res = summary.get_duration_n_play_times_with_games(
        mysql_master_read_cursor, from_time, to_time, "CNY", [str(gid) for gid in gids]
    )
    logger.debug(_res[:10])


def test_get_with_games(
    mysql_master_read_cursor: MySQLCursor,
    utc_today: pendulum_datetime,
):
    to_time = utc_today.format("YYYY-MM-DD")
    from_time = utc_today.add(days=-7).format("YYYY-MM-DD")
    gids = game.get_online_gid(mysql_master_read_cursor)
    _res = summary.get_with_games(
        mysql_master_read_cursor, from_time, to_time, "CNY", [str(gid) for gid in gids]
    )
    logger.debug(_res[:10])


def test_get_currency_grade_game(
    mysql_master_read_cursor: MySQLCursor,
    utc_today: pendulum_datetime,
):
    to_time = utc_today.format("YYYY-MM-DD")
    from_time = utc_today.add(days=-7).format("YYYY-MM-DD")
    _res = summary.get_currency_grade_game(mysql_master_read_cursor, from_time, to_time)
    logger.debug(_res[:10])


def test_get_vip_info_with_owners(
    mysql_master_read_cursor: MySQLCursor,
    utc_today: pendulum_datetime,
):
    to_time = utc_today.format("YYYY-MM-DD")
    from_time = utc_today.add(days=-7).format("YYYY-MM-DD")
    big_bet_ratio = 2
    vip_bet_threshold = 1000
    _res = summary.get_vip_info_with_owners(
        mysql_master_read_cursor, from_time, to_time, big_bet_ratio, vip_bet_threshold
    )
    logger.debug(_res[:10])


def test_get_users_bet_with_owners(
    mysql_master_read_cursor: MySQLCursor,
    utc_today: pendulum_datetime,
):
    to_time = utc_today.format("YYYY-MM-DD")
    from_time = utc_today.add(days=-7).format("YYYY-MM-DD")
    _res = summary.get_user_duration_n_times_with_owners(
        mysql_master_read_cursor, from_time, to_time
    )

    one_shots = list(set([str(_info[2]) for _info in _res if _info[3] == 1]))
    _nums = 100
    for i in range(0, len(one_shots), _nums):
        _res_bets = summary.get_users_bet_with_owners(
            mysql_master_read_cursor, from_time, to_time, one_shots[i : i + _nums]
        )
        logger.debug(_res_bets)


def test_get_user_durations_n_times_with_owners(
    mysql_master_read_cursor: MySQLCursor,
    utc_today: pendulum_datetime,
):
    to_time = utc_today.format("YYYY-MM-DD")
    from_time = utc_today.add(days=-7).format("YYYY-MM-DD")
    _res = summary.get_user_duration_n_times_with_owners(
        mysql_master_read_cursor, from_time, to_time
    )
    logger.debug(_res[:10])


def test_get_with_owners(
    mysql_master_read_cursor: MySQLCursor,
    utc_today: pendulum_datetime,
):
    to_time = utc_today.format("YYYY-MM-DD")
    from_time = utc_today.add(days=-7).format("YYYY-MM-DD")
    _res = summary.get_with_owners(mysql_master_read_cursor, from_time, to_time)
    logger.debug(_res[:10])
