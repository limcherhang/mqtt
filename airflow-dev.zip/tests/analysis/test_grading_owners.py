import pytest
from pytest_mock import MockerFixture

import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from datetime import datetime
import logging
from mysql.connector.cursor import MySQLCursor
from itertools import groupby
from airflow.exceptions import AirflowException

from dags.analysis.crud import summary, grade_resources, grade_results
from dags.utils import tools

logger = logging.getLogger(__name__)

_CFG = {
    "OWNER_GRADING": {
        "CHECK_DAY_INTERVAL": 7,
        "VIP_BET_THRESHOLD": 30_000,
        "VIP_BET_RATIO": 0.6,
        "GRADE_CORRESPOND_SIZE": 12,
    },
    "GRADE_INTERVAL": [
        {"LEVEL": -3, "RANGE_TO": -3},
        {"LEVEL": -2, "RANGE_FROM": -3, "RANGE_TO": -2},
        {"LEVEL": -1, "RANGE_FROM": -2, "RANGE_TO": -1},
        {"LEVEL": 0, "RANGE_FROM": -1, "RANGE_TO": 1},
        {"LEVEL": 1, "RANGE_FROM": 1, "RANGE_TO": 2},
        {"LEVEL": 2, "RANGE_FROM": 2, "RANGE_TO": 3},
        {"LEVEL": 3, "RANGE_FROM": 3},
    ],
}


def side_effect_insert(*_, **kwargs):
    logger.info(f"Insert with rows(top10): {kwargs.get('rows', [])[:10]}")


@pytest.fixture
def data_interval_end(utc_today: pendulum_datetime) -> pendulum_datetime:
    return pendulum.datetime(
        utc_today.year,
        utc_today.month,
        utc_today.day,
        tz=utc_today.tz,
    )


def test_give_grade(
    mocker: MockerFixture,
    mysql_master_read_cursor: MySQLCursor,
    mysql_master_write_cursor: MySQLCursor,
    data_interval_end: pendulum_datetime,
):
    """
    Final step: grading each owner by resources.
    """
    grade_results.store_owners = mocker.Mock(side_effect=side_effect_insert)

    _GRADING_CFG = _CFG.get("OWNER_GRADING", {})
    GRADE_CORRESPOND_SIZE = _GRADING_CFG.get("GRADE_CORRESPOND_SIZE", 12)
    CHECK_DAY_INTERVAL = _GRADING_CFG.get("CHECK_DAY_INTERVAL", 7)
    GRADE_INTERVAL = _GRADING_CFG.get("GRADE_INTERVAL", [])

    to_time = data_interval_end
    from_time = to_time.add(
        days=-1 * (CHECK_DAY_INTERVAL * (GRADE_CORRESPOND_SIZE + 1))
    )
    grade_time = to_time.add(days=-1 * CHECK_DAY_INTERVAL)
    compare_time = to_time.add(days=-2 * CHECK_DAY_INTERVAL)

    logger.info("Ready for grading")
    resources = grade_resources.get_owner_info(
        mysql_master_read_cursor,
        from_time.format("YYYY-MM-DD"),
        to_time.format("YYYY-MM-DD"),
    )
    if not resources:
        # raise AirflowException(
        #     f"Get nothing from owner resources from {from_time} to {to_time}"
        # )
        logger.info("No resources")
        return
    import pandas as pd
    import numpy as np

    # preparing for grading
    resources_df = pd.DataFrame(
        resources,
        columns=[
            "date",
            "oid",
            "bets",
            "avgBetByRound",
            "players",
            "oneShotBetsRatio",
            "avgDuration",
            "vipPlayersRatio",
            "onlinetime",
        ],
    )
    logger.debug("------owner grade resources------")
    logger.debug(resources_df.head(10))

    resources_df.bets = pd.to_numeric(resources_df.bets)
    resources_df.avgBetByRound = pd.to_numeric(resources_df.avgBetByRound)
    resources_df.oneShotBetsRatio = pd.to_numeric(resources_df.oneShotBetsRatio)
    resources_df.avgDuration = pd.to_numeric(resources_df.avgDuration)
    resources_df.vipPlayersRatio = pd.to_numeric(resources_df.vipPlayersRatio)
    resources_df.date = pd.to_datetime(resources_df.date)
    resources_df.onlinetime = pd.to_datetime(resources_df.onlinetime)
    index_res_df = resources_df.set_index(["oid", "date"])

    grade_cols = [
        "bets",
        "avgBetByRound",
        "players",
        "oneShotBetsRatio",
        "avgDuration",
        "vipPlayersRatio",
    ]
    grade_result_df = pd.DataFrame(
        index=resources_df.oid.unique(), data=0, dtype="int8", columns=grade_cols
    )
    grade_result_df = grade_result_df.join(resources_df.groupby("oid").agg({"onlinetime": "first"}))  # type: ignore
    logger.info("Complete preparing owner grade")

    # calculating growth point
    index_grade_time = datetime(grade_time.year, grade_time.month, grade_time.day)
    index_compare_time = datetime(
        compare_time.year, compare_time.month, compare_time.day
    )
    for col in grade_cols:
        for oid in grade_result_df.index:
            if col != "oneShotBetsRatio":
                if index_res_df[col].get((oid, index_grade_time), 0) > index_res_df[
                    col
                ].get((oid, index_compare_time), 0):
                    grade_result_df.at[oid, col] = 1
                elif index_res_df[col].get((oid, index_grade_time), 0) < index_res_df[
                    col
                ].get((oid, index_compare_time), 0):
                    grade_result_df.at[oid, col] = -1
            else:
                if index_res_df[col].get((oid, index_grade_time), 0) > index_res_df[
                    col
                ].get((oid, index_compare_time), 0):
                    grade_result_df.at[oid, col] = -1
                elif index_res_df[col].get((oid, index_grade_time), 0) < index_res_df[
                    col
                ].get((oid, index_compare_time), 0):
                    grade_result_df.at[oid, col] = 1
    logger.debug("------owner growth point------")
    logger.debug(grade_result_df.head(10))
    logger.info("complete owner growth point")

    # calaulating growth point
    np.seterr(
        divide="ignore", invalid="ignore"
    )  # Ignore: divide by zero, and invalid nan
    for oid in grade_result_df.index:
        res_df = resources_df.query(f"oid == {oid}")

        the_onlinetime = grade_result_df.at[oid, "onlinetime"]
        default_size = (
            datetime(grade_time.year, grade_time.month, grade_time.day) - the_onlinetime
        ).days // CHECK_DAY_INTERVAL
        # only calculate owner whose number of data have at least half of compare size
        if default_size < (GRADE_CORRESPOND_SIZE // 2):
            continue

        for col in grade_cols:

            # fill the missing value as 0. dep_% as dependency_%
            dep_arr = res_df[
                res_df.date
                <= datetime(compare_time.year, compare_time.month, compare_time.day)
            ][col].values
            dep_count = len(dep_arr)
            if default_size > GRADE_CORRESPOND_SIZE:
                while dep_count < GRADE_CORRESPOND_SIZE:
                    dep_arr = np.append(dep_arr, 0)
                    dep_count += 1
            else:
                while dep_count < default_size:
                    dep_arr = np.append(dep_arr, 0)
                    dep_count += 1

            # remove the maximum and minimum
            cleared_len = len(
                dep_arr[(dep_arr != np.max(dep_arr)) & (dep_arr != np.min(dep_arr))]
            )
            if cleared_len >= (GRADE_CORRESPOND_SIZE // 2):
                dep_arr = dep_arr[
                    (dep_arr != np.max(dep_arr)) & (dep_arr != np.min(dep_arr))
                ]

            # Calculating the grade level
            dep_avg = dep_arr.mean()
            dep_std = dep_arr.std(ddof=1)
            grade_dep = (
                index_res_df[col].get((oid, index_grade_time), 0) - dep_avg
            ) / dep_std
            if np.isnan(grade_dep):
                grade_dep = 0

            # Giving fluctuate grade to result
            if col != "oneShotBetsRatio":
                fluctuate_lvl = tools.get_level(grade_dep, GRADE_INTERVAL)
                grade_result_df.at[oid, col] += int(fluctuate_lvl)
            else:
                fluctuate_lvl = tools.get_level(
                    grade_dep, GRADE_INTERVAL, directly=False
                )
                grade_result_df.at[oid, col] += int(fluctuate_lvl)
    logger.debug("------owner growth point + fluctuate point------")
    logger.debug(grade_result_df.head(10))
    logger.info("complete owner fluctuate point")

    # store grades
    grade_result_df.drop(columns=["onlinetime"], inplace=True)
    grade_result_df.reset_index(inplace=True)
    grade_result_df.columns = pd.Index(["oid"] + grade_cols)
    grade_result_df["date"] = grade_time.strftime("%Y-%m-%d")

    insert_rows = list()
    for i in grade_result_df.index:
        insert_rows.append(
            (
                grade_result_df.at[i, "date"],
                int(grade_result_df.at[i, "oid"]),
                int(grade_result_df.at[i, "bets"]),
                int(grade_result_df.at[i, "avgBetByRound"]),
                int(grade_result_df.at[i, "players"]),
                int(grade_result_df.at[i, "oneShotBetsRatio"]),
                int(grade_result_df.at[i, "avgDuration"]),
                int(grade_result_df.at[i, "vipPlayersRatio"]),
            )
        )
    grade_results.store_owners(mysql_master_write_cursor, insert_rows)
    logger.info("Insert into owner_grade_resources success!")


def test_collect_vip(
    mocker: MockerFixture,
    mysql_master_read_cursor: MySQLCursor,
    mysql_master_write_cursor: MySQLCursor,
    data_interval_end: pendulum_datetime,
):
    """
    Third step: find vips situation under each owner.
    """
    grade_resources.insert_owner_vip = mocker.Mock(side_effect=side_effect_insert)

    to_time = data_interval_end.format("YYYY-MM-DD")
    _GRADING_CFG = _CFG.get("OWNER_GRADING", {})
    CHECK_DAY_INTERVAL = _GRADING_CFG.get("CHECK_DAY_INTERVAL", 7)
    from_time = data_interval_end.add(days=-1 * CHECK_DAY_INTERVAL).format("YYYY-MM-DD")
    VIP_BET_RATIO = _GRADING_CFG.get("VIP_BET_RATIO", 0.5)
    VIP_BET_THRESHOLD = _GRADING_CFG.get("VIP_BET_THRESHOLD", 10_000)

    owner_vip_infos = summary.get_vip_info_with_owners(
        mysql_master_read_cursor, from_time, to_time, VIP_BET_RATIO, VIP_BET_THRESHOLD
    )

    logger.info(f"Grading owner resource vip(top10): {owner_vip_infos[:10]}")
    if owner_vip_infos:
        grade_resources.insert_owner_vip(
            mysql_master_write_cursor, rows=owner_vip_infos
        )


def test_collect_duration_n_one_shot_info(
    mocker: MockerFixture,
    mysql_master_read_cursor: MySQLCursor,
    mysql_master_write_cursor: MySQLCursor,
    data_interval_end: pendulum_datetime,
):
    """
    Second step: grab duration info, and get one shot info base on each owner's basic summary
    """
    grade_resources.insert_owner_duration = mocker.Mock(side_effect=side_effect_insert)
    grade_resources.insert_owner_one_shots = mocker.Mock(side_effect=side_effect_insert)

    to_time = data_interval_end.format("YYYY-MM-DD")
    _GRADING_CFG = _CFG.get("OWNER_GRADING", {})
    CHECK_DAY_INTERVAL = _GRADING_CFG.get("CHECK_DAY_INTERVAL", 7)
    from_time = data_interval_end.add(days=-1 * CHECK_DAY_INTERVAL).format("YYYY-MM-DD")

    player_infos = summary.get_user_duration_n_times_with_owners(
        mysql_master_read_cursor, from_time, to_time
    )
    if not player_infos:
        logger.warning(
            f"Grading owner from {from_time} to {to_time} not have any duration or one-shot infos"
        )
        return

    def key_func(_info: summary.OwnerUserDurationNTimes):
        return str(_info.date) + ":" + str(_info.oid)

    # for duration
    owners_durations = []
    # groupby assumes that the elements in the same group appear consecutively
    for key_str, infos in groupby(sorted(player_infos, key=key_func), key=key_func):
        infos = list(infos)
        logger.debug(key_str + "<> " + str(infos[:5]))
        player_count = len(infos)
        total_duration = sum([info.duration / info.times for info in infos])
        key = tuple(i for i in key_str.split(":"))
        key += (total_duration / player_count,)
        owners_durations.append(key)

    logger.info(f"Grading owner resource duration(top10): {owners_durations[:10]}")
    if owners_durations:
        grade_resources.insert_owner_duration(
            mysql_master_write_cursor, rows=owners_durations
        )

    # for one-shot info
    owners_one_shot = []
    query_limit_num = 1000
    one_shots = [_info for _info in player_infos if _info.times == 1]
    for key_str, infos in groupby(sorted(one_shots, key=key_func), key=key_func):
        infos = list(infos)
        key = tuple(i for i in key_str.split(":"))
        _bets = 0
        for i in range(0, len(infos), query_limit_num):
            _bet_infos = summary.get_users_bet_with_owners(
                mysql_master_read_cursor,
                from_time,
                to_time,
                [str(u.uid) for u in one_shots[i : i + query_limit_num]],
            )
            _bets += _bet_infos[0].bets
        key += (len(infos), _bets)
        owners_one_shot.append(key)

    logger.info(f"Grading owner resource one-shots(top10): {one_shots[:10]}")
    if owners_one_shot:
        grade_resources.insert_owner_one_shots(
            mysql_master_write_cursor, rows=owners_one_shot
        )


def test_collect_interval_summary(
    mocker: MockerFixture,
    mysql_master_read_cursor: MySQLCursor,
    mysql_master_write_cursor: MySQLCursor,
    data_interval_end: pendulum_datetime,
):
    """
    First step: get basic summary for resources
    """
    grade_resources.insert_owner_summary = mocker.Mock(side_effect=side_effect_insert)

    to_time = data_interval_end.format("YYYY-MM-DD")
    _GRADING_CFG = _CFG.get("OWNER_GRADING", {})
    CHECK_DAY_INTERVAL = _GRADING_CFG.get("CHECK_DAY_INTERVAL", 7)
    from_time = data_interval_end.add(days=-1 * CHECK_DAY_INTERVAL).format("YYYY-MM-DD")
    _summary = summary.get_with_owners(mysql_master_read_cursor, from_time, to_time)

    logger.info(f"Grading owner resource basic-summary(top10): {_summary[:10]}")
    if not _summary:
        raise AirflowException(f"Get nothing for owner grading-resource summary")

    grade_resources.insert_owner_summary(mysql_master_write_cursor, rows=_summary)
