import sys
from pathlib import Path

sys.path.append(str(Path.cwd()) + "/dags")
