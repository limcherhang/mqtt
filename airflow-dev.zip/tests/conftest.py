from typing import Generator
import pytest
from pytest_mock import MockerFixture

from tests.utils.config import settings
import mysql.connector
from mysql.connector.cursor import CursorBase
from mysql.connector.cursor_cext import CMySQLCursor
import os
import sys
from sqlalchemy.engine import make_url
import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
import logging
import pymongo
from pymongo import MongoClient
from pathlib import Path

from airflow import DAG
from airflow.models import DagBag

logger = logging.getLogger(__name__)


@pytest.fixture
def OauthGSheetHook(
    mocker: MockerFixture,
):
    def side_effect_init(*args, **kwargs):
        logger.info(f"OauthGSheetHook __init__ args {args}; kwargs {kwargs}")
        return MockOauthGSheethook

    MockOauthGSheethook = mocker.MagicMock(side_effect=side_effect_init)

    def side_effect_append_values(*args, **kwargs):
        logger.info(f"OauthGSheetHook append_values args {args}; kwargs {kwargs}")

    MockOauthGSheethook.append_values = mocker.Mock(
        side_effect=side_effect_append_values
    )

    return MockOauthGSheethook


@pytest.fixture
def utc_today() -> pendulum_datetime:
    return pendulum.now("UTC")


@pytest.fixture
def mongo_read_client() -> Generator[MongoClient, None, None]:
    connection = MongoClient(
        host=settings.MONGO_READ.HOST,
        port=settings.MONGO_READ.PORT,
        username=settings.MONGO_READ.USERNAME,
        password=settings.MONGO_READ.PASSWORD,
        authSource=settings.MONGO_READ.AUTH_SOURCE,
        connect=True,
        serverSelectionTimeoutMS=3000,
        replicaSet=settings.MONGO_READ.REPLICA_SET,
        read_preference=pymongo.read_preferences.ReadPreference.SECONDARY_PREFERRED,  # type: ignore
        w=1,
    )
    yield connection
    connection.close()


@pytest.fixture
def mysql_master_write_cursor() -> Generator[
    None | CMySQLCursor | CursorBase, None, None
]:
    mysql_url = settings.MYSQL_MASTER_WRITE
    mysql_cnx = mysql.connector.connect(**make_url(mysql_url).translate_connect_args())
    cursor = mysql_cnx.cursor()
    cursor.execute("SET time_zone = '+00:00'")
    yield cursor
    cursor.close()
    mysql_cnx.close()


@pytest.fixture
def mysql_master_read_cursor() -> Generator[
    None | CMySQLCursor | CursorBase, None, None
]:
    mysql_url = settings.MYSQL_MASTER_READ
    mysql_cnx = mysql.connector.connect(**make_url(mysql_url).translate_connect_args())
    cursor = mysql_cnx.cursor()
    cursor.execute("SET time_zone = '+00:00'")
    yield cursor
    cursor.close()
    mysql_cnx.close()


@pytest.fixture(scope="session")
def airflow_env_setup():
    home_path = Path.cwd()
    os.environ["AIRFLOW_HOME"] = str(home_path)
    os.environ["AIRFLOW__CORE__EXECUTOR"] = "CeleryExecutor"
    os.environ["AIRFLOW__CORE__SQL_ALCHEMY_CONN"] = settings.AIRFLOW_SQL_CONN
    os.environ["AIRFLOW__CELERY__RESULT_BACKEND"] = settings.AIRFLOW_CELERY_RESULT
    os.environ["AIRFLOW__CELERY__BROKER_URL"] = settings.AIRFLOW_CELERY_BROKER
    os.environ["AIRFLOW__CORE__FERNET_KEY"] = ""
    os.environ["AIRFLOW__CORE__DAGS_FOLDER"] = str(home_path / "dags")
    os.environ["AIRFLOW__CORE__PLUGINS_FOLDER"] = str(home_path / "plugins")
    os.environ["AIRFLOW__CORE__BASE_LOG_FOLDER"] = "/tmp/log_airflow"
    os.environ["AIRFLOW__CORE__DAG_PROCESSOR_MANAGER_LOG_LOCATION"] = "/tmp/log_airflow"
    os.environ["AIRFLOW__SCHEDULER__CHILD_PROCESS_LOG_DIRECTORY"] = "/tmp/log_airflow"
    os.environ["AIRFLOW__CORE__LOAD_EXAMPLES"] = "false"
    os.environ["AIRFLOW__CORE__UNIT_TEST_MODE"] = "true"
    env_info = "Airflow environments: \n"
    for env in os.environ.keys():
        if env.startswith("AIRFLOW_"):
            env_info += f"{env}={os.environ[env]} \n"
    logger.info(env_info)
    yield


@pytest.fixture(scope="session")
def dag_bag(airflow_env_setup):
    DAGS_FOLDER = os.environ["AIRFLOW__CORE__DAGS_FOLDER"]
    return DagBag(dag_folder=DAGS_FOLDER, include_examples=False)


@pytest.fixture
def test_dag():
    default_args = {"owner": "airflow", "start_date": pendulum.today("UTC")}
    return DAG("test_dag", default_args=default_args, schedule=None)


@pytest.fixture(scope="session", autouse=True)
def setup_airflow_log():
    log = logging.getLogger("airflow.task")
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    log.addHandler(handler)
    yield
