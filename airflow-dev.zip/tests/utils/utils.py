import logging
from typing import Optional, Union

logger = logging.getLogger("test")


def side_effect_telegram_message(*args, **kwargs):
    _chats = kwargs.get("telegram_chats")
    _message = kwargs.get("message")
    if len(args) == 3:
        _chats, _message, _ = args
    elif len(args) == 2:
        if (not _chats) and (not _message):
            _chats, _message = args
        elif (not _chats) and _message:
            _chats, _ = args
        else:
            _, _message = args
    elif len(args) == 0:
        if not _chats:
            _chats = args[0]
        elif not _chats:
            _message = args[0]

    logger.info(f"Telegram to chats: {_chats} with: \n{_message}")


class MockResponse:
    def __init__(
        self, json_data: Optional[Union[dict, list]] = None, status_code: int = 200
    ):
        self.json_data = json_data
        self.status_code = status_code

    def json(self):
        return self.json_data


class MockDAAPIHook:
    def __init__(self) -> None:
        pass

    def add_specify_project(*args, **kwargs):
        logger.info(f"DA-API add_specify_project with args: {args}; kwargs: {kwargs}")
        return MockResponse()

    def update_specify_project(*args, **kwargs):
        logger.info(
            f"DA-API update_specify_project with args: {args}; kwargs: {kwargs}"
        )
        return MockResponse()

    def get_specify_project(*args, **kwargs):
        logger.info(f"DA-API get_specify_project with args: {args}; kwargs: {kwargs}")
        return MockResponse()


def side_effect_teamplus_message(*args, **kwargs):
    _chats = kwargs.get("teamplu_chats")
    _message = kwargs.get("message")
    if len(args) == 3:
        _chats, _message, _ = args
    elif len(args) == 2:
        if (not _chats) and (not _message):
            _chats, _message = args
        elif (not _chats) and _message:
            _chats, _ = args
        else:
            _, _message = args
    elif len(args) == 0:
        if not _chats:
            _chats = args[0]
        elif not _chats:
            _message = args[0]

    logger.info(f"TeamPlus to chats: {_chats} with: \n{_message}")
