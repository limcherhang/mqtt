import logging
from dags.utils import tools

logger = logging.getLogger(__name__)


def test_get_level():
    test_levels = [
        {"LEVEL": -3, "RANGE_TO": -3},
        {"LEVEL": -2, "RANGE_FROM": -3, "RANGE_TO": -2},
        {"LEVEL": -1, "RANGE_FROM": -2, "RANGE_TO": -1},
        {"LEVEL": 0, "RANGE_FROM": -1, "RANGE_TO": 1},
        {"LEVEL": 1, "RANGE_FROM": 1, "RANGE_TO": 2},
        {"LEVEL": 2, "RANGE_FROM": 2, "RANGE_TO": 3},
        {"LEVEL": 3, "RANGE_FROM": 3},
    ]
    level = tools.get_level(1, test_levels)
    assert level == 0
    level = tools.get_level(1.1, test_levels)
    assert level == 1
    level = tools.get_level(1.1, test_levels, directly=False)
    assert level == -1
