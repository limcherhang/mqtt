import pytest

import logging
from pendulum.datetime import DateTime as pendulum_datetime

from dags.utils.connection import team_plus

logger = logging.getLogger(__name__)


@pytest.mark.skip("Need to export env for Airflow")
def test_team_plus_hook(utc_today: pendulum_datetime):
    hook = team_plus.RMBotTeamPlusMessageHook()
    msg = f"Hello from Airflow at {utc_today}"
    hook.run(chat=832, message=msg)
