from pydantic import BaseSettings, BaseModel, validator


class MongoReadSetting(BaseModel):
    HOST: str = "10.30.2.114,10.30.2.115,10.30.2.116"

    @validator("HOST")
    def hosts2list(cls, value: str):
        if "," in value:
            return value.split(",")
        else:
            return [value]

    PORT: int = 27017
    USERNAME: str = "JMkumquat_keep"
    PASSWORD: str = "eWjV89SxC_ship"
    AUTH_SOURCE: str = "admin"
    REPLICA_SET: str = "INT-CUBE_rep"


class PytestSettings(BaseSettings):
    MONGO_READ: MongoReadSetting = MongoReadSetting()
    MYSQL_MASTER_WRITE: str = "mysql+mysqlconnector://IMkumquat_keep:G2vi7A6Sx_ship@10.30.2.144:3306/airflow_db"
    MYSQL_MASTER_READ: str = "mysql+mysqlconnector://IMkumquat_keep:G2vi7A6Sx_ship@10.30.2.144:3306/airflow_db"
    AIRFLOW_SQL_CONN: str = "mysql+mysqlconnector://IMairflow_keep:p3Jx6in7P_ship@10.30.2.144:3306/airflow_db"
    AIRFLOW_CELERY_RESULT: str = "db+mysql+mysqlconnector://IMairflow_keep:p3Jx6in7P_ship@10.30.2.144:3306/airflow_db"
    AIRFLOW_CELERY_BROKER: str = "redis://:redis4SYS@10.30.3.52:3002/6"

    class Config:
        case_sensitive = True
        env_file = "afpytest.env"
        env_file_encoding = "utf-8"
        env_prefix = "AFPYTEST_"
        env_nested_delimiter = "__"


settings = PytestSettings()
