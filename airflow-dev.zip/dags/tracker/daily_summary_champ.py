from typing import Dict, Any
import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from datetime import timedelta
import logging
import tenacity

from utils.connection.mysql import mysql_cursor
from utils.connection.da_api import DAAPIHook
from utils.connection.champ_api import ChampAPIHook
from tracker.crud import summary
from tracker.src import sender

from airflow.decorators import dag, task
from utils.tools import teamplus_message
from airflow.models import Variable

logger = logging.getLogger("airflow.task")

default_args = {
    "depends_on_past": False,
    "email": ["rmpeter0474@adcrow.tech"],
    "email_on_failure": True,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(seconds=10),
}


@dag(
    start_date=pendulum.datetime(2022, 10, 12, tz="UTC"),
    schedule="10 0 * * *",
    default_args=default_args,
    catchup=False,
    max_active_tasks=4,
    tags=["CHAMP", "champ", "tracker"],
)
def daliy_summary_champ():
    """
    ### Champ Daily Summary
    Get addition info from champland API, and send summary to team+ and store to DA-API
    """

    @task()
    def get_diversity_summary(
        data_interval_start: pendulum_datetime = pendulum.now(),
    ) -> Any:
        """
        ### Get the day summary
        """
        import pandas as pd

        check_date_str = data_interval_start.format("YYYY-MM-DD")
        brand = "champland"
        _CFG = Variable.get("TRACKER_SUMMARY", deserialize_json=True)
        champ_rate = 585

        lotto_games = _CFG.get("CHAMPLAND_LOTTO")
        one_time_range = _CFG.get("CHAMPLAND_ONE_TIME_RANGE")
        with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
            one_time_users = summary.get_one_time_users(
                cursor, check_date_str, brand, one_time_range, game_codes=lotto_games
            )
            lotto_sum = summary.get_lotto_date(
                cursor,
                check_date_str,
                lotto_games,
                by_genre=False,
                exclude_uids=one_time_users,
            )
            lotto_genre = summary.get_lotto_date(
                cursor,
                check_date_str,
                lotto_games,
                by_genre=True,
                exclude_uids=one_time_users,
            )
            played_registered_user, _ = summary.get_played_registered_user_count(
                cursor, check_date_str, brand, game_codes=lotto_games
            )
            registered_user = summary.get_registered_user_count(cursor, check_date_str)

        hook = ChampAPIHook()
        retry_args = dict(
            wait=tenacity.wait_exponential(),  # pyright: ignore [reportPrivateImportUsage]
            stop=tenacity.stop_after_attempt(  # pyright: ignore [reportPrivateImportUsage]
                10
            ),
            retry=tenacity.retry_if_exception_type(  # pyright: ignore [reportPrivateImportUsage]
                Exception
            ),
        )
        members_bet_info = hook.run_with_advanced_retry(
            func="get_member_bet",
            _retry_args=retry_args,
            check_date=check_date_str.replace("-", ""),
        )
        champ_df = pd.DataFrame(
            [_info.split(",") for _info in members_bet_info.text.split("\n")]
        )
        champ_df.rename(columns=champ_df.iloc[0], inplace=True)
        champ_df.drop(champ_df.index[0], inplace=True)  # type: ignore
        champ_df["總投注額"] = pd.to_numeric(champ_df["總投注額"]) / champ_rate
        champ_summary = (
            champ_df.groupby(["類別"], as_index=False)
            .agg({"總投注額": "sum", "會員編號": "nunique"})
            .to_dict("records")  # type: ignore
        )

        return {  # type: ignore
            "check_date_str": check_date_str,
            "lotto_sum": lotto_sum,
            "lotto_genre": lotto_genre,
            "champ_summary": champ_summary,
            "one_time_users": one_time_users,
            "played_registered_user": played_registered_user,
            "registered_user": registered_user,
        }

    @task()
    def teamplus_summary_message(
        day_summary: Dict,
    ):
        """
        Send summary message to TeamPlus
        """
        check_date_str = day_summary["check_date_str"]
        lotto_sum = day_summary["lotto_sum"]
        lotto_genre = day_summary["lotto_genre"]
        champ_summary = day_summary["champ_summary"]
        one_time_users = day_summary["one_time_users"]
        played_registered_user = day_summary["played_registered_user"]
        registered_user = day_summary["registered_user"]
        _CFG = Variable.get("TRACKER_SUMMARY", deserialize_json=True)
        _GENRE_NAME_TW = Variable.get("GENRE_NAME_TW", deserialize_json=True)
        check_genres = _CFG.get("CHAMPLAND_LOTTO_GENRES")
        one_time_range = _CFG.get("CHAMPLAND_ONE_TIME_RANGE")

        api_types = _CFG.get("CHAMPLAND_API_TYPES")
        bets_include_type = _CFG.get("CHAMPLAND_BET_INCLUDE_TYPES")
        msg = f"日期: {check_date_str} \n"
        for game, info in lotto_sum.items():
            champ_bets = float(info["bets"])
            for _type in champ_summary:
                if _type.get("類別") in bets_include_type:
                    champ_bets += _type.get("總投注額")
            msg += f"遊戲: {game} \n"
            msg += f"總碼量(CNY): {champ_bets:,.0f} \n"
            msg += f'不重複人數: {info["players"]:,} \n'
            msg += f"註冊人數: {registered_user:,} \n"
            msg += f"註冊且下注人數: {played_registered_user:,} \n"
            msg += f"{one_time_range}日內一次性玩家數: {len(one_time_users)} \n"
            for _type in champ_summary:
                _category = _type.get("類別")
                if _category not in api_types:
                    continue
                _bet = _type.get("總投注額")
                _player = _type.get("會員編號")
                msg += f"{_category}總碼量(CNY): {_bet:,.0f} \n"
                msg += f"{_category}不重複人數: {_player:,d} \n"

            msg += "\n"
            for genre in check_genres:
                gen_info = lotto_genre.get(game, {}).get(genre, {})
                msg += f"\t類型: {_GENRE_NAME_TW.get(genre, genre)} \n"
                msg += f'\t碼量: {gen_info.get("bets", 0):,.0f} \n'
                msg += f'\t人數: {gen_info.get("players", 0):,} \n'
                msg += "\n"

        teamplus_message(_CFG.get("TEAMPLUS_CHAT", []), msg)

    @task()
    def add_and_update_to_api(
        day_summary: Dict,
    ):
        import schemas

        brand = "champland"
        check_date_str = day_summary["check_date_str"]
        lotto_sum = day_summary["lotto_sum"]
        lotto_genre = day_summary["lotto_genre"]
        champ_summary = day_summary["champ_summary"]
        played_registered_user = day_summary["played_registered_user"]
        registered_user = day_summary["registered_user"]

        _CFG = Variable.get("TRACKER_SUMMARY", deserialize_json=True)
        check_genres = _CFG.get("CHAMPLAND_LOTTO_GENRES")
        bets_include_type = _CFG.get("CHAMPLAND_BET_INCLUDE_TYPES")
        api_types = _CFG.get("CHAMPLAND_API_TYPES")
        hook = DAAPIHook()
        other_genres = []
        for game, info in lotto_sum.items():

            if game != "球狀元(CF體育)":  # "動博體育" in SIT
                continue

            champ_bets = float(info["bets"])
            for _type in champ_summary:
                if _type.get("類別") in bets_include_type:
                    champ_bets += _type.get("總投注額")

            performance_in = schemas.SalesPerformance.parse_obj(
                dict(
                    date=check_date_str,
                    brand="champland",
                    bet=champ_bets,
                    player=info["players"],
                    registered_player=registered_user,
                    played_registered_player=played_registered_user,
                )
            )
            hook.add_performance(
                performance_in=performance_in.json(
                    exclude_unset=True, exclude_none=True
                ),
                check_response=False,
            )
            # record champ-API type
            for _type in champ_summary:
                if _type.get("類別") not in api_types:
                    continue
                _bet = _type.get("總投注額")
                _player = _type.get("會員編號")
                other_genres.append(
                    {"genre": _type.get("類別"), "bets": _bet, "players": _player}
                )

            for genre in check_genres:
                gen_info = lotto_genre.get(game, {}).get(genre, {})

                performance_in = schemas.SalesPerformanceGametype.parse_obj(
                    dict(
                        date=check_date_str,
                        brand="champland",
                        currency="ALL",
                        gametype=genre,
                        bet=gen_info.get("bets", 0),
                        player=gen_info.get("players", 0),
                    )
                )
                hook.add_performance_by_gametype(
                    performance_in=performance_in.json(
                        exclude_unset=True, exclude_none=True
                    ),
                    check_response=False,
                )

        for _info in other_genres:
            performance_in = schemas.SalesPerformanceGametype.parse_obj(
                dict(
                    date=check_date_str,
                    brand="champland",
                    currency="ALL",
                    gametype=_info.get("genre"),
                    bet=_info.get("bets", 0),
                    player=_info.get("players", 0),
                )
            )
            hook.add_performance_by_gametype(
                performance_in=performance_in.json(
                    exclude_unset=True, exclude_none=True
                ),
                check_response=False,
            )

        with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
            # SP game
            for game, info in _CFG.get("SP_GAME").items():
                if not brand.upper() in info:
                    continue
                logger.info(f"Get game: {game} under brand {brand}")
                sp_game_code = info[brand.upper()]
                sp_game_name = info["NAME"]
                sp_game_type = info["TYPE"]
                (_bets, _net_wins, _rounds, _players,) = summary.get_game_by_code(
                    cursor, check_date_str, sp_game_code, sp_game_type
                )
                performance_in = schemas.SalesSpecifyProject.parse_obj(
                    dict(
                        date=check_date_str,
                        brand=brand,
                        currency="ALL",
                        project=sp_game_name,
                        span="day",
                        code=sp_game_code,
                        bet=_bets,
                        net_win=_net_wins,
                        player=_players,
                        rounds=_rounds,
                    )
                )
                logger.debug(performance_in)
                hook.add_specify_game(performance_in.json(), check_response=False)
                if _bets == 0:
                    continue
                sp_spreadsheet_id = info.get("SPREADSHEET_ID")
                if sp_spreadsheet_id:
                    sender.google_sheet_append_sp_game_values(
                        "CHAMP",
                        check_date_str,
                        _bets,
                        _net_wins,
                        _rounds,
                        _players,
                        sp_spreadsheet_id,
                    )
                sp_spreadsheet_id = info.get("BY_OWNER_SPREADSHEET_ID")
                if sp_spreadsheet_id:
                    sender.google_sheet_append_sp_game_by_owner_values(
                        "CHAMP",
                        check_date_str,
                        sp_game_code,
                        sp_game_type,
                        sp_spreadsheet_id,
                        cursor,
                    )

                (_bets, _net_wins, _rounds, _players,) = summary.get_game_month_by_code(
                    cursor, check_date_str, sp_game_code, sp_game_type
                )
                if _bets == 0:
                    continue
                key = schemas.SalesSpecifyProjectKey.parse_obj(
                    dict(
                        date=check_date_str[:8] + "01",
                        brand=brand,
                        currency="ALL",
                        project=sp_game_name,
                        span="month",
                    )
                )
                info = hook.get_specify_project(key.dict(), check_response=False)
                performance_in = {
                    "bet": _bets,
                    "net_win": _net_wins,
                    "player": _players,
                    "rounds": _rounds,
                }
                if 233 > info.status_code >= 200:
                    hook.update_specify_game(
                        key.json(),
                        schemas.SalesSpecifyProjectUpdate.parse_obj(
                            performance_in
                        ).json(exclude_unset=True, exclude_none=True),
                        check_response=False,
                    )
                else:
                    performance_in["code"] = sp_game_code
                    performance_in.update(key.dict())
                    hook.add_specify_game(
                        schemas.SalesSpecifyProject.parse_obj(performance_in).json(),
                        check_response=False,
                    )

        hook.maintain_performance_size()

    diversity_summary = get_diversity_summary()
    teamplus_summary_message(diversity_summary)
    add_and_update_to_api(diversity_summary)


daily_summary_champ_dag = daliy_summary_champ()
