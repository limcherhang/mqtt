# Tracker

### ANY
##### Transform point to rate (for venus)
* rememeber to create empty table under other environment  
* `LEFT JOIN` with `IFNULL`
```sql
CREATE TABLE MaReport.parent_point_rate (
  `oid` INT NOT NULL COMMENT '總代id mapping cypress.parent_list.id',
  `pid` INT NOT NULL COMMENT '子代id mapping cypress.parent_list.id',
  `point_rate` DECIMAL(20,7) DEFAULT 1 COMMENT '點數轉換',
  PRIMARY KEY (`pid`)
);

INSERT INTO MaReport.parent_point_rate VALUES (16884, 16884, 130);
```

### hourly alert on new players
* schedule `20,50 * * * *`
* variable `{'TRACKER_ALERT': {NEW_PLAYER: {...config}}}`
  * REGISTER_FROM_HOURS 新玩家註冊時間（小時）； N小時前到程式執行當下，註冊的新玩家
  * TOTAL_NET_WIN_THRESHOLD 當小時**所有**遊戲net_win加總警示閥值
  * TOTAL_NET_WIN 當小時**所有**遊戲警示TeamPlus群組
  * GAME_NET_WIN_THRESHOLD 當小時**單一**遊戲net_win加總警示閥值
  * GAME_NET_WIN 當小時**單一**遊戲警示TeamPlus群組
* flow
```mermaid
    flowchart LR;
      A[alert_high_net_win] -.-> T
      subgraph task
        direction LR
        T[high total net win] --> G[high game net win]
      end
```

### high bet high win sport
* schedule `*/5 * * * *`
* variable `{'ALERT_HIGHBET_N_HIGHWIN_SPORT:{...}}`
  * HIGHBET_CHAT : TeamPlus群組編號
  * HIGHWIN_CHAT : TeamPlus群組編號
  * HIGHBET_THRESHOLD : 碼量閥值，大約閾值則警示，否則跳過
  * MULTIPLE_THRESHOLD : 倍數閥值，當吐錢除以閥值大於碼量則警示，否則跳過
* flow
```mermaid
    flowchart LR;
      A[alert_highbet_and_highwin_sport] -.-> T
      subgraph task
        direction LR
        T[high bet] --> G[high win]
      end
```

### on specify hedge
* schedule `*/15 * * * *`
* variable `{'TRACKER_ALERT': {...config}}`
  * SPECIFIC_HEDGE_CHAT 警示TeamPlus群組
* rules
  1. 特定bet_type與bet_type特定組合  
  2. table 1 百家, 4 龍虎  
  3. 1/3 < 碼量倍率 < 3  
  4. 至少連續 **3場** 對打  

### high bet and high win motivation
* schedule `*/5 * * * *`
* variable `{'ALERT_HIGHBET_N_HIGHWIN_MOTIVATION:{...}}`
  * TELEGRAM_CHAT : Telegram群組編號
  * HIGHBET_THRESHOLD : 碼量閥值
  * MULTIPLE_THRESHOLD : 倍數閥值
* explanation
  * alert when condition bets>=HIGHBET_THRESHOLD and wins>bets*MULTIPLE_THRESHOLD
* flow
```mermaid
  flowchart LR;
    A[alert_highbet_and_highwin_sport] -.-> T
    subgraph task
      T[high bet and<br>high win]
    end
```