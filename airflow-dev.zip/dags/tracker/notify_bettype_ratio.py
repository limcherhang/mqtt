import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from datetime import timedelta
import logging

from airflow.providers.mongo.hooks.mongo import MongoHook
from tracker.crud.mongo import order
from utils.tools import telegram_message

from airflow.decorators import dag, task
from airflow.models import Variable

logger = logging.getLogger("airflow.task")

default_args = {
    "depends_on_past": False,
    "email": ["rmpeter0474@adcrow.tech"],
    "email_on_failure": True,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(seconds=10),
}


@dag(
    start_date=pendulum.datetime(2023, 1, 17, tz="UTC"),
    schedule="15 * * * *",
    default_args=default_args,
    catchup=False,
    max_active_tasks=4,
    tags=["PRO", "cq9", "VENUS", "168", "tracker"],
)
def notify_bettype_ratio():
    """
    ### Notify Motivation bettype ratio
    """

    @task()
    def notify(
        data_interval_end: pendulum_datetime = pendulum.now(),
    ):
        _CFG = Variable.get("TRACKER_ALERT", deserialize_json=True)
        _BT_CFG = _CFG.get("BETTYPE_RATIO", {})
        check_interval = _BT_CFG.get("CHECK_INTERVAL", 1)

        infos = []
        with MongoHook(conn_id="mongo_read") as mongo_hook:
            mongo_cnx = mongo_hook.get_conn()
            infos = order.get_motivation_bettype_info(
                mongo_cnx,
                data_interval_end.add(hours=-1 * check_interval),
                data_interval_end,
            )
        logger.info("james testing")
        logger.info(f"Count on {len(infos)} data")
        counter = {}
        for info in infos:
            _tabletype = info.get("tabletype")
            _tableid = info.get("tableid")
            _bettypes = info.get("bettype", [])
            table_counter = counter.setdefault(_tableid, {"tabletype": _tabletype})
            for _bettype in _bettypes:
                if _bettype in table_counter:
                    table_counter[_bettype] += 1
                else:
                    table_counter[_bettype] = 1

        logger.info(f"Notify {len(counter)} counted-data")
        TABLETYPE_INFO = Variable.get("TABLETYPE_INFO", deserialize_json=True)
        ENV = _BT_CFG.get("ENV", "")
        msg = ""
        if ENV and counter:
            msg = f"環境: {ENV}\n"
        for table, info in sorted(counter.items(), key=lambda k: k[0]):
            tabletype = info.pop("tabletype")
            the_type_info = TABLETYPE_INFO.get(tabletype, {})
            tabletype_name = the_type_info.get("NAME", "_")

            msg += f"{tabletype_name}桌號: {table} 場次比例<"
            total = sum(info.values())
            for _bettype, _count in sorted(info.items(), key=lambda k: int(k[0])):
                msg += f"{the_type_info.get('BETTYPE', {}).get(_bettype, _bettype)}: {(_count / total) * 100 :.2f}% "
            msg += ">\n"

        if msg:
            TG_CHAT = _BT_CFG.get("TG_CHAT", [])
            telegram_message(TG_CHAT, msg)

    notify()


notify_bettype_ratio_dag = notify_bettype_ratio()
