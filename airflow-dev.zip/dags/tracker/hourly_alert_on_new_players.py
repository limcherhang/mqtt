import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from datetime import timedelta
import logging

from utils.connection.mysql import mysql_cursor
from utils.connection.da_api import DAAPIHook
from tracker.crud import user
from utils.tools import teamplus_message

from airflow.decorators import dag, task
from airflow.models import Variable

logger = logging.getLogger("airflow.task")

default_args = {
    "depends_on_past": False,
    "email": ["rmpeter0474@adcrow.tech"],
    "email_on_failure": True,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(seconds=10),
}


@dag(
    start_date=pendulum.datetime(2022, 12, 1, tz="UTC"),
    schedule="20,50 * * * *",
    default_args=default_args,
    catchup=False,
    max_active_tasks=4,
    tags=["PRO", "cq9", "tracker"],
)
def hourly_alert_on_new_player():
    """
    ### High Net-Win New Players
    Send alert to team+ and broadcast via API
    """

    @task()
    def alert_high_net_win(
        data_interval_end: pendulum_datetime = pendulum.now(),
    ):
        _CFG = Variable.get("TRACKER_ALERT", deserialize_json=True)
        _NEWS_CFG = _CFG.get("NEW_PLAYER", {})
        reg_from_hour = _NEWS_CFG.get("REGISTER_FROM_HOURS", 720)
        check_to_time_str = data_interval_end.format("YYYY-MM-DD HH")
        check_from_time_str = data_interval_end.add(hours=-1).format("YYYY-MM-DD HH")
        reg_from_time_str = data_interval_end.add(hours=-1 * reg_from_hour).format(
            "YYYY-MM-DD HH"
        )
        logger.info(f"Track range from {check_from_time_str} to {check_to_time_str}")
        hook = DAAPIHook()
        api_param = {
            "topic": "alert:risk",
            "key": "",
            "message": "",
        }

        with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
            total_net_win_threshold = _NEWS_CFG.get("TOTAL_NET_WIN_THRESHOLD", 100_000)
            infos = user.get_news_with_high_net_win(
                cursor,
                check_from_time_str,
                check_to_time_str,
                reg_from_time_str,
                total_net_win_threshold,
            )

            high_total_net_win_chat = _NEWS_CFG.get("HIGH_TOTAL_NET_WIN")
            api_param["key"] = "new_player_high_total_net_win"

            if infos:
                for (
                    _owner,
                    _parent,
                    _user,
                    _userid,
                    _bets,
                    _rounds,
                    _net_wins,
                ) in infos:
                    msg = "    HIGH TOTAL NET WIN!\n"
                    msg += f"owner: {_owner}\n"
                    msg += f"prent: {_parent}\n"
                    msg += f"player: {_user}\n"
                    msg += f"playerSSID: {_userid}\n"
                    msg += f"bets: {_bets:,.2f}\n"
                    msg += f"rounds: {_rounds:,}\n"
                    msg += f"netWins: {_net_wins:,.2f}\n"
                    teamplus_message(high_total_net_win_chat, msg)

                    api_param["message"] = msg
                    hook.broadcast_alert(api_param, check_response=False)

            else:
                msg = "There is not any high TOTAL net-win players!"
                teamplus_message(high_total_net_win_chat, msg)

                api_param["message"] = msg
                hook.broadcast_alert(api_param, check_response=False)

            game_net_win_threshold = _NEWS_CFG.get("GAME_NET_WIN_THRESHOLD", 50_000)
            api_param["key"] = "new_player_high_game_net_win"

            infos = user.get_news_with_high_net_win_n_game(
                cursor,
                check_from_time_str,
                check_to_time_str,
                reg_from_time_str,
                game_net_win_threshold,
            )

            high_game_net_win_chat = _NEWS_CFG.get("HIGH_GAME_NET_WIN")
            if infos:
                for (
                    _owner,
                    _parent,
                    _user,
                    _userid,
                    _game,
                    _bets,
                    _rounds,
                    _net_wins,
                ) in infos:
                    msg = "    HIGH GAME NET WIN!\n"
                    msg += f"owner: {_owner}\n"
                    msg += f"prent: {_parent}\n"
                    msg += f"player: {_user}\n"
                    msg += f"playerSSID: {_userid}\n"
                    msg += f"game: {_game}\n"
                    msg += f"bets: {_bets:,.2f}\n"
                    msg += f"rounds: {_rounds:,}\n"
                    msg += f"netWins: {_net_wins:,.2f}\n"
                    teamplus_message(high_game_net_win_chat, msg)

                    api_param["message"] = msg
                    hook.broadcast_alert(api_param, check_response=False)
            else:
                msg = "There is not any high GAME net-win players!"
                teamplus_message(high_game_net_win_chat, msg)

                api_param["message"] = msg
                hook.broadcast_alert(api_param, check_response=False)

    alert_high_net_win()


hourly_alert_on_new_player_dag = hourly_alert_on_new_player()
