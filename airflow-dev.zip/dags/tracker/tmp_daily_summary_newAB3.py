import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from datetime import timedelta, datetime
import logging

from utils.connection.mysql import mysql_cursor
from utils.connection.google import OauthGSheetHook
from tracker.crud import summary
from utils.tools import get_excel_timestamp

from airflow.decorators import dag, task

logger = logging.getLogger("airflow.task")

default_args = {
    "depends_on_past": False,
    "email": ["rmpeter0474@adcrow.tech"],
    "email_on_failure": True,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(seconds=10),
}


@dag(
    start_date=pendulum.datetime(2022, 12, 30, tz="UTC"),
    schedule="10 0 * * *",
    default_args=default_args,
    catchup=False,
    max_active_tasks=2,
    tags=["PRO", "cq9", "tracker"],
)
def tmp_daily_summary_newAB3():
    @task()
    def get_summary(
        data_interval_start: pendulum_datetime = pendulum.now(),
    ):
        check_date_str = data_interval_start.format("YYYY-MM-DD")
        with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
            _summary = summary.get_newAB3_summary(cursor, check_date_str)

            gsheet_hook = OauthGSheetHook(gcp_conn_id="google_report")
            range_ = "sheet1"
            values_ = [
                [
                    get_excel_timestamp(datetime.strptime(check_date_str, "%Y-%m-%d")),
                    "AB3",
                    round(float(_summary[0]), 2),
                    round(float(_summary[1]), 0),
                    round(float(_summary[2]), 0),
                    round(float(_summary[3]), 2),
                ]
            ]
            gsheet_hook.append_values(
                spreadsheet_id="1O_LiYXWOwm5PdkLB_P_LtGYF_imi-alnBvDyx3Y6fW0",
                range_=range_,
                values=values_,
            )

    get_summary()


tmp_daily_summary_newAB3_dag = tmp_daily_summary_newAB3()
