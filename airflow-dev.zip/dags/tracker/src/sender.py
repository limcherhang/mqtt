from typing import List, Optional
from tracker.crud import summary
from decimal import Decimal
from mysql.connector.cursor import MySQLCursor
from datetime import datetime

from utils.tools import teamplus_message, get_excel_timestamp
from utils.connection.da_api import DAAPIHook
from utils.connection.google import OauthGSheetHook
from tracker.src import tools
import schemas


def google_sheet_append_sp_game_by_owner_values(
    brand: str,
    date_str: str,
    game_code: str,
    game_type: str,
    spreadsheet_id: str,
    cursor: MySQLCursor,
    custom_rate: int = 1,
    gsheet_hook: Optional[OauthGSheetHook] = None,
):
    owner_summarys = summary.get_game_owner_summary_by_code(
        cursor, date_str, game_code, game_type
    )
    if not gsheet_hook:
        gsheet_hook = OauthGSheetHook(gcp_conn_id="google_report")
    range_ = "sheet1"
    values_ = [
        [
            get_excel_timestamp(datetime.strptime(date_str, "%Y-%m-%d")),
            brand,
            str(summary[0]),
            round(float(summary[1]) / custom_rate, 2),
            round(float(summary[3]), 2),
            summary[4],
            round(float(summary[2]) / custom_rate, 2),
        ]
        for summary in owner_summarys
    ]
    gsheet_hook.append_values(
        spreadsheet_id=spreadsheet_id, range_=range_, values=values_
    )


def google_sheet_append_sp_game_values(
    brand: str,
    date_str: str,
    game_bets: Decimal,
    game_net_wins: Decimal,
    game_rounds: int,
    game_players: int,
    spreadsheet_id: str,
    custom_rate: int = 1,
    gsheet_hook: Optional[OauthGSheetHook] = None,
):
    if not gsheet_hook:
        gsheet_hook = OauthGSheetHook(gcp_conn_id="google_report")
    range_ = "sheet1"
    values_ = [
        [
            get_excel_timestamp(datetime.strptime(date_str, "%Y-%m-%d")),
            brand,
            round(float(game_bets) / custom_rate, 2),
            game_rounds,
            game_players,
            round(float(game_net_wins) / custom_rate, 2),
        ]
    ]
    gsheet_hook.append_values(
        spreadsheet_id=spreadsheet_id, range_=range_, values=values_
    )


def notify_performance_alarm(
    date: str,
    brand: str,
    currency: str,
    today_bets: Decimal,
    pre_month_avg_bet: Decimal | float,
    gametype: Optional[str] = None,
    hook: Optional[DAAPIHook] = None,
    _config: dict = {},
    desc_threshold: float = -0.1,
):
    diff_rate = tools.growth_rate(today_bets, pre_month_avg_bet)
    if diff_rate > desc_threshold:
        return

    if not hook:
        hook = DAAPIHook()
    message = f"與上月平均相較下降{abs(diff_rate) * 100:.0f}%"
    match gametype:
        case "slot":
            message = "老虎機" + message
        case "arcade":
            message = "街機" + message
        case "fish":
            message = "漁機" + message
        case "live":
            message = "真人" + message
        case "table":
            message = "棋牌" + message
        case "lotto":
            message = "彩票" + message
        case "sport":
            message = "體育" + message
        case _:
            pass

    alarm = schemas.SalesAlarm(
        title="整體業績警示" if currency == "ALL" else f"{currency}市場警示",
        message=message,
        brand=f"{brand}-{currency}-{gametype}",
        date=date,
    )
    if _config.get("IS_CQ9", False):
        hook.notify_performance_alarm(alarm=alarm.dict(), check_response=False)
    elif _config.get("IS_SIT", False):
        hook.notify_performance_alarm(
            alarm=alarm.dict(),
            action="TestSalesAlarm",
            topic="test-alarm",
            check_response=False,
        )


def teamplus_motivation_with_top_owners(
    brand: str,
    game_code: str,
    game_name: str,
    game_type: str,
    game_bets: Decimal,
    date_str: str,
    cursor: MySQLCursor,
    teamplus_chats: List[int],
    custom_rate: int = 1,
):
    top_owners = summary.get_game_top_owner_by_code(
        cursor, date_str, game_code, game_type
    )
    msg = f"環境：{brand} \n"
    msg += f"日期：{date_str} \n"
    msg += f"遊戲：{game_name} \n"
    msg += f"碼量：{game_bets / custom_rate:,.2f}(CNY) \n"
    msg += "\n"
    if top_owners:
        msg += "Top 總代 \n"
        for (owner, bets) in top_owners:
            msg += f"\t\t 總代：{owner} \n"
            msg += f"\t\t 碼量：{bets / custom_rate:,.2f} \n"
            msg += "\n"

    teamplus_message(teamplus_chats, msg)
