def growth_rate(compare, base):
    try:
        return (float(compare) - float(base)) / float(base)
    except ZeroDivisionError:
        if compare > 0:
            return 1
        else:
            return 0


def divide_no_zero(numerator, denominator):
    if numerator == 0:
        return 0
    if denominator == 0:
        return numerator

    return numerator / denominator
