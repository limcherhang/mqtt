import logging
from mysql.connector.cursor import MySQLCursor

logger = logging.getLogger("airflow.task")


def get_info(cursor: MySQLCursor) -> dict:

    stmt = "SELECT game_name_en, game_code "
    stmt += "FROM MaReport.game_info"

    cursor.execute(stmt)
    result = list(cursor)
    logger.info("Get game info success")

    return result
