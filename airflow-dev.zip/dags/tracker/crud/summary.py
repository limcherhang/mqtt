import logging
from typing import Tuple, Dict, List, Optional
from decimal import Decimal
from mysql.connector.cursor import MySQLCursor

from airflow.models import Variable

from utils.tools import trans_num_type_prevent_none

logger = logging.getLogger("airflow.task")


def get_newAB3_summary(
    cursor: MySQLCursor,
    check_date: str,
) -> tuple[Decimal, Decimal, Decimal, int]:
    """New-AB3 summary from GO_Prob_RecordDB.Wager (bets, rounds, players, net_win);"""

    stmt = "SELECT SUM(GW.TotalBet / FR.rate), COUNT(1), COUNT(DISTINCT GW.UserID), SUM((GW.TotalBet - GW.TotalWin) / FR.rate)"
    stmt += "FROM GO_Prob_RecordDB.Wager GW "
    stmt += (
        "JOIN cypress.parent_list PLP ON GW.SubAgent = PLP.ssid AND PLP.istestss = 0 "
    )
    stmt += "JOIN cypress.parent_list PLO ON PLP.owner = PLO.ssid AND PLO.istestss = 0 "
    stmt += "JOIN cypress.fx_rate FR ON PLP.currency = FR.short_name "
    stmt += f"WHERE GW.GameCode = 'AB3' AND GW.StartTime >= '{check_date}' AND GW.StartTime < DATE_ADD('{check_date}', INTERVAL 1 DAY) "

    cursor.execute(stmt)
    _summary = cursor.fetchone()  # type: ignore
    logger.info(f"Get new-AB3 summary on {check_date} SUCCESS!")
    return _summary  # type: ignore


def get_lego_summary(
    cursor: MySQLCursor,
    check_date: str,
    project: str,
    day_opt: str = "today",
) -> tuple[Decimal, Decimal, Decimal, int]:
    """Lego summary (bets, net_win, rounds, players);"""

    stmt = "SELECT IFNULL(SUM(LUG.bets/FR.rate), 0) bet, IFNULL(SUM((LUG.bets - LUG.wins)/FR.rate), 0) net_win,"
    stmt += " IFNULL(SUM(LUG.rounds), 0) round, COUNT(DISTINCT LUG.uid) player_count "
    stmt += "FROM ReportStore.lego_hour_user_game LUG "
    stmt += f"JOIN ReportStore.lego_user_list LUL ON LUG.uid = LUL.id AND LUL.project = '{project}' "
    stmt += "JOIN (SELECT * FROM cypress.fx_rate UNION ALL SELECT '', 'TWD', '', 4.393, '', '') FR ON LUL.currency = FR.short_name "
    if day_opt == "cumonth":
        stmt += f"WHERE LUG.date BETWEEN DATE_FORMAT('{check_date}', '%Y-%m-01') AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    else:
        stmt += f"WHERE LUG.date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "

    cursor.execute(stmt)
    _summary = cursor.fetchone()  # type: ignore
    logger.info(f"Get Lego summary on {check_date} SUCCESS!")
    return _summary  # type: ignore


def get_game_owner_summary_by_code(
    cursor: MySQLCursor,
    check_date: str,
    game_code: str,
    game_type: str,
) -> List[tuple[str, Decimal, Decimal, Decimal, int]]:
    """(owner, bets, net_win, rounds, players); RM API SP games"""

    if game_type in ("slot", "fish", "arcade"):
        stmt = "SELECT RPL.owner, SUM(UG.total_bet/RPL.rate/IFNULL(PPR.point_rate, 1)) bet, SUM((UG.total_bet - UG.total_win)/RPL.rate/IFNULL(PPR.point_rate, 1)) net_win,"
        stmt += " SUM(UG.total_round) round, COUNT(DISTINCT UG.uid) player_count "
        stmt += "FROM cypress.statistic_user_by_game UG "
    elif game_type in ("table", "live"):
        stmt = "SELECT RPL.owner, SUM(UG.total_bet/RPL.rate/IFNULL(PPR.point_rate, 1)) bet, SUM((UG.total_rake - UG.total_win + UG.room_fee)/RPL.rate/IFNULL(PPR.point_rate, 1)) net_win,"
        stmt += " SUM(UG.total_round) round, COUNT(DISTINCT UG.uid) player_count "
        stmt += "FROM cypress.statistic_user_by_tablegame UG "
    else:
        stmt = "SELECT RPL.owner, SUM(UG.total_bet/RPL.rate/IFNULL(PPR.point_rate, 1)) bet, SUM((UG.total_bet - UG.total_win)/RPL.rate/IFNULL(PPR.point_rate, 1)) net_win,"
        stmt += " SUM(UG.total_bet_count) round, COUNT(DISTINCT UG.uid) player_count "
        stmt += "FROM cypress.statistic_user_by_lottogame UG "

    stmt += "JOIN cypress.user_list UL ON UG.uid = UL.id "
    stmt += "JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid "
    stmt += "LEFT JOIN MaReport.parent_point_rate PPR ON RPL.pid = PPR.pid "
    stmt += (
        f"JOIN cypress.game_list GL ON UG.gid = GL.id AND GL.game_code = '{game_code}' "
    )
    stmt += f"WHERE UG.date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    stmt += "GROUP BY RPL.owner "

    cursor.execute(stmt)
    owner_summary = cursor.fetchall()  # type: ignore
    logger.info(
        f"Get game: {game_code} {len(owner_summary)} oids summary on {check_date} SUCCESS!"
    )
    return owner_summary


def get_one_time_users(
    cursor: MySQLCursor,
    check_date: str,
    brand: str,
    check_range: int = 7,
    currencys: list = [],
    game_codes: list = [],
) -> List[int]:
    """Get one-time players who play only one day in the recent 7({check_range}) days. (For champ)"""
    one_time_users = []

    users_stmt = f"SELECT DISTINCT UG.uid "
    users_stmt += "FROM ( "
    users_stmt += "  SELECT uid, gid "
    users_stmt += "  FROM cypress.statistic_user_by_game "
    users_stmt += (
        f" WHERE date BETWEEN '{check_date}' AND '{check_date}' + INTERVAL 23 HOUR "
    )
    users_stmt += "  GROUP BY uid, gid "
    users_stmt += "  UNION ALL "
    users_stmt += "  SELECT uid, gid "
    users_stmt += "  FROM cypress.statistic_user_by_tablegame "
    users_stmt += (
        f" WHERE date BETWEEN '{check_date}' AND '{check_date}' + INTERVAL 23 HOUR "
    )
    users_stmt += "  GROUP BY uid, gid "
    users_stmt += "  UNION ALL "
    users_stmt += "  SELECT uid, gid "
    users_stmt += "  FROM cypress.statistic_user_by_lottogame "
    users_stmt += (
        f" WHERE date BETWEEN '{check_date}' AND '{check_date}' + INTERVAL 23 HOUR "
    )
    users_stmt += "  GROUP BY uid, gid ) UG "
    users_stmt += "JOIN cypress.user_list UL ON UG.uid = UL.id "
    users_stmt += "JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid "
    if currencys:
        users_stmt += f"AND RPL.currency IN ({str(currencys)[1:-1]}) "
    users_stmt += (
        f"JOIN cypress.game_list GL ON UG.gid = GL.id AND GL.brand = '{brand}' "
    )
    users_stmt += "  AND GL.status = 1 AND GL.maintain = 0 "
    if game_codes:
        users_stmt += f"AND GL.game_code IN ({str(game_codes)[1:-1]}) "

    count_stmt = f"SELECT UG.uid, COUNT(DISTINCT UG.dt) counts "
    count_stmt += "FROM ( "
    count_stmt += "  SELECT DATE(date) dt, uid, gid "
    count_stmt += "  FROM cypress.statistic_user_by_game "
    count_stmt += f" WHERE date BETWEEN DATE_SUB(DATE_ADD('{check_date}', INTERVAL 1 DAY), INTERVAL {check_range} DAY) AND '{check_date}' + INTERVAL 23 HOUR "
    count_stmt += "     AND uid IN ({users})"
    count_stmt += "  GROUP BY dt, uid, gid "
    count_stmt += "  UNION ALL "
    count_stmt += "  SELECT DATE(date) dt, uid, gid "
    count_stmt += "  FROM cypress.statistic_user_by_tablegame "
    count_stmt += f" WHERE date BETWEEN DATE_SUB(DATE_ADD('{check_date}', INTERVAL 1 DAY), INTERVAL {check_range} DAY) AND '{check_date}' + INTERVAL 23 HOUR "
    count_stmt += "     AND uid IN ({users})"
    count_stmt += "  GROUP BY dt, uid, gid "
    count_stmt += "  UNION ALL "
    count_stmt += "  SELECT DATE(date) dt, uid, gid "
    count_stmt += "  FROM cypress.statistic_user_by_lottogame "
    count_stmt += f" WHERE date BETWEEN DATE_SUB(DATE_ADD('{check_date}', INTERVAL 1 DAY), INTERVAL {check_range} DAY) AND '{check_date}' + INTERVAL 23 HOUR "
    count_stmt += "     AND uid IN ({users})"
    count_stmt += "  GROUP BY dt, uid, gid ) UG "
    count_stmt += "JOIN cypress.user_list UL ON UG.uid = UL.id "
    count_stmt += f"  AND DATE(UL.update_time) = '{check_date}' "
    count_stmt += "JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid "
    if currencys:
        count_stmt += f"AND RPL.currency IN ({str(currencys)[1:-1]}) "
    count_stmt += (
        f"JOIN cypress.game_list GL ON UG.gid = GL.id AND GL.brand = '{brand}' "
    )
    count_stmt += "  AND GL.status = 1 AND GL.maintain = 0 "
    if game_codes:
        count_stmt += f"AND GL.game_code IN ({str(game_codes)[1:-1]}) "
    count_stmt += "GROUP BY UG.uid "
    count_stmt += "HAVING counts = 1 "

    cursor.execute(users_stmt)
    today_users = [_u for (_u,) in cursor.fetchall()]

    if today_users:
        cursor.execute(count_stmt.format(users=str(today_users)[1:-1]))
        one_time_users = [_u for (_u, _) in cursor.fetchall()]

    logger.info(f"Get {brand} one-time players under {check_range} days SUCCESS!")
    logger.debug(one_time_users)

    return one_time_users


def get_lotto_date(
    cursor: MySQLCursor,
    check_date: str,
    game_codes: list,
    by_genre: bool,
    exclude_uids: list = [],
) -> dict:
    """
    Get each genre's or summary information including bets, players on selected date.
    Source: cypress.statistic_user_by_lottogame
    """

    stmt = "SELECT GI.game_name_tw, "
    if by_genre:
        stmt += "GNL.genre_name, SUM(UG.total_bet/RPL.rate) bets, COUNT(DISTINCT UG.uid) players "
    else:
        stmt += "SUM(UG.total_bet/RPL.rate) bets, COUNT(DISTINCT UG.uid) players "
    stmt += "FROM cypress.statistic_user_by_lottogame UG "
    stmt += f"JOIN MaReport.game_info GI ON UG.gid = GI.gid AND GI.game_code IN ({str(game_codes)[1:-1]}) "
    if by_genre:
        stmt += "JOIN cypress.genre_list GNL ON UG.genre_id = GNL.id "
    stmt += "JOIN cypress.user_list UL ON UG.uid = UL.id "
    if exclude_uids:
        stmt += f"AND UL.id NOT IN ({str(exclude_uids)[1:-1]}) "
    stmt += "JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid "
    stmt += f"WHERE (UG.date BETWEEN '{check_date}' AND ('{check_date}' + INTERVAL 23 HOUR)) "
    if by_genre:
        stmt += "GROUP BY UG.gid, UG.genre_id "
    else:
        stmt += "GROUP BY UG.gid "

    cursor.execute(stmt)
    if by_genre:
        _result = {}
        for _i in list(cursor):
            _genre_of_game = _result.setdefault(_i[0], {})
            _genre_of_game[_i[1]] = {"bets": _i[2], "players": _i[3]}
    else:
        _result = {_i[0]: {"bets": _i[1], "players": _i[2]} for _i in list(cursor)}

    if by_genre:
        logger.info(f"Get {check_date} genre's info from {game_codes} SUCCESS!")
    else:
        logger.info(f"Get {check_date} info from {game_codes} SUCCESS!")

    return _result


def get_game_top_owner_by_code(
    cursor: MySQLCursor,
    check_date: str,
    game_code: str,
    game_type: str,
    top_range: int = 10,
) -> List[tuple]:
    """(owner, bets); RM API SP games"""

    if game_type in ("slot", "fish", "arcade"):
        stmt_top = "SELECT RPL.owner, SUM(PG.total_bet/RPL.rate/IFNULL(PPR.point_rate, 1)) bet "
        stmt_top += "FROM cypress.statistic_parent_by_game PG "
    elif game_type in ("table", "live"):
        stmt_top = "SELECT RPL.owner, SUM(PG.total_bet/RPL.rate/IFNULL(PPR.point_rate, 1)) bet "
        stmt_top += "FROM cypress.statistic_parent_by_tablegame PG "
    else:
        stmt_top = "SELECT RPL.owner, SUM(PG.total_bet/RPL.rate/IFNULL(PPR.point_rate, 1)) bet "
        stmt_top += "FROM cypress.statistic_parent_by_lottogame PG "

    stmt_top += "JOIN MaReport.report_parent_list RPL ON PG.pid = RPL.pid "
    stmt_top += "LEFT JOIN MaReport.parent_point_rate PPR ON RPL.pid = PPR.pid "
    stmt_top += (
        f"JOIN cypress.game_list gl ON PG.gid = gl.id AND gl.game_code = '{game_code}' "
    )
    stmt_top += f"WHERE PG.date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    stmt_top += "GROUP BY RPL.owner "
    stmt_top += "ORDER BY bet DESC "
    stmt_top += f"LIMIT {top_range} "

    cursor.execute(stmt_top)
    tops = cursor.fetchall()  # type: ignore
    logger.info(
        f"Get game: {game_code} top({top_range}) oids({tops}) on {check_date} SUCCESS!"
    )
    return tops


def get_game_month_by_code(
    cursor: MySQLCursor,
    check_date: str,
    game_code: str,
    game_type: str,
) -> tuple:
    """(bets, net_wins, rounds, players); RM API SP games"""

    if game_type in ("slot", "fish", "arcade"):
        stmt = "SELECT SUM(UG.total_bet/RPL.rate/IFNULL(PPR.point_rate, 1)) bet, SUM((UG.total_bet - UG.total_win)/RPL.rate/IFNULL(PPR.point_rate, 1)) net_win,"
        stmt += " SUM(UG.total_round) round, COUNT(DISTINCT UG.uid) player_count "
        stmt += "FROM cypress.statistic_user_by_game UG "
    elif game_type in ("table", "live"):
        stmt = "SELECT SUM(UG.total_bet/RPL.rate/IFNULL(PPR.point_rate, 1)) bet, SUM((UG.total_rake - UG.total_win + UG.room_fee)/RPL.rate/IFNULL(PPR.point_rate, 1)) net_win,"
        stmt += " SUM(UG.total_round) round, COUNT(DISTINCT UG.uid) player_count "
        stmt += "FROM cypress.statistic_user_by_tablegame UG "
    else:
        stmt = "SELECT SUM(UG.total_bet/RPL.rate/IFNULL(PPR.point_rate, 1)) bet, SUM((UG.total_bet - UG.total_win)/RPL.rate/IFNULL(PPR.point_rate, 1)) net_win,"
        stmt += " SUM(UG.total_bet_count) round, COUNT(DISTINCT UG.uid) player_count "
        stmt += "FROM cypress.statistic_user_by_lottogame UG "

    stmt += "JOIN cypress.user_list UL ON UG.uid = UL.id "
    stmt += "JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid "
    stmt += "LEFT JOIN MaReport.parent_point_rate PPR ON RPL.pid = PPR.pid "
    stmt += (
        f"JOIN cypress.game_list GL ON UG.gid = GL.id AND GL.game_code = '{game_code}' "
    )
    stmt += f"WHERE UG.date BETWEEN DATE_FORMAT('{check_date}', '%Y-%m-01') AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "

    cursor.execute(stmt)
    _res: tuple = cursor.fetchone()  # type: ignore
    logger.info(f"Get game: {game_code} month summary on {check_date} SUCCESS!")

    summary = (
        trans_num_type_prevent_none(float, _res[0]),
        trans_num_type_prevent_none(float, _res[1]),
        trans_num_type_prevent_none(int, _res[2]),
        trans_num_type_prevent_none(int, _res[3]),
    )

    return summary


def get_game_by_code(
    cursor: MySQLCursor,
    check_date: str,
    game_code: str,
    game_type: str,
) -> tuple:
    """(bets, net_wins, rounds, players); RM API SP games"""

    if game_type in ("slot", "fish", "arcade"):
        stmt = "SELECT SUM(UG.total_bet/RPL.rate/IFNULL(PPR.point_rate, 1)) bet, SUM((UG.total_bet - UG.total_win)/RPL.rate/IFNULL(PPR.point_rate, 1)) net_win,"
        stmt += " SUM(UG.total_round) round, COUNT(DISTINCT UG.uid) player_count "
        stmt += "FROM cypress.statistic_user_by_game UG "
    elif game_type in ("table", "live"):
        stmt = "SELECT SUM(UG.total_bet/RPL.rate/IFNULL(PPR.point_rate, 1)) bet, SUM((UG.total_rake - UG.total_win + UG.room_fee)/RPL.rate/IFNULL(PPR.point_rate, 1)) net_win,"
        stmt += " SUM(UG.total_round) round, COUNT(DISTINCT UG.uid) player_count "
        stmt += "FROM cypress.statistic_user_by_tablegame UG "
    else:
        stmt = "SELECT SUM(UG.total_bet/RPL.rate/IFNULL(PPR.point_rate, 1)) bet, SUM((UG.total_bet - UG.total_win)/RPL.rate/IFNULL(PPR.point_rate, 1)) net_win,"
        stmt += " SUM(UG.total_bet_count) round, COUNT(DISTINCT UG.uid) player_count "
        stmt += "FROM cypress.statistic_user_by_lottogame UG "

    stmt += "JOIN cypress.user_list UL ON UG.uid = UL.id "
    stmt += "JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid "
    stmt += "LEFT JOIN MaReport.parent_point_rate PPR ON RPL.pid = PPR.pid "
    stmt += (
        f"JOIN cypress.game_list GL ON UG.gid = GL.id AND GL.game_code = '{game_code}' "
    )
    stmt += f"WHERE UG.date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "

    cursor.execute(stmt)
    _res: tuple = cursor.fetchone()  # type: ignore
    logger.info(f"Get game: {game_code} summary on {check_date} SUCCESS!")

    summary = (
        trans_num_type_prevent_none(float, _res[0]),
        trans_num_type_prevent_none(float, _res[1]),
        trans_num_type_prevent_none(int, _res[2]),
        trans_num_type_prevent_none(int, _res[3]),
    )

    return summary


def get_game_pre_month(
    cursor: MySQLCursor,
    check_date: str,
    brand: str,
    gid: int,
    currency: Optional[str] = None,
) -> Tuple[Decimal, Decimal, int]:
    """
    The previous month of check_date. Get brand game bets, and rounds with/out Currency for comparing"""

    stmt = "SELECT IFNULL(SUM(PGA.bets), 0) bets, IFNULL(SUM(PGA.rounds), 0) rounds, COUNT(DISTINCT dt) count_dates "
    stmt += "FROM ( "
    stmt += "  SELECT DATE(PG.date) dt, PG.pid, PG.gid, SUM(PG.total_bet/RPL.rate) bets, SUM(PG.total_round) rounds "
    stmt += "  FROM cypress.statistic_parent_by_game PG "
    stmt += f" JOIN MaReport.report_parent_list RPL ON PG.pid = RPL.pid "
    if currency:
        stmt += f"AND (CASE WHEN RPL.currency = 'MMKP1' THEN 'MMK' ELSE REGEXP_REPLACE(RPL.currency, '([(].*[)])', '') END) = '{currency}' "
    stmt += f"  WHERE PG.date BETWEEN (LAST_DAY('{check_date}' - INTERVAL 2 Month) + INTERVAL 1 DAY) AND (LAST_DAY('{check_date}' - INTERVAL 1 Month) - INTERVAL 1 HOUR) "
    stmt += f"    AND PG.gid = {gid}"
    stmt += "  GROUP BY dt, PG.pid, PG.gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT DATE(PG.date) dt, PG.pid, PG.gid, SUM(PG.total_bet/RPL.rate) bets, SUM(PG.total_round) rounds "
    stmt += "  FROM cypress.statistic_parent_by_tablegame PG "
    stmt += f" JOIN MaReport.report_parent_list RPL ON PG.pid = RPL.pid "
    if currency:
        stmt += f"AND (CASE WHEN RPL.currency = 'MMKP1' THEN 'MMK' ELSE REGEXP_REPLACE(RPL.currency, '([(].*[)])', '') END) = '{currency}' "
    stmt += f"  WHERE PG.date BETWEEN (LAST_DAY('{check_date}' - INTERVAL 2 Month) + INTERVAL 1 DAY) AND (LAST_DAY('{check_date}' - INTERVAL 1 Month) - INTERVAL 1 HOUR) "
    stmt += f"    AND PG.gid = {gid}"
    stmt += "  GROUP BY dt, PG.pid, PG.gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT DATE(PG.date) dt, PG.pid, PG.gid, SUM(PG.total_bet/RPL.rate) bets, SUM(PG.total_bet_count) rounds "
    stmt += "  FROM cypress.statistic_parent_by_lottogame PG "
    stmt += f" JOIN MaReport.report_parent_list RPL ON PG.pid = RPL.pid "
    if currency:
        stmt += f"AND (CASE WHEN RPL.currency = 'MMKP1' THEN 'MMK' ELSE REGEXP_REPLACE(RPL.currency, '([(].*[)])', '') END) = '{currency}' "
    stmt += f"  WHERE PG.date BETWEEN (LAST_DAY('{check_date}' - INTERVAL 2 Month) + INTERVAL 1 DAY) AND (LAST_DAY('{check_date}' - INTERVAL 1 Month) - INTERVAL 1 HOUR) "
    stmt += f"    AND PG.gid = {gid}"
    stmt += "  GROUP BY dt, PG.pid, PG.gid) PGA "

    cursor.execute(stmt)
    _result = cursor.fetchone()
    logger.info(f"Get {brand} game {gid} previous month bet SUCCESS!")

    return _result  # type: ignore


def get_game_yesterday(
    cursor: MySQLCursor,
    check_date: str,
    brand: str,
    gid: int,
    currency: Optional[str] = None,
) -> Tuple[Decimal, Decimal]:
    """
    The yesterday of check_date. Get brand game bets, and rounds with/out Currency for comparing
    """

    stmt = "SELECT IFNULL(SUM(PG.bets/RPL.rate), 0) bets, IFNULL(SUM(PG.rounds), 0) rounds "
    stmt += "FROM ( "
    stmt += "  SELECT pid, gid, SUM(total_bet) bets, SUM(total_round) rounds "
    stmt += "  FROM cypress.statistic_parent_by_game "
    stmt += f"  WHERE date BETWEEN ('{check_date}' - INTERVAL 1 DAY) AND ('{check_date}' - INTERVAL 1 HOUR) "
    stmt += f"    AND gid = {gid}"
    stmt += "  GROUP BY pid, gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT pid, gid, SUM(total_bet) bets, SUM(total_round) rounds "
    stmt += "  FROM cypress.statistic_parent_by_tablegame "
    stmt += f"  WHERE date BETWEEN ('{check_date}' - INTERVAL 1 DAY) AND ('{check_date}' - INTERVAL 1 HOUR) "
    stmt += f"    AND gid = {gid}"
    stmt += "  GROUP BY pid, gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT pid, gid, SUM(total_bet) bets, SUM(total_bet_count) rounds "
    stmt += "  FROM cypress.statistic_parent_by_lottogame "
    stmt += f"  WHERE date BETWEEN ('{check_date}' - INTERVAL 1 DAY) AND ('{check_date}' - INTERVAL 1 HOUR) "
    stmt += f"    AND gid = {gid}"
    stmt += "  GROUP BY pid, gid) PG "
    stmt += f"JOIN MaReport.report_parent_list RPL ON PG.pid = RPL.pid "
    if currency:
        stmt += f"AND (CASE WHEN RPL.currency = 'MMKP1' THEN 'MMK' ELSE REGEXP_REPLACE(RPL.currency, '([(].*[)])', '') END) = '{currency}' "

    cursor.execute(stmt)
    _result = cursor.fetchone()
    logger.info(f"Get {brand} game {gid} yesterday bet  SUCCESS!")

    return _result  # type: ignore


def get_date_top_game(
    cursor: MySQLCursor,
    check_date: str,
    brand: str,
    currency: Optional[str] = None,
    game_codes: list = [],
    top_range: int = 5,
) -> List[Tuple[str, int, Decimal, Decimal, int]]:
    """
    Get brand game rank, bets, and rounds with/out Currency for riskmanagemange.cagame.cc/api/v1
    """

    stmt = "SELECT RES.game_name_tw, RES.gid, RES.bets, RES.rounds, RES.ranking FROM ( "
    stmt += "SELECT MED_RES.game_name_tw, MED_RES.gid, MED_RES.bets, MED_RES.rounds, RANK() OVER (ORDER BY MED_RES.bets DESC) ranking FROM ( "
    stmt += "SELECT GI.game_name_tw, PG.gid, IFNULL(SUM(PG.bets/RPL.rate), 0) bets, IFNULL(SUM(PG.rounds), 0) rounds "
    stmt += "FROM ( "
    stmt += "  SELECT pid, gid, SUM(total_bet) bets, SUM(total_round) rounds "
    stmt += "  FROM cypress.statistic_parent_by_game "
    stmt += f"  WHERE date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    stmt += "  GROUP BY pid, gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT pid, gid, SUM(total_bet) bets, SUM(total_round) rounds "
    stmt += "  FROM cypress.statistic_parent_by_tablegame "
    stmt += f"  WHERE date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    stmt += "  GROUP BY pid, gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT pid, gid, SUM(total_bet) bets, SUM(total_bet_count) rounds "
    stmt += "  FROM cypress.statistic_parent_by_lottogame "
    stmt += f"  WHERE date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    stmt += "  GROUP BY pid, gid) PG "
    stmt += "JOIN MaReport.report_parent_list RPL ON PG.pid = RPL.pid "
    if currency:
        stmt += f"AND (CASE WHEN RPL.currency = 'MMKP1' THEN 'MMK' ELSE REGEXP_REPLACE(RPL.currency, '([(].*[)])', '') END) = '{currency}' "
    stmt += f"JOIN cypress.game_list GL ON PG.gid = GL.id AND GL.brand = '{brand}' "
    if game_codes:
        stmt += f"AND GL.game_code IN ({str(game_codes)[1:-1]}) "
    stmt += "JOIN MaReport.game_info GI ON GL.id = GI.gid "
    stmt += "GROUP BY PG.gid ) MED_RES ) RES "
    stmt += f"WHERE RES.ranking <= {top_range} "

    if not currency:
        currency = "ALL"

    cursor.execute(stmt)
    _result = [_i for _i in cursor.fetchall()]
    logger.info(f"Get {brand} of currency {currency} top game  SUCCESS!")

    return _result


def get_gametype(
    cursor: MySQLCursor,
    check_date: str,
    brand: str,
    game_type: str,
    currency: Optional[str] = None,
    game_codes: list = [],
    day_opt: str = "today",
) -> Tuple[Decimal, int, Decimal]:
    """
    Get brand gametype bets, and rounds with/out Currency for comparing.
    :day_opt: today, yesterday, premonth
    """

    stmt = "SELECT IFNULL(SUM(PG.total_bet/RPL.rate), 0) bets, COUNT(DISTINCT DATE(PG.date)), "
    if game_type in ("slot", "arcade", "fish"):
        stmt += "  IFNULL(SUM(PG.total_round), 0) rounds "
        stmt += "FROM cypress.statistic_parent_by_game PG "
    elif game_type in ("table", "live"):
        stmt += "  IFNULL(SUM(PG.total_round), 0) rounds "
        stmt += "FROM cypress.statistic_parent_by_tablegame PG "
    elif game_type in ("lotto", "sport"):
        stmt += "  IFNULL(SUM(PG.total_bet_count), 0) rounds "
        stmt += "FROM cypress.statistic_parent_by_lottogame PG "

    stmt += "JOIN MaReport.report_parent_list RPL ON PG.pid = RPL.pid "
    if currency:
        stmt += f"AND (CASE WHEN RPL.currency = 'MMKP1' THEN 'MMK' ELSE REGEXP_REPLACE(RPL.currency, '([(].*[)])', '') END) = '{currency}' "
    stmt += f"JOIN cypress.game_list GL ON PG.gid = GL.id "
    if game_type in ("table", "live"):
        stmt += f"  AND GL.brand = '{brand}' AND GL.game_type = 'table' "
    else:
        stmt += f"  AND GL.brand = '{brand}' AND GL.game_type = '{game_type}' "
    if game_codes:
        stmt += f"AND GL.game_code IN ({str(game_codes)[1:-1]}) "
    elif game_type in ("table", "live"):
        _GAME_TYPE_INFO = Variable.get("GAME_TYPE_INFO", deserialize_json=True)
        include_games = _GAME_TYPE_INFO.get(game_type, {}).get("in")
        if include_games:
            stmt += f"AND GL.game_code IN ({str(include_games)[1:-1]}) "
        exclude_games = _GAME_TYPE_INFO.get(game_type, {}).get("ex")
        if exclude_games:
            stmt += f"AND GL.game_code NOT IN ({str(exclude_games)[1:-1]}) "

    if day_opt == "today":
        stmt += f"  WHERE PG.date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    elif day_opt == "yesterday":
        stmt += f"  WHERE PG.date BETWEEN ('{check_date}' - INTERVAL 1 DAY) AND ('{check_date}' - INTERVAL 1 HOUR) "
    elif day_opt == "premonth":
        stmt += f"  WHERE PG.date BETWEEN (LAST_DAY('{check_date}' - INTERVAL 2 Month) + INTERVAL 1 DAY) AND (LAST_DAY('{check_date}' - INTERVAL 1 Month) - INTERVAL 1 HOUR) "

    if not currency:
        currency = "ALL"

    cursor.execute(stmt)
    _result = cursor.fetchone()
    logger.info(
        f"Get {brand} of currency {currency} gametype-{game_type} {day_opt} bet SUCCESS!"
    )

    return _result  # type: ignore


def get_owner_pre_month(
    cursor: MySQLCursor,
    check_date: str,
    brand: str,
    oid: int,
    currency: Optional[str] = None,
    game_codes: list = [],
) -> Tuple[Decimal, Decimal, int]:
    """
    The previous month of check_date. Get brand owner bets, and rounds with/out Currency for comparing
    """

    stmt = "SELECT IFNULL(SUM(PGA.bets), 0) bets, IFNULL(SUM(PGA.rounds), 0) rounds, COUNT(DISTINCT dt) count_dates "
    stmt += "FROM ( "
    stmt += "  SELECT DATE(PG.date) dt, PG.pid, PG.gid, SUM(PG.total_bet/RPL.rate) bets, SUM(PG.total_round) rounds "
    stmt += "  FROM cypress.statistic_parent_by_game PG "
    stmt += f" JOIN MaReport.report_parent_list RPL ON PG.pid = RPL.pid AND RPL.oid = '{oid}' "
    if currency:
        stmt += f"AND (CASE WHEN RPL.currency = 'MMKP1' THEN 'MMK' ELSE REGEXP_REPLACE(RPL.currency, '([(].*[)])', '') END) = '{currency}' "
    stmt += f"  WHERE PG.date BETWEEN (LAST_DAY('{check_date}' - INTERVAL 2 Month) + INTERVAL 1 DAY) AND (LAST_DAY('{check_date}' - INTERVAL 1 Month) - INTERVAL 1 HOUR) "
    stmt += "  GROUP BY dt, PG.pid, PG.gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT DATE(PG.date) dt, PG.pid, PG.gid, SUM(PG.total_bet/RPL.rate) bets, SUM(PG.total_round) rounds "
    stmt += "  FROM cypress.statistic_parent_by_tablegame PG "
    stmt += f" JOIN MaReport.report_parent_list RPL ON PG.pid = RPL.pid AND RPL.oid = '{oid}' "
    if currency:
        stmt += f"AND (CASE WHEN RPL.currency = 'MMKP1' THEN 'MMK' ELSE REGEXP_REPLACE(RPL.currency, '([(].*[)])', '') END) = '{currency}' "
    stmt += f"  WHERE PG.date BETWEEN (LAST_DAY('{check_date}' - INTERVAL 2 Month) + INTERVAL 1 DAY) AND (LAST_DAY('{check_date}' - INTERVAL 1 Month) - INTERVAL 1 HOUR) "
    stmt += "  GROUP BY dt, PG.pid, PG.gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT DATE(PG.date) dt, PG.pid, PG.gid, SUM(PG.total_bet/RPL.rate) bets, SUM(PG.total_bet_count) rounds "
    stmt += "  FROM cypress.statistic_parent_by_lottogame PG "
    stmt += f" JOIN MaReport.report_parent_list RPL ON PG.pid = RPL.pid AND RPL.oid = '{oid}' "
    if currency:
        stmt += f"AND (CASE WHEN RPL.currency = 'MMKP1' THEN 'MMK' ELSE REGEXP_REPLACE(RPL.currency, '([(].*[)])', '') END) = '{currency}' "
    stmt += f"  WHERE PG.date BETWEEN (LAST_DAY('{check_date}' - INTERVAL 2 Month) + INTERVAL 1 DAY) AND (LAST_DAY('{check_date}' - INTERVAL 1 Month) - INTERVAL 1 HOUR) "
    stmt += "  GROUP BY dt, PG.pid, PG.gid) PGA "
    stmt += f"JOIN cypress.game_list GL ON PGA.gid = GL.id AND GL.brand = '{brand}' "
    if game_codes:
        stmt += f"AND GL.game_code IN ({str(game_codes)[1:-1]}) "

    cursor.execute(stmt)
    _result = cursor.fetchone()
    logger.info(f"Get {brand} owner {oid} previous month bet  SUCCESS!")

    return _result  # type: ignore


def get_owner_yesterday(
    cursor: MySQLCursor,
    check_date: str,
    brand: str,
    oid: int,
    currency: Optional[str] = None,
    game_codes: list = [],
) -> Tuple[Decimal, Decimal]:
    """
    The yesterday of check_date. Get brand owner bets, and rounds with/out Currency for comparing
    """

    stmt = "SELECT IFNULL(SUM(PG.bets/RPL.rate), 0) bets, IFNULL(SUM(PG.rounds), 0) rounds "
    stmt += "FROM ( "
    stmt += "  SELECT pid, gid, SUM(total_bet) bets, SUM(total_round) rounds "
    stmt += "  FROM cypress.statistic_parent_by_game "
    stmt += f"  WHERE date BETWEEN ('{check_date}' - INTERVAL 1 DAY) AND ('{check_date}' - INTERVAL 1 HOUR) "
    stmt += "  GROUP BY pid, gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT pid, gid, SUM(total_bet) bets, SUM(total_round) rounds "
    stmt += "  FROM cypress.statistic_parent_by_tablegame "
    stmt += f"  WHERE date BETWEEN ('{check_date}' - INTERVAL 1 DAY) AND ('{check_date}' - INTERVAL 1 HOUR) "
    stmt += "  GROUP BY pid, gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT pid, gid, SUM(total_bet) bets, SUM(total_bet_count) rounds "
    stmt += "  FROM cypress.statistic_parent_by_lottogame "
    stmt += f"  WHERE date BETWEEN ('{check_date}' - INTERVAL 1 DAY) AND ('{check_date}' - INTERVAL 1 HOUR) "
    stmt += "  GROUP BY pid, gid) PG "
    stmt += (
        f"JOIN MaReport.report_parent_list RPL ON PG.pid = RPL.pid AND RPL.oid = {oid} "
    )
    if currency:
        stmt += f"AND (CASE WHEN RPL.currency = 'MMKP1' THEN 'MMK' ELSE REGEXP_REPLACE(RPL.currency, '([(].*[)])', '') END) = '{currency}' "
    stmt += f"JOIN cypress.game_list GL ON PG.gid = GL.id AND GL.brand = '{brand}' "
    if game_codes:
        stmt += f"AND GL.game_code IN ({str(game_codes)[1:-1]}) "

    cursor.execute(stmt)
    _result = cursor.fetchone()
    logger.info(f"Get {brand} owner {oid} yesterday bet SUCCESS!")

    return _result  # type: ignore


def get_date_top_owner(
    cursor: MySQLCursor,
    check_date: str,
    brand: str,
    currency: Optional[str] = None,
    game_codes: list = [],
    top_range: int = 5,
) -> List[Tuple[str, int, Decimal, Decimal, int]]:
    """
    Get brand owner rank, bets, and rounds with/out Currency for riskmanagemange.cagame.cc/api/v1
    """

    stmt = "SELECT RES.owner, RES.oid, RES.bets, RES.rounds, RES.ranking FROM ( "
    stmt += "SELECT MED_RES.owner, MED_RES.oid, MED_RES.bets, MED_RES.rounds, RANK() OVER (ORDER BY MED_RES.bets DESC) ranking FROM ( "
    stmt += "SELECT RPL.owner, RPL.oid, IFNULL(SUM(PG.bets/RPL.rate), 0) bets, IFNULL(SUM(PG.rounds), 0) rounds "
    stmt += "FROM ( "
    stmt += "  SELECT pid, gid, SUM(total_bet) bets, SUM(total_round) rounds "
    stmt += "  FROM cypress.statistic_parent_by_game "
    stmt += f"  WHERE date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    stmt += "  GROUP BY pid, gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT pid, gid, SUM(total_bet) bets, SUM(total_round) rounds "
    stmt += "  FROM cypress.statistic_parent_by_tablegame "
    stmt += f"  WHERE date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    stmt += "  GROUP BY pid, gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT pid, gid, SUM(total_bet) bets, SUM(total_bet_count) rounds "
    stmt += "  FROM cypress.statistic_parent_by_lottogame "
    stmt += f"  WHERE date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    stmt += "  GROUP BY pid, gid) PG "
    stmt += "JOIN MaReport.report_parent_list RPL ON PG.pid = RPL.pid "
    if currency:
        stmt += f"AND (CASE WHEN RPL.currency = 'MMKP1' THEN 'MMK' ELSE REGEXP_REPLACE(RPL.currency, '([(].*[)])', '') END) = '{currency}' "
    stmt += f"JOIN cypress.game_list GL ON PG.gid = GL.id AND GL.brand = '{brand}' "
    if game_codes:
        stmt += f"AND GL.game_code IN ({str(game_codes)[1:-1]}) "
    stmt += "GROUP BY RPL.oid ) MED_RES ) RES "
    stmt += f"WHERE RES.ranking <= {top_range} "

    if not currency:
        currency = "ALL"

    cursor.execute(stmt)
    _result = [_i for _i in cursor.fetchall()]
    logger.info(f"Get {brand} of currency {currency} top owner  SUCCESS!")

    return _result


def get_registered_user_count(
    cursor: MySQLCursor,
    check_date: str,
    currencys: list = [],
    oids: str = "ALL",
    exclude_uids: list = [],
) -> int:

    stmt = "SELECT UL.id "
    stmt += "FROM cypress.user_list UL "
    stmt += "JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid "
    if currencys:
        stmt += f"AND (CASE WHEN RPL.currency = 'MMKP1' THEN 'MMK' ELSE REGEXP_REPLACE(RPL.currency, '([(].*[)])', '') END) IN ({str(currencys)[1:-1]}) "
    if oids != "ALL":
        stmt += f"AND RPL.oid IN ({oids}) "
    stmt += f"WHERE UL.update_time BETWEEN '{check_date} 00:00:00' AND '{check_date} 23:59:59' "
    if exclude_uids:
        stmt += f"AND UL.id NOT IN ({str(exclude_uids)[1:-1]}) "

    cursor.execute(stmt)
    _result = len(list(cursor))
    logger.info("Get registered players SUCCESS!")
    logger.debug(_result)

    return _result


def get_played_registered_user_count(
    cursor: MySQLCursor,
    check_date: str,
    brand: str,
    currencys: list = [],
    game_codes: list = [],
) -> Tuple[int, str]:

    default_oids = "ALL"
    if brand == "kimbaba":
        default_oids = "16884,16893"

    stmt = f"SELECT '{check_date}', COUNT(DISTINCT UG.uid), 'ALL' "
    if brand == "kimbaba":
        stmt = f"SELECT '{check_date}', COUNT(DISTINCT UG.uid), GROUP_CONCAT(DISTINCT rpl.oid) "
    stmt += "FROM ( "
    stmt += "  SELECT uid, gid "
    stmt += "  FROM cypress.statistic_user_by_game "
    stmt += f" WHERE date BETWEEN '{check_date}' AND '{check_date}' + INTERVAL 23 HOUR "
    stmt += "  GROUP BY uid, gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT uid, gid "
    stmt += "  FROM cypress.statistic_user_by_tablegame "
    stmt += f" WHERE date BETWEEN '{check_date}' AND '{check_date}' + INTERVAL 23 HOUR "
    stmt += "  GROUP BY uid, gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT uid, gid "
    stmt += "  FROM cypress.statistic_user_by_lottogame "
    stmt += f" WHERE date BETWEEN '{check_date}' AND '{check_date}' + INTERVAL 23 HOUR "
    stmt += "  GROUP BY uid, gid ) UG "
    stmt += "JOIN cypress.user_list UL ON UG.uid = UL.id "
    stmt += f"  AND DATE(UL.update_time) = '{check_date}' "
    stmt += "JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid "
    if currencys:
        stmt += f"AND (CASE WHEN RPL.currency = 'MMKP1' THEN 'MMK' ELSE REGEXP_REPLACE(RPL.currency, '([(].*[)])', '') END) IN ({str(currencys)[1:-1]}) "
    stmt += f"JOIN cypress.game_list GL ON UG.gid = GL.id AND GL.brand = '{brand}' "
    stmt += "  AND GL.status = 1 AND GL.maintain = 0 "
    if game_codes:
        stmt += f"AND GL.game_code IN ({str(game_codes)[1:-1]}) "

    cursor.execute(stmt)
    _result = cursor.fetchone()
    logger.info(f"Get {brand} daily played and registered players SUCCESS!")
    logger.debug(_result)
    if (not _result) or (not _result[0]):
        return 0, default_oids
    elif not _result[2]:
        return _result[1], default_oids

    return _result[1], _result[2]


def get_daily_of_currencys(
    cursor: MySQLCursor,
    check_date: str,
    brand: str,
    currencys: list = [],
    game_codes: list = [],
) -> Dict[str, Tuple[Decimal, Decimal, int, Decimal]]:
    """
    Get bets, net_win, players, and rounds BY Currency
    """

    stmt = "SELECT CASE WHEN RPL.currency = 'MMKP1' THEN 'MMK' ELSE REGEXP_REPLACE(RPL.currency, '([(].*[)])', '') END AS display_currency, "
    stmt += "IFNULL(SUM(UG.bets/RPL.rate), 0), IFNULL(SUM(UG.net_wins/RPL.rate), 0), COUNT(DISTINCT UG.uid), IFNULL(SUM(UG.rounds), 0) "
    stmt += "FROM ( "
    stmt += "  SELECT uid, gid, SUM(total_bet) bets, SUM(total_bet - total_win) net_wins, SUM(total_round) rounds "
    stmt += "  FROM cypress.statistic_user_by_game "
    stmt += f"  WHERE date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    stmt += "  GROUP BY uid, gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT uid, gid, SUM(total_bet) bets, SUM(total_rake + room_fee - total_win) net_wins, SUM(total_round) rounds "
    stmt += "  FROM cypress.statistic_user_by_tablegame "
    stmt += f"  WHERE date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    stmt += "  GROUP BY uid, gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT uid, gid, SUM(total_bet) bets, SUM(total_bet - total_win) net_wins, SUM(total_bet_count) rounds "
    stmt += "  FROM cypress.statistic_user_by_lottogame "
    stmt += f"  WHERE date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    stmt += "  GROUP BY uid, gid) UG "
    stmt += "JOIN cypress.user_list UL ON UG.uid = UL.id "
    stmt += "JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid "
    stmt += f"JOIN MaReport.game_info GI ON UG.gid = GI.gid AND GI.brand = '{brand}' "
    if game_codes:
        stmt += f"AND GI.game_code IN ({str(game_codes)[1:-1]}) "
    stmt += "GROUP BY display_currency "
    if currencys:
        stmt += f"HAVING display_currency IN ({str(currencys)[1:-1]}) "

    cursor.execute(stmt)
    _result = {_i[0]: _i[1:] for _i in cursor.fetchall()}
    logger.info(f"Get {brand} daily all currencys summary SUCCESS!")

    return _result


def get_daily_by_currency(
    cursor: MySQLCursor,
    check_date: str,
    brand: str,
    currency: Optional[str] = None,
    game_codes: list = [],
    day_opt: str = "today",
) -> Tuple[Decimal, Decimal, int, Decimal]:
    """
    Get brand-currency bets, net_win, day-counts, and rounds.
    premonth stand for all-the-previous-month
    """

    stmt = "SELECT IFNULL(SUM(PGA.bets), 0), IFNULL(SUM(PGA.net_wins), 0), COUNT(DISTINCT PGA.dt), IFNULL(SUM(PGA.rounds), 0) "
    stmt += "FROM ( "
    stmt += "  SELECT DATE(PG.date) dt, PG.pid, gid, SUM(total_bet / RPL.rate) bets, SUM((total_bet - total_win) / RPL.rate) net_wins, SUM(total_round) rounds "
    stmt += "  FROM cypress.statistic_parent_by_game PG"
    stmt += "  JOIN MaReport.report_parent_list RPL ON PG.pid = RPL.pid "
    if currency:
        stmt += f"AND (CASE WHEN RPL.currency = 'MMKP1' THEN 'MMK' ELSE REGEXP_REPLACE(RPL.currency, '([(].*[)])', '') END) = '{currency}' "
    if day_opt == "yesterday":
        stmt += f"  WHERE date BETWEEN ('{check_date}' - INTERVAL 1 DAY) AND ('{check_date}' - INTERVAL 1 HOUR) "
    elif day_opt == "premonth":
        stmt += f"  WHERE PG.date BETWEEN (LAST_DAY('{check_date}' - INTERVAL 2 Month) + INTERVAL 1 DAY) AND (LAST_DAY('{check_date}' - INTERVAL 1 Month) - INTERVAL 1 HOUR) "
    else:
        stmt += f"  WHERE date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    stmt += "  GROUP BY dt, PG.pid, gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT DATE(PG.date) dt, PG.pid, gid, SUM(total_bet / RPL.rate) bets, SUM((total_rake + room_fee - total_win) / RPL.rate) net_wins, SUM(total_round) rounds "
    stmt += "  FROM cypress.statistic_parent_by_tablegame PG "
    stmt += "  JOIN MaReport.report_parent_list RPL ON PG.pid = RPL.pid "
    if currency:
        stmt += f"AND (CASE WHEN RPL.currency = 'MMKP1' THEN 'MMK' ELSE REGEXP_REPLACE(RPL.currency, '([(].*[)])', '') END) = '{currency}' "
    if day_opt == "yesterday":
        stmt += f"  WHERE date BETWEEN ('{check_date}' - INTERVAL 1 DAY) AND ('{check_date}' - INTERVAL 1 HOUR) "
    elif day_opt == "premonth":
        stmt += f"  WHERE PG.date BETWEEN (LAST_DAY('{check_date}' - INTERVAL 2 Month) + INTERVAL 1 DAY) AND (LAST_DAY('{check_date}' - INTERVAL 1 Month) - INTERVAL 1 HOUR) "
    else:
        stmt += f"  WHERE date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    stmt += "  GROUP BY dt, PG.pid, gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT DATE(PG.date) dt, PG.pid, gid, SUM(total_bet / RPL.rate) bets, SUM((total_bet - total_win) / RPL.rate) net_wins, SUM(total_bet_count) rounds "
    stmt += "  FROM cypress.statistic_parent_by_lottogame PG "
    stmt += "  JOIN MaReport.report_parent_list RPL ON PG.pid = RPL.pid "
    if currency:
        stmt += f"AND (CASE WHEN RPL.currency = 'MMKP1' THEN 'MMK' ELSE REGEXP_REPLACE(RPL.currency, '([(].*[)])', '') END) = '{currency}' "
    if day_opt == "yesterday":
        stmt += f"  WHERE date BETWEEN ('{check_date}' - INTERVAL 1 DAY) AND ('{check_date}' - INTERVAL 1 HOUR) "
    elif day_opt == "premonth":
        stmt += f"  WHERE PG.date BETWEEN (LAST_DAY('{check_date}' - INTERVAL 2 Month) + INTERVAL 1 DAY) AND (LAST_DAY('{check_date}' - INTERVAL 1 Month) - INTERVAL 1 HOUR) "
    else:
        stmt += f"  WHERE date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    stmt += "  GROUP BY dt, PG.pid, gid) PGA "
    stmt += f"JOIN MaReport.game_info GI ON PGA.gid = GI.gid AND GI.brand = '{brand}' "
    if game_codes:
        stmt += f"AND GI.game_code IN ({str(game_codes)[1:-1]}) "

    cursor.execute(stmt)
    _result: Tuple[Decimal, Decimal, int, Decimal] = cursor.fetchone()  # type: ignore
    logger.info(f"Get {brand}-{currency} daily summary SUCCESS!")

    return _result


def get_daily(
    cursor: MySQLCursor,
    check_date: str,
    brand: str,
    currencys: list = [],
    game_codes: list = [],
    day_opt: str = "today",
) -> Tuple[Decimal, Decimal, int, Decimal]:
    """
    Get brand bets, net_win, players, and rounds.
    premonth stand for the-date-a-month-ago
    """

    stmt = "SELECT IFNULL(SUM(UG.bets/RPL.rate), 0), IFNULL(SUM(UG.net_wins/RPL.rate), 0), COUNT(DISTINCT UG.uid), IFNULL(SUM(UG.rounds), 0) "
    stmt += "FROM ( "
    stmt += "  SELECT uid, gid, SUM(total_bet) bets, SUM(total_bet - total_win) net_wins, SUM(total_round) rounds "
    stmt += "  FROM cypress.statistic_user_by_game "
    if day_opt == "yesterday":
        stmt += f"  WHERE date BETWEEN ('{check_date}' - INTERVAL 1 DAY) AND ('{check_date}' - INTERVAL 1 HOUR) "
    elif day_opt == "premonth":
        stmt += f"  WHERE date BETWEEN DATE_SUB('{check_date}', INTERVAL 1 MONTH) AND (DATE_SUB('{check_date}', INTERVAL 1 MONTH) + INTERVAL 23 HOUR) "
    else:
        stmt += f"  WHERE date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    stmt += "  GROUP BY uid, gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT uid, gid, SUM(total_bet) bets, SUM(total_rake + room_fee - total_win) net_wins, SUM(total_round) rounds "
    stmt += "  FROM cypress.statistic_user_by_tablegame "
    if day_opt == "yesterday":
        stmt += f"  WHERE date BETWEEN ('{check_date}' - INTERVAL 1 DAY) AND ('{check_date}' - INTERVAL 1 HOUR) "
    elif day_opt == "premonth":
        stmt += f"  WHERE date BETWEEN DATE_SUB('{check_date}', INTERVAL 1 MONTH) AND (DATE_SUB('{check_date}', INTERVAL 1 MONTH) + INTERVAL 23 HOUR) "
    else:
        stmt += f"  WHERE date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    stmt += "  GROUP BY uid, gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT uid, gid, SUM(total_bet) bets, SUM(total_bet - total_win) net_wins, SUM(total_bet_count) rounds "
    stmt += "  FROM cypress.statistic_user_by_lottogame "
    if day_opt == "yesterday":
        stmt += f"  WHERE date BETWEEN ('{check_date}' - INTERVAL 1 DAY) AND ('{check_date}' - INTERVAL 1 HOUR) "
    elif day_opt == "premonth":
        stmt += f"  WHERE date BETWEEN DATE_SUB('{check_date}', INTERVAL 1 MONTH) AND (DATE_SUB('{check_date}', INTERVAL 1 MONTH) + INTERVAL 23 HOUR) "
    else:
        stmt += f"  WHERE date BETWEEN '{check_date}' AND DATE_ADD('{check_date}', INTERVAL 23 HOUR) "
    stmt += "  GROUP BY uid, gid) UG "
    stmt += "JOIN cypress.user_list UL ON UG.uid = UL.id "
    stmt += "JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid "
    if currencys:
        stmt += f"AND (CASE WHEN RPL.currency = 'MMKP1' THEN 'MMK' ELSE REGEXP_REPLACE(RPL.currency, '([(].*[)])', '') END) IN ({str(currencys)[1:-1]}) "
    stmt += f"JOIN MaReport.game_info GI ON UG.gid = GI.gid AND GI.brand = '{brand}' "
    if game_codes:
        stmt += f"AND GI.game_code IN ({str(game_codes)[1:-1]}) "

    cursor.execute(stmt)
    _result: Tuple[Decimal, Decimal, int, Decimal] = cursor.fetchone()  # type: ignore
    logger.info(f"Get {brand} daily summary SUCCESS!")

    return _result
