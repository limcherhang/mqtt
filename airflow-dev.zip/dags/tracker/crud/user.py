import logging
from typing import Tuple, List
from decimal import Decimal
from mysql.connector.cursor import MySQLCursor
from decimal import Decimal

logger = logging.getLogger("airflow.task")


def get_news_with_high_net_win_n_game(
    cursor: MySQLCursor,
    start_time: str,
    end_time: str,
    reg_after_dt: str,
    net_win_threshold: int,
) -> List[Tuple[str, str, str, str, str, Decimal, int, Decimal]]:

    stmt = "SELECT CAST(PLO.account AS CHAR), CAST(PLP.account AS CHAR), CAST(UL.account AS CHAR),"
    stmt += "  UL.userid, GI.game_name_tw, SUM(UG.bets/FR.rate) bets, "
    stmt += "  SUM(UG.rounds) rounds, SUM(UG.net_win/FR.rate) net_wins "
    stmt += "FROM ("
    stmt += "  SELECT uid, gid, SUM(total_bet) bets, SUM(total_round) rounds, SUM(total_win-total_bet) net_win "
    stmt += "  FROM cypress.statistic_user_by_game "
    stmt += f" WHERE date < '{end_time}' AND date >= '{start_time}' "
    stmt += "  GROUP BY uid, gid "
    stmt += "  UNION ALL"
    stmt += "  SELECT uid, gid, SUM(total_bet) bets, SUM(total_round) rounds, SUM(total_win-total_rake-room_fee) net_win "
    stmt += "  FROM cypress.statistic_user_by_tablegame "
    stmt += f" WHERE date < '{end_time}' AND date >= '{start_time}' "
    stmt += "  GROUP BY uid, gid "
    stmt += "  UNION ALL"
    stmt += "  SELECT uid, gid, SUM(total_bet) bets, SUM(total_bet_count) rounds, SUM(total_win-total_bet) net_win "
    stmt += "  FROM cypress.statistic_user_by_lottogame "
    stmt += f" WHERE date < '{end_time}' AND date >= '{start_time}' "
    stmt += "  GROUP BY uid, gid ) UG "
    stmt += f"JOIN cypress.user_list UL ON UG.uid = UL.id AND UL.update_time >= '{reg_after_dt}' "
    stmt += "JOIN cypress.fx_rate FR ON UL.currency = FR.short_name "
    stmt += "JOIN cypress.parent_list PLP ON UL.parentid = PLP.id AND PLP.istestss = 0 "
    stmt += "JOIN cypress.parent_list PLO ON PLP.owner = PLO.ssid AND PLO.istestss = 0 "
    stmt += "JOIN MaReport.game_info GI ON UG.gid = GI.gid "
    stmt += "GROUP BY UG.uid, UG.gid "
    stmt += f"HAVING net_wins > {net_win_threshold};"

    cursor.execute(stmt)
    result = list(cursor)
    logger.info(f"Get game high net-win new(after {reg_after_dt}) players success")

    return result


def get_news_with_high_net_win(
    cursor: MySQLCursor,
    start_time: str,
    end_time: str,
    reg_after_dt: str,
    net_win_threshold: int,
) -> List[Tuple[str, str, str, str, Decimal, int, Decimal]]:

    stmt = "SELECT CAST(PLO.account AS CHAR), CAST(PLP.account AS CHAR), CAST(UL.account AS CHAR),"
    stmt += "  UL.userid, SUM(UG.bets/FR.rate) bets, SUM(UG.rounds) rounds, SUM(UG.net_win/FR.rate) net_wins "
    stmt += "FROM ("
    stmt += "  SELECT uid, gid, SUM(total_bet) bets, SUM(total_round) rounds, SUM(total_win-total_bet) net_win "
    stmt += "  FROM cypress.statistic_user_by_game "
    stmt += f" WHERE date < '{end_time}' AND date >= '{start_time}' "
    stmt += "  GROUP BY uid, gid "
    stmt += "  UNION ALL"
    stmt += "  SELECT uid, gid, SUM(total_bet) bets, SUM(total_round) rounds, SUM(total_win-total_rake-room_fee) net_win "
    stmt += "  FROM cypress.statistic_user_by_tablegame "
    stmt += f" WHERE date < '{end_time}' AND date >= '{start_time}' "
    stmt += "  GROUP BY uid, gid "
    stmt += "  UNION ALL"
    stmt += "  SELECT uid, gid, SUM(total_bet) bets, SUM(total_bet_count) rounds, SUM(total_win-total_bet) net_win "
    stmt += "  FROM cypress.statistic_user_by_lottogame "
    stmt += f" WHERE date < '{end_time}' AND date >= '{start_time}' "
    stmt += "  GROUP BY uid, gid ) UG "
    stmt += f"JOIN cypress.user_list UL ON UG.uid = UL.id AND UL.update_time >= '{reg_after_dt}' "
    stmt += "JOIN cypress.fx_rate FR ON UL.currency = FR.short_name "
    stmt += "JOIN cypress.parent_list PLP ON UL.parentid = PLP.id AND PLP.istestss = 0 "
    stmt += "JOIN cypress.parent_list PLO ON PLP.owner = PLO.ssid AND PLO.istestss = 0 "
    stmt += "JOIN MaReport.game_info GI ON UG.gid = GI.gid "
    stmt += "GROUP BY UG.uid "
    stmt += f"HAVING net_wins > {net_win_threshold};"

    cursor.execute(stmt)
    result = list(cursor)
    logger.info(f"Get total high net-win new(after {reg_after_dt}) players success")

    return result
