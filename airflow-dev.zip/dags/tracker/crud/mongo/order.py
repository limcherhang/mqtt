import logging
from typing import List
from datetime import datetime, timedelta
from typing import List
from bson.objectid import ObjectId
from pendulum.datetime import DateTime as pendulum_datetime
from pymongo import MongoClient
import pymongo

logger = logging.getLogger("airflow.task")


def get_motivation_bettype_info(
    mongo_cnx: MongoClient,
    start_time: pendulum_datetime,
    end_time: pendulum_datetime,
) -> List[dict]:
    """
    Get motivation bettype ans tableid
    """
    start_id = ObjectId.from_datetime(start_time)
    end_id = ObjectId.from_datetime(end_time)

    query = {
        "_id": {"$gte": start_id, "$lt": end_id},
        "gamecode": "GINKGO01",
    }
    field = [
        "tabletype",
        "tableid",
        "bettype",
    ]

    _result = list(mongo_cnx.order.order.find(query, field))
    logger.info(f"Get GINKGO01 bettype from {start_time} to {end_time} SUCCESS!")

    return _result


def get_by_bettime(
    mongo_cnx: MongoClient,
    end_time: datetime,
    interval_minute: int,
) -> List[dict]:

    start_time = end_time - timedelta(minutes=interval_minute)
    field = [
        "ownerid",
        "parentid",
        "account",
        "gametype",
        "genre",
        "gamecode",
        "roundid",
        "bets",
        "wins",
        "bettime",
        "currency",
    ]

    query = {"bettime": {"$gte": start_time, "$lt": end_time}}

    collection_by_bettime = list(mongo_cnx.order.orderlotto.find(query, field))
    logger.info(f"Get order collect by bettime from {start_time} to {end_time} sucess")

    return collection_by_bettime


def get_by_createtime(
    mongo_cnx: MongoClient,
    end_time: datetime,
    interval_minute: int,
) -> List[dict]:

    start_time = end_time - timedelta(minutes=interval_minute)
    field = [
        "ownerid",
        "parentid",
        "account",
        "gametype",
        "genre",
        "gamecode",
        "roundid",
        "bets",
        "wins",
        "createtime",
        "currency",
    ]

    query = {"createtime": {"$gte": start_time, "$lt": end_time}}

    collection_by_createtime = list(mongo_cnx.order.orderlotto.find(query, field))
    logger.info(
        f"Get order collect by createtime from {start_time} to {end_time} sucess"
    )

    return collection_by_createtime


def get_specific_bettype_hedge(
    mongo_cnx: MongoClient,
    start_time: pendulum_datetime,
    end_time: pendulum_datetime,
    table_type: str,
) -> List[dict]:
    """
    The data sources for hedge
    """
    start_id = ObjectId.from_datetime(start_time)
    end_id = ObjectId.from_datetime(end_time)

    pipeline = [
        {
            "$match": {
                "_id": {"$gte": start_id, "$lt": end_id},
                "gamecode": "CA01",
                "tabletype": table_type,
            }
        },
        {"$unwind": "$bettype"},
        {
            "$project": {
                "_id": 0,
                "account": 1,
                "parentid": 1,
                "playerid": 1,
                "roundnumber": 1,
                "bets": 1,
                "tableid": 1,
                "bettype": 1,
                "createtime": 1,
            }
        },
    ]

    _result = list(mongo_cnx.order.order.aggregate(pipeline, allowDiskUse=True))
    logger.info(f"Get CA01 table type={table_type} from {start_time} SUCCESS!")

    return _result


def get_motivation_order(
    mongo_cnx: MongoClient,
    start_time: pendulum_datetime,
    end_time: pendulum_datetime,
) -> List[dict]:
    """
    Get motivation order collect by createtime
    """
    start_id = ObjectId.from_datetime(start_time)
    end_id = ObjectId.from_datetime(end_time)

    query = {
        "_id": {"$gte": start_id, "$lt": end_id},
        "gamecode": "GINKGO01",
    }
    field = [
        "ownerid",
        "parentid",
        "account",
        "playerid",
        "tableid",
        "roundid",
        "currency",
        "bets",
        "wins",
    ]

    _result = list(mongo_cnx.order.order.find(query, field))
    logger.info(f"Get GINKGO01 order from {start_time} to {end_time} SUCCESS!")

    return _result


def get_motivation_order_sort_by_createtime(
    mongo_cnx: MongoClient, start_time: pendulum_datetime, end_time: pendulum_datetime
) -> List[dict]:
    """
    Get motivation order sort by createtime
    """
    start_id = ObjectId.from_datetime(start_time)
    end_id = ObjectId.from_datetime(end_time)

    query = {
        "_id": {"$gte": start_id, "$lt": end_id},
        "gamecode": "GINKGO01",
    }
    field = [
        "parentid",
        "account",
        "playerid" "tableid",
        "wins",
    ]

    _result = list(
        mongo_cnx.order.order.find(query, field).sort(
            [("createtime", pymongo.DESCENDING)]
        )
    )

    return _result


def get_player_daily_bet_win(
    mongo_cnx: MongoClient,
    start_time: pendulum_datetime,
    end_time: pendulum_datetime,
    playerid: str,
) -> List[dict]:
    """
    Get motivation player daily bet and daily win
    """
    start_id = ObjectId.from_datetime(start_time)
    end_id = ObjectId.from_datetime(end_time)

    query = {
        "_id": {"$gte": start_id, "$lt": end_id},
        "gamecode": "GINKGO01",
        "playerid": playerid,
    }
    field = [
        "bets",
        "wins",
    ]

    _res = list(mongo_cnx.order.order.find(query, field))

    logger.info(
        f"Get {playerid} GINKGO01 daily bets and wins from {start_time} to {end_time} SUCCESS!"
    )

    return _res
