import logging
from typing import Tuple, List
from decimal import Decimal
from mysql.connector.cursor import MySQLCursor

logger = logging.getLogger("airflow.task")


def get_info(cursor: MySQLCursor) -> List[Tuple[str, str, str, Decimal]]:

    stmt = "SELECT PLP.ssid, CAST(PLP.account AS CHAR), CAST(PLO.account AS CHAR), FR.rate "
    stmt += "FROM cypress.parent_list PLP "
    stmt += "JOIN cypress.parent_list PLO ON PLP.owner=PLO.ssid AND PLO.istestss = 0 "
    stmt += "JOIN cypress.fx_rate FR ON PLP.currency = FR.short_name "
    stmt += "WHERE PLP.istestss = 0 "

    cursor.execute(stmt)
    result = list(cursor)
    logger.info("Get agent info SUCCESS")

    return result
