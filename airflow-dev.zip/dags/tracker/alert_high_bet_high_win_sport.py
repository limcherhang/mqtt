import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from datetime import timedelta, datetime
import logging

from utils.connection.mysql import mysql_cursor
from airflow.providers.mongo.hooks.mongo import MongoHook
from tracker.crud import agent
from tracker.crud.mysql import game
from tracker.crud.mongo import order
from utils.tools import teamplus_message

from airflow.models import Variable
from airflow.decorators import dag, task

logger = logging.getLogger("airflow.task")

default_args = {
    "depends_on_past": False,
    "email": ["aaron5139@adcrow.tech"],
    "email_on_failure": True,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(seconds=10),
}


@dag(
    start_date=pendulum.datetime(2023, 1, 5, tz="UTC"),
    schedule="*/5 * * * *",
    default_args=default_args,
    catchup=False,
    max_active_tasks=4,
    tags=["PRO", "cq9", "tracker"],
)
def alert_high_bet_high_win_sport():
    """
    ### HIGH BET AND HIGH WIN FOR SPORT
    Send alert to team+
    """

    @task()
    def alert_high_bet_n_high_win_sport(
        data_interval_end: pendulum_datetime = pendulum.now(),
        data_interval: int = 5,
    ):
        _CFG = Variable.get("TRACKER_ALERT", deserialize_json=True)
        _NEW_CFG = _CFG.get("ALERT_HIGHBET_N_HIGHWIN_SPORT", {})
        HIGHBET_THRESHOLD = _NEW_CFG.get("HIGHBET_THRESHOLD")
        MULTIPLE_THRESHOLD = _NEW_CFG.get("MULTIPLE_THRESHOLD")
        HIGHBET_CHAT = _NEW_CFG.get("HIGHBET_CHAT")
        HIGHWIN_CHAT = _NEW_CFG.get("HIGHWIN_CHAT")

        insert_date = datetime.fromtimestamp(
            pendulum.datetime(
                data_interval_end.year,
                data_interval_end.month,
                data_interval_end.day,
                data_interval_end.hour,
                data_interval_end.minute,
                tz=data_interval_end.tz,
            ).timestamp(),
            tz=pendulum.tz.UTC,
        )

        logger.info(
            f"Alert tracking from {insert_date-timedelta(minutes=data_interval)} to {insert_date}"
        )
        with (
            mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor,
            MongoHook(conn_id="mongo_read") as mongo_hook,
        ):
            parent_list = {}
            for (ssid, _parent, _owner, _rate) in agent.get_info(cursor):
                parent_list[ssid] = {
                    "parent": _parent,
                    "owner": _owner,
                    "rate": float(_rate),
                }
            game_info = {}
            for (game_name_en, gamecode) in game.get_info(cursor):
                game_info[gamecode] = game_name_en

            mongo_cnx = mongo_hook.get_conn()
            collection_by_bettime = order.get_by_bettime(
                mongo_cnx, insert_date, data_interval
            )

            for res in collection_by_bettime:
                parentid = res.get("parentid")
                gamecode = res.get("gamecode")
                rate = parent_list[parentid].get("rate")
                if res["bets"] / rate > HIGHBET_THRESHOLD and parent_list.get(parentid):
                    msg = f"type : bet >= {HIGHBET_THRESHOLD:,}\n"
                    msg += f"owner : {parent_list[parentid].get('owner')}\n"
                    msg += f"parent : {parent_list[parentid].get('parent')}\n"
                    msg += f"account : {res['account']}\n"
                    msg += f"gametype : {res['gametype']}\n"
                    msg += f"genre : {res.get('genre')}\n"
                    msg += f"game : {game_info.get(gamecode)}\n"
                    msg += f"roundid : {res.get('roundid')}\n"
                    msg += f"bets : {res.get('bets', 0)/rate:,.2f}\n"
                    msg += f"wins : {res.get('wins', 0)/rate:,.2f}\n"
                    msg += f"bettime : {res.get('bettime')}"

                    teamplus_message(HIGHBET_CHAT, msg)

            collection_by_createtime = order.get_by_createtime(
                mongo_cnx, insert_date, data_interval
            )

            for res in collection_by_createtime:
                parentid = res.get("parentid")
                gamecode = res.get("gamecode")
                rate = parent_list[parentid].get("rate")
                if res["wins"] / res["bets"] >= MULTIPLE_THRESHOLD and parent_list.get(
                    parentid
                ):
                    msg = f"type : win >= bet * {MULTIPLE_THRESHOLD}\n"
                    msg += f"owner : {parent_list[parentid].get('owner')}\n"
                    msg += f"parent : {parent_list[parentid].get('parent')}\n"
                    msg += f"account : {res.get('account')}\n"
                    msg += f"gametype : {res.get('gametype')}\n"
                    msg += f"genre : {res.get('genre')}\n"
                    msg += f"game : {game_info.get(gamecode)}\n"
                    msg += f"roundid : {res.get('roundid')}\n"
                    msg += f"bets : {res.get('bets', 0)/rate:,.2f}\n"
                    msg += f"wins : {res.get('wins', 0)/rate:,.2f}\n"
                    msg += f"createtime : {res.get('createtime')}"

                    teamplus_message(HIGHWIN_CHAT, msg)

    alert_high_bet_n_high_win_sport()


alert_high_bet_high_win_sport_dag = alert_high_bet_high_win_sport()
