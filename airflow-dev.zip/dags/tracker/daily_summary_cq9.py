from typing import Dict, Any
import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from datetime import timedelta
import logging

from utils.connection.mysql import mysql_cursor
from utils.connection.da_api import DAAPIHook
from tracker.crud import summary

from airflow.decorators import dag, task
from utils.tools import teamplus_message
from airflow.models import Variable
from tracker.src import sender, tools

logger = logging.getLogger("airflow.task")

default_args = {
    "depends_on_past": False,
    "email": ["rmpeter0474@adcrow.tech"],
    "email_on_failure": True,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(seconds=10),
}


@dag(
    start_date=pendulum.datetime(2022, 10, 12, tz="UTC"),
    schedule="10 0 * * *",
    default_args=default_args,
    catchup=False,
    max_active_tasks=4,
    tags=["PRO", "cq9", "tracker"],
)
def daily_summary_cq9():
    """
    ### Cq9 Daily Summary
    Send summary to team+ and store to DA-API
    """

    @task()
    def get_day_and_currecny_summary(
        data_interval_start: pendulum_datetime = pendulum.now(),
    ) -> Any:
        """
        ### Get the day summary and day-summary by currency
        """
        check_date_str = data_interval_start.format("YYYY-MM-DD")
        brand = "cq9"

        with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
            # by day summary
            today_summary = summary.get_daily(cursor, check_date_str, brand)
            logger.debug(f"Today: {today_summary}")
            yesterday_summary = summary.get_daily(
                cursor, check_date_str, brand, day_opt="yesterday"
            )
            logger.debug(f"Yesterday: {yesterday_summary}")
            premonth_summary = summary.get_daily(
                cursor, check_date_str, brand, day_opt="premonth"
            )
            logger.debug(f"Premonth: {premonth_summary}")
            # by day, currency summary
            currency_summary = summary.get_daily_of_currencys(
                cursor, check_date_str, brand
            )
            logger.debug(f"Currency: {currency_summary}")

        return {  # type: ignore
            "check_date_str": check_date_str,
            "today_summary": today_summary,
            "yesterday_summary": yesterday_summary,
            "premonth_summary": premonth_summary,
            "currency_summary": currency_summary,
        }

    @task()
    def teamplus_summary_message(
        day_summary: Dict,
    ):
        """
        Send summary message to TeamPlus
        """
        brand = "cq9"
        check_date_str = day_summary["check_date_str"]
        today_bet, _, today_player, today_round = day_summary["today_summary"]
        yesterday_bet, _, yesterday_player, yesterday_round = day_summary[
            "yesterday_summary"
        ]
        premonth_bet, _, premonth_player, premonth_round = day_summary[
            "premonth_summary"
        ]
        _CFG = Variable.get("TRACKER_SUMMARY", deserialize_json=True)

        # Daily dummary with growth rate
        msg = f"品牌：{brand} \n"
        msg += f"日期：{check_date_str} \n"
        msg += "\n"
        msg += f"碼量：{float(today_bet):,.0f} \n"
        msg += f"前一日碼量：{float(yesterday_bet):,.0f} \n"
        msg += f"成長率：{tools.growth_rate(today_bet, yesterday_bet) * 100:.0f}% \n"
        msg += f"上個月碼量：{float(premonth_bet):,.0f} \n"
        msg += f"成長率：{tools.growth_rate(today_bet, premonth_bet) * 100:.0f}% \n"
        msg += "\n"
        msg += f"不重複人數：{int(today_player):,} \n"
        msg += f"前一日不重複人數：{int(yesterday_player):,} \n"
        msg += f"成長率：{tools.growth_rate(today_player, yesterday_player) * 100:.0f}% \n"
        msg += f"上個月不重複人數：{int(premonth_player):,} \n"
        msg += f"成長率：{tools.growth_rate(today_player, premonth_player) * 100:.0f}% \n"
        msg += "\n"
        msg += f"單量：{int(today_round):,} \n"
        msg += f"前一日單量：{int(yesterday_round):,} \n"
        msg += f"成長率：{tools.growth_rate(today_round, yesterday_round) * 100:.0f}% \n"
        msg += f"上個月單量：{int(premonth_player):,} \n"
        msg += f"成長率：{tools.growth_rate(today_round, premonth_round) * 100:.0f}% \n"

        teamplus_message(_CFG.get("TEAMPLUS_CHAT", []), msg)

        # Daily summary by currency
        currency_summary = day_summary["currency_summary"]
        post_cur = _CFG.get("POST_CUR")
        _CURRENCY_TW = Variable.get("CURRENCY_TW", deserialize_json=True)
        msg = f"品牌：{brand} \n"
        msg += f"日期：{check_date_str} \n"
        for _currency in post_cur:
            msg += "\n"
            msg += f"幣別: {_currency}({_CURRENCY_TW.get(_currency)})\n"

            _bet, _, _player, _ = currency_summary.get(_currency, (0, 0, 0, 0))
            msg += f"碼量：{_bet:,.0f} \n"
            msg += f"不重複人數：{_player:,.0f} \n"

        teamplus_message(_CFG.get("TEAMPLUS_CHAT", []), msg)

    @task()
    def add_and_update_to_api(
        day_summary: Dict,
    ):
        import schemas

        _CFG = Variable.get("TRACKER_SUMMARY", deserialize_json=True)
        brand = "cq9"
        check_date_str = day_summary["check_date_str"]
        with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
            _played_registered_player, _ = summary.get_played_registered_user_count(
                cursor, check_date_str, brand
            )
            (
                _pre_month_bet,
                _,
                _pre_month_date_counts,
                _,
            ) = summary.get_daily_by_currency(
                cursor, check_date_str, brand, day_opt="premonth"
            )
            _pre_month_avg_bet = tools.divide_no_zero(
                _pre_month_bet, _pre_month_date_counts
            )
        _registered_player = 0  # calculation is time-consuming
        _bets, _net_wins, _players, _rounds = day_summary["today_summary"]
        performance_in = schemas.SalesPerformance.parse_obj(
            dict(
                date=check_date_str,
                brand=brand,
                bet=_bets,
                net_win=_net_wins,
                player=_players,
                registered_player=_registered_player,
                played_registered_player=_played_registered_player,
                rounds=_rounds,
            )
        )
        hook = DAAPIHook()
        hook.add_performance(performance_in.json(), check_response=False)
        sender.notify_performance_alarm(
            date=check_date_str,
            brand=brand,
            currency="ALL",
            today_bets=_bets,
            pre_month_avg_bet=_pre_month_avg_bet,
            hook=hook,
            _config=_CFG,
        )

        sys_query_currency = _CFG.get("API_CUR")
        query_gametypes = _CFG.get("GAMETYPE", [])
        currency_summary = day_summary["currency_summary"]
        top_range = _CFG.get("TOP_RANGE")
        for _currency, _info in currency_summary.items():

            if _currency not in sys_query_currency:
                continue
            with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
                _bets, _net_wins, _players, _rounds = _info
                _yesterday_bet, _, _, _ = summary.get_daily_by_currency(
                    cursor, check_date_str, brand, _currency, day_opt="yesterday"
                )
                (
                    _pre_month_bet,
                    _,
                    _pre_month_date_counts,
                    _,
                ) = summary.get_daily_by_currency(
                    cursor, check_date_str, brand, _currency, day_opt="premonth"
                )
                _pre_month_avg_bet = tools.divide_no_zero(
                    _pre_month_bet, _pre_month_date_counts
                )

                performance_in = schemas.SalesPerformanceCurrency.parse_obj(
                    dict(
                        date=check_date_str,
                        brand=brand,
                        currency=_currency,
                        bet=_bets,
                        pre_bet=_yesterday_bet,
                        pre_month_avg_bet=_pre_month_avg_bet,
                        net_win=_net_wins,
                        player=_players,
                        rounds=_rounds,
                    )
                )
                logger.debug(performance_in)
                hook.add_performance_by_currency(
                    performance_in.json(), check_response=False
                )
                sender.notify_performance_alarm(
                    date=check_date_str,
                    brand=brand,
                    currency=_currency,
                    today_bets=_bets,
                    pre_month_avg_bet=_pre_month_avg_bet,
                    hook=hook,
                    _config=_CFG,
                )

                # Get By-Currency top 10 agent
                today_top_owner = summary.get_date_top_owner(
                    cursor, check_date_str, brand, _currency, top_range=top_range
                )
                logger.debug(f"{_currency} top owner: {today_top_owner}")
                for (_owner, _oid, _bets, _rounds, _rank) in today_top_owner:
                    (_yesterday_bet, _yesterday_rounds,) = summary.get_owner_yesterday(
                        cursor, check_date_str, brand, _oid, _currency
                    )
                    (
                        _pre_month_bet,
                        _pre_month_rounds,
                        _pre_month_date_counts,
                    ) = summary.get_owner_pre_month(
                        cursor, check_date_str, brand, _oid, _currency
                    )
                    _pre_month_avg_bet = tools.divide_no_zero(
                        _pre_month_bet, _pre_month_date_counts
                    )
                    performance_in = schemas.SalesPerformanceTopBet.parse_obj(
                        dict(
                            date=check_date_str,
                            brand=brand,
                            currency=_currency,
                            name=_owner,
                            top_type="agent",
                            code=_oid,
                            rank=_rank,
                            bet=_bets,
                            pre_bet=_yesterday_bet,
                            pre_month_avg_bet=_pre_month_avg_bet,
                            bet_day_diff=_bets - _yesterday_bet,
                            bet_month_avg_diff=_bets - _pre_month_avg_bet,
                            rounds=_rounds,
                        )
                    )
                    hook.add_performance_by_top_bet(
                        performance_in.json(), check_response=False
                    )

                # Get By-Currency top 10 game
                today_top_game = summary.get_date_top_game(
                    cursor, check_date_str, brand, _currency, top_range=top_range
                )
                logger.debug(f"{_currency} top game: {today_top_game}")
                for (_game, _gid, _bets, _rounds, _rank) in today_top_game:
                    (_yesterday_bet, _yesterday_rounds,) = summary.get_game_yesterday(
                        cursor, check_date_str, brand, _gid, _currency
                    )
                    (
                        _pre_month_bet,
                        _pre_month_rounds,
                        _pre_month_date_counts,
                    ) = summary.get_game_pre_month(
                        cursor, check_date_str, brand, _gid, _currency
                    )
                    _pre_month_avg_bet = tools.divide_no_zero(
                        _pre_month_bet, _pre_month_date_counts
                    )
                    performance_in = schemas.SalesPerformanceTopBet.parse_obj(
                        dict(
                            date=check_date_str,
                            brand=brand,
                            currency=_currency,
                            name=_game,
                            top_type="game",
                            code=_gid,
                            rank=_rank,
                            bet=_bets,
                            pre_bet=_yesterday_bet,
                            pre_month_avg_bet=_pre_month_avg_bet,
                            bet_day_diff=_bets - _yesterday_bet,
                            bet_month_avg_diff=_bets - _pre_month_avg_bet,
                            rounds=_rounds,
                        )
                    )
                    hook.add_performance_by_top_bet(
                        performance_in.json(), check_response=False
                    )

                # Get By-Currency gametype
                for _gametype in query_gametypes:
                    _today_bet, _, _today_round = summary.get_gametype(
                        cursor,
                        check_date_str,
                        brand,
                        _gametype,
                        _currency,
                        day_opt="today",
                    )
                    (_yesterday_bet, _, _yesterday_round,) = summary.get_gametype(
                        cursor,
                        check_date_str,
                        brand,
                        _gametype,
                        _currency,
                        day_opt="yesterday",
                    )
                    (_pre_month_bet, _counts, _pre_month_round,) = summary.get_gametype(
                        cursor,
                        check_date_str,
                        brand,
                        _gametype,
                        _currency,
                        day_opt="premonth",
                    )
                    _bet_day_diff = _today_bet - _yesterday_bet
                    _pre_month_avg_bet = tools.divide_no_zero(_pre_month_bet, _counts)
                    _bet_month_avg_diff = _today_bet - _pre_month_avg_bet

                    performance_in = schemas.SalesPerformanceGametype.parse_obj(
                        dict(
                            date=check_date_str,
                            brand=brand,
                            currency=_currency,
                            gametype=_gametype,
                            bet=_today_bet,
                            pre_bet=_yesterday_bet,
                            pre_month_avg_bet=_pre_month_avg_bet,
                            bet_day_diff=_bet_day_diff,
                            bet_month_avg_diff=_bet_month_avg_diff,
                            rounds=_today_round,
                        )
                    )
                    hook.add_performance_by_gametype(
                        performance_in.json(), check_response=False
                    )
                    sender.notify_performance_alarm(
                        date=check_date_str,
                        brand=brand,
                        currency=_currency,
                        gametype=_gametype,
                        today_bets=_today_bet,
                        pre_month_avg_bet=_pre_month_avg_bet,
                        hook=hook,
                        _config=_CFG,
                    )

        with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
            # Get ALL gametype
            for _gametype in query_gametypes:
                _today_bet, _, _today_round = summary.get_gametype(
                    cursor, check_date_str, brand, _gametype, day_opt="today"
                )
                _yesterday_bet, _, _yesterday_round = summary.get_gametype(
                    cursor, check_date_str, brand, _gametype, day_opt="yesterday"
                )
                (_pre_month_bet, _counts, _pre_month_round,) = summary.get_gametype(
                    cursor, check_date_str, brand, _gametype, day_opt="premonth"
                )
                _bet_day_diff = _today_bet - _yesterday_bet
                _pre_month_avg_bet = tools.divide_no_zero(_pre_month_bet, _counts)
                _bet_month_avg_diff = _today_bet - _pre_month_avg_bet
                performance_in = schemas.SalesPerformanceGametype.parse_obj(
                    dict(
                        date=check_date_str,
                        brand=brand,
                        currency="ALL",
                        gametype=_gametype,
                        bet=_today_bet,
                        pre_bet=_yesterday_bet,
                        pre_month_avg_bet=_pre_month_avg_bet,
                        bet_day_diff=_bet_day_diff,
                        bet_month_avg_diff=_bet_month_avg_diff,
                        rounds=_today_round,
                    )
                )
                hook.add_performance_by_gametype(
                    performance_in.json(), check_response=False
                )

            # Get ALL top 10 agent
            today_top_owner = summary.get_date_top_owner(
                cursor, check_date_str, brand, top_range=top_range
            )
            logger.debug(f"All top agent: {today_top_owner}")
            for (_owner, _oid, _bets, _rounds, _rank) in today_top_owner:
                (
                    _yesterday_bet,
                    _yesterday_rounds,
                ) = summary.get_owner_yesterday(cursor, check_date_str, brand, _oid)
                (
                    _pre_month_bet,
                    _pre_month_rounds,
                    _pre_month_date_counts,
                ) = summary.get_owner_pre_month(cursor, check_date_str, brand, _oid)
                logger.debug(
                    f"{_pre_month_bet}, {_pre_month_rounds}, {_pre_month_date_counts}"
                )
                _pre_month_avg_bet = tools.divide_no_zero(
                    _pre_month_bet, _pre_month_date_counts
                )
                performance_in = schemas.SalesPerformanceTopBet.parse_obj(
                    dict(
                        date=check_date_str,
                        brand=brand,
                        currency="ALL",
                        name=_owner,
                        top_type="agent",
                        code=_oid,
                        rank=_rank,
                        bet=_bets,
                        pre_bet=_yesterday_bet,
                        pre_month_avg_bet=_pre_month_avg_bet,
                        bet_day_diff=_bets - _yesterday_bet,
                        bet_month_avg_diff=_bets - _pre_month_avg_bet,
                        rounds=_rounds,
                    )
                )
                hook.add_performance_by_top_bet(
                    performance_in.json(), check_response=False
                )

            # Get ALL top 10 game
            today_top_game = summary.get_date_top_game(
                cursor, check_date_str, brand, top_range=top_range
            )
            logger.debug(f"All top game: {today_top_game}")
            for (_game, _gid, _bets, _rounds, _rank) in today_top_game:
                (
                    _yesterday_bet,
                    _yesterday_rounds,
                ) = summary.get_game_yesterday(cursor, check_date_str, brand, _gid)
                logger.debug(f"{_bets-_yesterday_bet}, {_yesterday_rounds}")
                (
                    _pre_month_bet,
                    _pre_month_rounds,
                    _pre_month_date_counts,
                ) = summary.get_game_pre_month(cursor, check_date_str, brand, _gid)
                logger.debug(
                    f"{_pre_month_bet}, {_pre_month_rounds}, {_pre_month_date_counts}"
                )
                _pre_month_avg_bet = tools.divide_no_zero(
                    _pre_month_bet, _pre_month_date_counts
                )
                performance_in = schemas.SalesPerformanceTopBet.parse_obj(
                    dict(
                        date=check_date_str,
                        brand=brand,
                        currency="ALL",
                        name=_game,
                        top_type="game",
                        code=_gid,
                        rank=_rank,
                        bet=_bets,
                        pre_bet=_yesterday_bet,
                        pre_month_avg_bet=_pre_month_avg_bet,
                        bet_day_diff=_bets - _yesterday_bet,
                        bet_month_avg_diff=_bets - _pre_month_avg_bet,
                        rounds=_rounds,
                    )
                )
                hook.add_performance_by_top_bet(
                    performance_in.json(), check_response=False
                )

            # SP game
            for game, info in _CFG.get("SP_GAME").items():
                if not brand.upper() in info:
                    continue
                logger.info(f"Get game: {game} under brand {brand}")
                sp_game_code = info[brand.upper()]
                sp_game_name = info["NAME"]
                sp_game_type = info["TYPE"]
                (_bets, _net_wins, _rounds, _players,) = summary.get_game_by_code(
                    cursor, check_date_str, sp_game_code, sp_game_type
                )
                performance_in = schemas.SalesSpecifyProject.parse_obj(
                    dict(
                        date=check_date_str,
                        brand=brand,
                        currency="ALL",
                        project=sp_game_name,
                        span="day",
                        code=sp_game_code,
                        bet=_bets,
                        net_win=_net_wins,
                        player=_players,
                        rounds=_rounds,
                    )
                )
                logger.debug(performance_in)
                hook.add_specify_game(performance_in.json(), check_response=False)
                if game == "MOTIVATION":
                    sender.teamplus_motivation_with_top_owners(
                        brand,
                        sp_game_code,
                        sp_game_name,
                        sp_game_type,
                        _bets,
                        check_date_str,
                        cursor,
                        _CFG.get("TEAMPLUS_MOTIVATION_CHAT"),
                    )
                if _bets == 0:
                    continue
                sp_spreadsheet_id = info.get("SPREADSHEET_ID")
                if sp_spreadsheet_id:
                    sender.google_sheet_append_sp_game_values(
                        "PRO",
                        check_date_str,
                        _bets,
                        _net_wins,
                        _rounds,
                        _players,
                        sp_spreadsheet_id,
                    )
                sp_spreadsheet_id = info.get("BY_OWNER_SPREADSHEET_ID")
                if sp_spreadsheet_id:
                    sender.google_sheet_append_sp_game_by_owner_values(
                        "PRO",
                        check_date_str,
                        sp_game_code,
                        sp_game_type,
                        sp_spreadsheet_id,
                        cursor,
                    )

                (_bets, _net_wins, _rounds, _players,) = summary.get_game_month_by_code(
                    cursor, check_date_str, sp_game_code, sp_game_type
                )
                if _bets == 0:
                    continue
                key = schemas.SalesSpecifyProjectKey.parse_obj(
                    dict(
                        date=check_date_str[:8] + "01",
                        brand=brand,
                        currency="ALL",
                        project=sp_game_name,
                        span="month",
                    )
                )
                info = hook.get_specify_project(key.dict(), check_response=False)
                performance_in = {
                    "bet": _bets,
                    "net_win": _net_wins,
                    "player": _players,
                    "rounds": _rounds,
                }
                if 233 > info.status_code >= 200:
                    hook.update_specify_game(
                        key.json(),
                        schemas.SalesSpecifyProjectUpdate.parse_obj(
                            performance_in
                        ).json(exclude_unset=True, exclude_none=True),
                        check_response=False,
                    )
                else:
                    performance_in["code"] = sp_game_code
                    performance_in.update(key.dict())
                    hook.add_specify_game(
                        schemas.SalesSpecifyProject.parse_obj(performance_in).json(),
                        check_response=False,
                    )

        hook.maintain_performance_size()
        if _CFG.get("IS_CQ9", False):
            hook.notify_performance_update()

    day_with_currency_summary = get_day_and_currecny_summary()
    teamplus_summary_message(day_with_currency_summary)
    add_and_update_to_api(day_with_currency_summary)


daily_summary_cq9_dag = daily_summary_cq9()
