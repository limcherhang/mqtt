import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from datetime import timedelta
import logging

from utils.connection.mysql import mysql_cursor
from utils.connection.da_api import DAAPIHook
from tracker.crud import summary
from utils.tools import teamplus_message

from airflow.decorators import dag, task
from airflow.models import Variable

logger = logging.getLogger("airflow.task")

default_args = {
    "depends_on_past": False,
    "email": ["rmpeter0474@adcrow.tech"],
    "email_on_failure": True,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(seconds=10),
}


@dag(
    start_date=pendulum.datetime(2022, 10, 12, tz="UTC"),
    schedule="5 0 * * *",
    default_args=default_args,
    catchup=False,
    max_active_tasks=4,
    tags=["PRO", "lego", "tracker"],
)
def daily_summary_lego():
    """
    ### Lego Daily Summary
    Send summary to team+ and store to DA-API
    """

    @task()
    def add_and_update_to_api(
        data_interval_start: pendulum_datetime = pendulum.now(),
    ):
        import schemas

        _CFG = Variable.get("TRACKER_SUMMARY", deserialize_json=True)
        check_date_str = data_interval_start.format("YYYY-MM-DD")
        brand = "Lego"
        teamplus_chats = _CFG.get("LEGO_TEAMPLUS_CHAT", 832)

        hook = DAAPIHook()
        with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
            for project_name, project in _CFG.get("LEGO_BRANDS", {}).items():
                bet_infos = summary.get_lego_summary(cursor, check_date_str, project)
                player_count = 0
                bets = 0
                rounds = 0
                net_wins = 0
                if bet_infos:
                    bets, net_wins, rounds, player_count = bet_infos

                msg = f"日期: {check_date_str} \n"
                msg += f"品牌: {brand} \n"
                msg += f"專案: {project_name} \n"
                msg += f"總碼量(CNY): {bets:,.0f} \n"
                msg += f"不重複人數: {player_count:,d} \n"

                teamplus_message(teamplus_chats, msg)
                performance_in = schemas.SalesSpecifyProject.parse_obj(
                    dict(
                        date=check_date_str,
                        brand="lego",
                        currency="ALL",
                        project=project,
                        span="day",
                        bet=bets,
                        net_win=net_wins,
                        player=player_count,
                        rounds=rounds,
                    )
                )
                logger.debug(performance_in)
                hook.add_specify_project(performance_in.json(), check_response=False)
                if bets == 0:
                    continue

                bet_infos = summary.get_lego_summary(
                    cursor, check_date_str, project, day_opt="cumonth"
                )
                bets = 0
                if bet_infos:
                    bets, net_wins, rounds, player_count = bet_infos
                if bets == 0:
                    continue

                key = schemas.SalesSpecifyProjectKey.parse_obj(
                    dict(
                        date=check_date_str[:8] + "01",
                        brand="lego",
                        currency="ALL",
                        project=project,
                        span="month",
                    )
                )
                info = hook.get_specify_project(key.dict(), check_response=False)
                performance_in = {
                    "bet": bets,
                    "net_win": net_wins,
                    "player": player_count,
                    "rounds": rounds,
                }
                if 299 > info.status_code >= 200:
                    hook.update_specify_project(
                        key.json(),
                        schemas.SalesSpecifyProjectUpdate.parse_obj(
                            performance_in
                        ).json(exclude_unset=True, exclude_none=True),
                        check_response=False,
                    )
                else:
                    performance_in.update(key.dict())
                    hook.add_specify_project(
                        schemas.SalesSpecifyProject.parse_obj(performance_in).json(),
                        check_response=False,
                    )

    add_and_update_to_api()


daily_summary_lego_dag = daily_summary_lego()
