import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from datetime import timedelta
import logging

from airflow.providers.mongo.hooks.mongo import MongoHook
from utils.connection.mysql import mysql_cursor
from tracker.crud.mongo import order
from tracker.crud import agent
from utils.tools import teamplus_message

from airflow.decorators import dag, task
from airflow.models import Variable

logger = logging.getLogger("airflow.task")

default_args = {
    "depends_on_past": False,
    "email": ["rmpeter0474@adcrow.tech"],
    "email_on_failure": True,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(seconds=10),
}


@dag(
    start_date=pendulum.datetime(2023, 1, 4, tz="UTC"),
    schedule="*/15 * * * *",
    default_args=default_args,
    catchup=False,
    max_active_tasks=4,
    tags=["PRO", "cq9", "tracker"],
)
def on_specify_hedge():
    """
    ### On Specify Hedge
    CA01 specific bettype hedge status and send alert to team+
    """

    @task()
    def alert(
        data_interval_end: pendulum_datetime = pendulum.now(),
        data_interval_start: pendulum_datetime = pendulum.now(),
    ):
        import pandas as pd

        conti_threshold = 3
        _CFG = Variable.get("TRACKER_ALERT", deserialize_json=True)

        bettypes = [
            "1",
            "11",
            "2",
            "11",
            "2,3,4,5",
            "1,3,4,5",
            "2,3,4",
            "1,3,4",
            "2,3",
            "1,3",
            "2,4,5",
            "1,4,5",
            "2,5",
            "1,5",
            "9",
            "10",
        ]
        bettypes_comb = [
            ("1", "11"),
            ("1", "2"),
            ("11", "2"),
            ("2,3,4,5", "1"),
            ("1,3,4,5", "2"),
            ("2,3,4", "1"),
            ("1,3,4", "2"),
            ("2,3", "1"),
            ("1,3", "2"),
            ("2,4,5", "1"),
            ("1,4,5", "2"),
            ("2,5", "1"),
            ("1,5", "2"),
            ("9", "10"),
        ]
        table_types = ["1", "4"]
        msg = ""
        for table_type in table_types:
            order_df = []
            with MongoHook(conn_id="mongo_read") as mongo_hook:
                mongo_cnx = mongo_hook.get_conn()
                order_df = order.get_specific_bettype_hedge(
                    mongo_cnx, data_interval_start, data_interval_end, table_type
                )

            if not order_df:
                logger.info(
                    f"There is not any specific hedge players at table type={table_type} from order! \n"
                )
                continue

            # get concat bet type and sum bets
            order_df = pd.DataFrame(order_df)

            # join result_con and result_bet
            bettype_bet_df = pd.merge(
                order_df.groupby(
                    ["account", "parentid", "roundnumber", "tableid", "createtime"]
                )["bettype"]
                .apply(",".join)
                .reset_index(),
                order_df.groupby(["account", "parentid", "roundnumber", "tableid"])
                .agg({"bets": "sum"})
                .reset_index(),  # type: ignore
                on=["account", "parentid", "roundnumber", "tableid"],
            )

            players = bettype_bet_df["account"].unique().tolist()

            # get continue at least 3 times bet type in bettype_check
            result = pd.DataFrame()
            for player in players:
                player_bettype = bettype_bet_df.loc[bettype_bet_df["account"] == player]
                player_bettype = player_bettype.sort_values(
                    ["createtime"], ascending=True
                )

                player_bettype["type_in"] = player_bettype["bettype"].apply(
                    lambda x: 1 if x in bettypes else 0
                )
                player_bettype["counter"] = (player_bettype["type_in"] == 0).cumsum()
                player_bettype = player_bettype[player_bettype["type_in"] != 0]
                counter_count = player_bettype.groupby("counter")["roundnumber"].count()
                result_count = player_bettype[
                    player_bettype["counter"].isin(
                        counter_count[counter_count >= conti_threshold].index
                    )
                ]

                result = pd.concat([result, result_count], ignore_index=True)

            result.drop(columns=["type_in", "counter"], inplace=True)
            logger.info(
                f"Get players who's bet type in bettype_check and continue at least {conti_threshold} times SUCCESS"
            )

            # combine parent info
            parent_info = []
            with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
                parent_info = agent.get_info(cursor)
            parent_info = pd.DataFrame(
                parent_info, columns=["parentid", "parent", "owner", "rate"]
            )
            result_ui = pd.merge(result, parent_info, on=["parentid"], how="inner")

            result_ui["bets"] = result_ui["bets"].astype("float") / result_ui[
                "rate"
            ].astype("float")
            result_ui.drop(columns=["rate"], inplace=True)

            result_join = pd.merge(
                result_ui,
                result_ui,
                on=["roundnumber", "tableid"],
                how="inner",
                suffixes=("_1", "_2"),
            )
            result_final = result_join.loc[
                result_join["account_1"] != result_join["account_2"]
            ]

            logger.info("Combine parent info with result SUCCESS")

            # get bettypes in bettypes_comb
            players = result_final["account_1"].unique().tolist()
            result_final["type_tuple"] = ""
            for index, row in result_final.iterrows():
                a = row["bettype_1"]
                b = row["bettype_2"]
                result_final["type_tuple"][index] = (a, b)

            result_tuple = pd.DataFrame()
            for player in players:
                player_bettype = result_final.loc[result_final["account_1"] == player]
                player_bettype = player_bettype.sort_values(
                    ["createtime_1"], ascending=True
                )

                player_bettype["type_in"] = player_bettype["type_tuple"].apply(
                    lambda x: 1 if x in bettypes_comb else 0
                )
                player_bettype["counter"] = (player_bettype["type_in"] == 0).cumsum()
                player_bettype = player_bettype[player_bettype["type_in"] != 0]
                counter_count = player_bettype.groupby("counter")["roundnumber"].count()
                result_count = player_bettype[
                    player_bettype["counter"].isin(
                        counter_count[counter_count >= conti_threshold].index
                    )
                ]

                result_count["count"] = 1

                result_count_copy = result_count.copy()
                result_count_copy[["count"]] = result_count.groupby(
                    ["tableid", "account_2"]
                )[["count"]].transform("sum")
                result_count = result_count_copy.loc[
                    result_count_copy["count"] >= conti_threshold
                ]

                result_tuple = pd.concat(
                    [result_tuple, result_count], ignore_index=True
                )

            logger.info(
                f"Get players who's bet types in bettype_check_tuple and continue at least {conti_threshold} times SUCCESS"
            )

            if result_tuple.empty:
                logger.info(
                    f"There is not any specific hedge players at table type={table_type}! \n"
                )

            else:
                table_type_tw = ""
                if table_type == "1":
                    table_type_tw = "百家桌"
                elif table_type == "4":
                    table_type_tw = "龍虎桌"

                result_bets = result_tuple.groupby(
                    [
                        "owner_1",
                        "parent_1",
                        "account_1",
                        "tableid",
                        "owner_2",
                        "parent_2",
                        "account_2",
                    ],
                    as_index=False,
                ).agg({"bets_1": "sum", "bets_2": "sum"})

                result_tuple["roundnumber"] = result_tuple["roundnumber"].astype(str)
                round_str = result_tuple.groupby(
                    [
                        "owner_1",
                        "parent_1",
                        "account_1",
                        "tableid",
                        "owner_2",
                        "parent_2",
                        "account_2",
                    ],
                    as_index=False,
                )["roundnumber"].agg(lambda x: x.str.cat(sep=", "))

                result_send = pd.merge(
                    result_bets,  # type: ignore
                    round_str,  # type: ignore
                    on=[
                        "owner_1",
                        "parent_1",
                        "account_1",
                        "tableid",
                        "owner_2",
                        "parent_2",
                        "account_2",
                    ],
                    how="inner",
                )

                # filter bet difference greater than 3 times
                result_send["bet_divide"] = round(
                    result_send["bets_1"].astype("float")
                    / result_send["bets_2"].astype("float"),
                    2,
                )
                result_send = result_send.loc[
                    (result_send["bet_divide"] > 0.33)
                    & (result_send["bet_divide"] <= 3)
                ]

                if result_send.empty:
                    logger.info(
                        f"No similar bet difference at table type={table_type} during specific hedge! \n"
                    )
                else:
                    msg += f"CA01 {table_type_tw} specific hedge: \n"
                    for index, row in result_send.iterrows():
                        msg += f"桌號: {row['tableid']}, 局號：{row['roundnumber']}, \n"
                        msg += (
                            f"Owner1: {row['owner_1']}, Parent1: {row['parent_1']},\n"
                        )
                        msg += f"Account1: {row['account_1']}, Bets1: {format(row['bets_1'], ',.2f')}, \n"
                        msg += (
                            f"Owner2: {row['owner_2']}, Parent2: {row['parent_2']},\n"
                        )
                        msg += f"Account2: {row['account_2']}, Bets2: {format(row['bets_2'], ',.2f')} \n"
        if msg != "":
            teamplus_message(_CFG.get("SPECIFIC_HEDGE_CHAT", ["832"]), msg)

    alert()


on_specify_hedge_dag = on_specify_hedge()
