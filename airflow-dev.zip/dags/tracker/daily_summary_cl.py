import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from datetime import timedelta
import logging

from utils.connection.mysql import mysql_cursor
from utils.connection.da_api import DAAPIHook
from tracker.crud import summary

from airflow.decorators import dag, task
from airflow.models import Variable
from tracker.src import sender

logger = logging.getLogger("airflow.task")

default_args = {
    "depends_on_past": False,
    "email": ["rmpeter0474@adcrow.tech"],
    "email_on_failure": True,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(seconds=10),
}


@dag(
    start_date=pendulum.datetime(2022, 10, 12, tz="UTC"),
    schedule="10 0 * * *",
    default_args=default_args,
    catchup=False,
    max_active_tasks=4,
    tags=["CL", "cl", "tracker"],
)
def daily_summary_cl():
    """
    ### CL Daily Summary
    Send summary to team+ and store to DA-API
    """

    @task()
    def add_and_update_to_api(
        data_interval_start: pendulum_datetime = pendulum.now(),
    ):
        import schemas

        _CFG = Variable.get("TRACKER_SUMMARY", deserialize_json=True)
        check_date_str = data_interval_start.format("YYYY-MM-DD")
        brand = "cl"

        hook = DAAPIHook()
        with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
            # SP game
            for game, info in _CFG.get("SP_GAME").items():
                if not brand.upper() in info:
                    continue
                logger.info(f"Get game: {game} under brand {brand}")
                sp_game_code = info[brand.upper()]
                sp_game_name = info["NAME"]
                sp_game_type = info["TYPE"]
                (_bets, _net_wins, _rounds, _players,) = summary.get_game_by_code(
                    cursor, check_date_str, sp_game_code, sp_game_type
                )
                performance_in = schemas.SalesSpecifyProject.parse_obj(
                    dict(
                        date=check_date_str,
                        brand=brand,
                        currency="ALL",
                        project=sp_game_name,
                        span="day",
                        code=sp_game_code,
                        bet=_bets,
                        net_win=_net_wins,
                        player=_players,
                        rounds=_rounds,
                    )
                )
                logger.debug(performance_in)
                hook.add_specify_game(performance_in.json(), check_response=False)
                if game == "MOTIVATION":
                    sender.teamplus_motivation_with_top_owners(
                        "日韓",
                        sp_game_code,
                        sp_game_name,
                        sp_game_type,
                        _bets,
                        check_date_str,
                        cursor,
                        _CFG.get("TEAMPLUS_MOTIVATION_CHAT"),
                    )
                if _bets == 0:
                    continue
                sp_spreadsheet_id = info.get("SPREADSHEET_ID")
                if sp_spreadsheet_id:
                    sender.google_sheet_append_sp_game_values(
                        "CL日韓",
                        check_date_str,
                        _bets,
                        _net_wins,
                        _rounds,
                        _players,
                        sp_spreadsheet_id,
                    )
                sp_spreadsheet_id = info.get("BY_OWNER_SPREADSHEET_ID")
                if sp_spreadsheet_id:
                    sender.google_sheet_append_sp_game_by_owner_values(
                        "CL日韓",
                        check_date_str,
                        sp_game_code,
                        sp_game_type,
                        sp_spreadsheet_id,
                        cursor,
                    )

                (_bets, _net_wins, _rounds, _players,) = summary.get_game_month_by_code(
                    cursor, check_date_str, sp_game_code, sp_game_type
                )
                if _bets == 0:
                    continue
                key = schemas.SalesSpecifyProjectKey.parse_obj(
                    dict(
                        date=check_date_str[:8] + "01",
                        brand=brand,
                        currency="ALL",
                        project=sp_game_name,
                        span="month",
                    )
                )
                info = hook.get_specify_project(key.dict(), check_response=False)
                performance_in = {
                    "bet": _bets,
                    "net_win": _net_wins,
                    "player": _players,
                    "rounds": _rounds,
                }
                if 233 > info.status_code >= 200:
                    hook.update_specify_game(
                        key.json(),
                        schemas.SalesSpecifyProjectUpdate.parse_obj(
                            performance_in
                        ).json(exclude_unset=True, exclude_none=True),
                        check_response=False,
                    )
                else:
                    performance_in["code"] = sp_game_code
                    performance_in.update(key.dict())
                    hook.add_specify_game(
                        schemas.SalesSpecifyProject.parse_obj(performance_in).json(),
                        check_response=False,
                    )

        hook.maintain_performance_size()

    add_and_update_to_api()


daily_summary_cl_dag = daily_summary_cl()
