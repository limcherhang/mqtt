import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from datetime import timedelta
import logging
from lego.src.etl import transform_docs2summary

from airflow.decorators import dag, task

# from airflow.utils.trigger_rule import TriggerRule
from airflow.providers.mongo.hooks.mongo import MongoHook
from airflow.providers.mysql.hooks.mysql import MySqlHook

logger = logging.getLogger("airflow.task")

default_args = {
    "depends_on_past": False,
    "email": ["rmpeter0474@adcrow.tech"],
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}


@dag(
    start_date=pendulum.datetime(2022, 6, 26, tz="UTC"),
    schedule="1 * * * *",
    default_args=default_args,
    catchup=False,
    max_active_tasks=4,
    tags=["PRO", "qt"],
)
def qtech_etl():
    """
    ### Lego-QTech ETL
    """

    @task()
    def extract_games(data_interval_start: pendulum_datetime = pendulum.now()):
        """
        ### Extract played games
        """
        data_start_date = pendulum.datetime(
            data_interval_start.year,
            data_interval_start.month,
            data_interval_start.day,
            data_interval_start.hour,
            tz=data_interval_start.tz,
        )
        logger.info(
            f"Query on {data_start_date} and {data_start_date + timedelta(hours=1)}"
        )
        with MongoHook(conn_id="mongo_read") as mongo_cnx:
            collection = mongo_cnx.get_collection(
                mongo_collection="bets", mongo_db="qt"
            )

            filter = {
                "createTime": {
                    "$gte": data_start_date,
                    "$lt": data_start_date + timedelta(hours=1),
                },
            }
            games = list(collection.distinct("gameCode", filter))

        logger.info(f"Get {games}")
        return games

    @task(max_active_tis_per_dag=4)
    def load_infos_by_game(
        game_code: str, data_interval_start: pendulum_datetime = pendulum.now()
    ):
        """
        ### Get complete QTech bets and wins
        """
        data_from_date = pendulum.datetime(
            data_interval_start.year,
            data_interval_start.month,
            data_interval_start.day,
            data_interval_start.hour,
            tz=data_interval_start.tz,
        )
        logger.info(f"Game code {game_code} get infos")
        mysql_cnx = MySqlHook(mysql_conn_id="mysql_master_read").get_conn()
        cursor = mysql_cnx.cursor()
        cursor.execute(
            "SELECT id FROM cypress.game_list WHERE game_code = %s", (game_code,)
        )
        gid = cursor.fetchone()[0]
        logger.info(f"Execute on {data_from_date} with game id {gid}")
        cursor.close()
        mysql_cnx.close()

        bets_docs = []
        with MongoHook(conn_id="mongo_read") as mongo_cnx:
            bets_collection = mongo_cnx.get_collection(
                mongo_collection="bets", mongo_db="qt"
            )

            pipeline = [
                {
                    "$match": {
                        "createTime": {
                            "$gte": data_from_date,
                            "$lt": data_from_date + timedelta(hours=1),
                        },
                        "gameCode": game_code,
                    }
                },
                {
                    "$project": {
                        "_id": 0,
                        "id": 1,
                        "round": 1,
                        "amount": 1,
                        "currency": 1,
                        "gameCode": 1,
                        "datetime": 1,
                        "gameToken": 1,
                        "end": 1,
                        "refund": 1,
                    }
                },
            ]
            bets_docs = list(bets_collection.aggregate(pipeline, allowDiskUse=True))

            wins_collection = mongo_cnx.get_collection(
                mongo_collection="wins", mongo_db="qt"
            )
            for _doc in bets_docs:
                _roundid = _doc.get("round")
                if not _roundid:
                    bets_docs.remove(_doc)
                    continue

                wins_doc = {}
                if not bool(_doc.get("end", False)):
                    if bool(_doc.get("refund", False)):
                        bets_docs.remove(_doc)
                        continue
                    _doc["win_amount"] = "None"
                else:
                    finds = {"round": _roundid}
                    projection = {"_id": 0, "amount": 1}
                    try:
                        wins_doc = list(wins_collection.find(finds, projection))[0]
                    except (TypeError, IndexError):
                        pass

                    _doc["win_amount"] = wins_doc.get("amount", "Miss")
                _doc["gid"] = gid
                if isinstance(_doc["datetime"], str):
                    _datetime = pendulum.parse(_doc["datetime"])
                    _doc["datetime"] = _datetime.in_tz("UTC").format(
                        "YYYY-MM-DD HH:mm:ss"
                    )
                else:
                    _doc["datetime"] = _doc["datetime"].strftime("%Y-%m-%d %H:%M:%S")

        logger.info(f"Game code {game_code} get {len(bets_docs)} docs!")

        mysql_cnx = MySqlHook(mysql_conn_id="mysql_master_write").get_conn()
        mysql_cnx.autocommit = True
        cursor = mysql_cnx.cursor()
        cursor.execute("SET time_zone = '+00:00'")
        cursor.execute(
            "DELETE FROM ReportStore.lego_hour_user_gametoken WHERE date = %s AND gid = %s",
            (data_from_date.format("YYYY-MM-DD HH:00:00"), gid),
        )
        cursor.execute(
            "DELETE FROM ReportStore.lego_hour_user_game WHERE date = %s AND gid = %s",
            (data_from_date.format("YYYY-MM-DD HH:00:00"), gid),
        )

        transform_docs2summary(bets_docs, cursor, data_from_date)

        cursor.close()
        mysql_cnx.close()
        return 1

    @task()
    def reload_incomplete_round(
        none_sense: list[int],
        data_interval_start: pendulum_datetime = pendulum.now(),
    ):
        """
        ### Reload incomplete round
        """
        logger.info(f"Get none sense {none_sense}")
        data_from_date = pendulum.datetime(
            data_interval_start.year,
            data_interval_start.month,
            data_interval_start.day,
            data_interval_start.hour,
            tz=data_interval_start.tz,
        )
        mysql_cnx = MySqlHook(mysql_conn_id="mysql_master_write").get_conn()
        mysql_cnx.autocommit = True
        cursor = mysql_cnx.cursor()
        cursor.execute("SET time_zone = '+00:00'")

        cursor.execute(
            "SELECT roundid FROM ReportStore.lego_incomplete_round WHERE create_time < %s",
            (data_from_date,),
        )
        rounds = [_rid for (_rid,) in cursor.fetchall()]
        if not rounds:
            logger.info(f"Not having any incomplete round before {data_from_date}")
            return
        logger.info(f"Having {len(rounds)} incomplete round before {data_from_date}")

        with MongoHook(conn_id="mongo_read") as mongo_cnx:
            bets_collection = mongo_cnx.get_collection(
                mongo_collection="bets", mongo_db="qt"
            )
            wins_collection = mongo_cnx.get_collection(
                mongo_collection="wins", mongo_db="qt"
            )
            finds = {"round": {"$in": rounds}}
            projection = {
                "_id": 0,
                "id": 1,
                "round": 1,
                "amount": 1,
                "currency": 1,
                "gameCode": 1,
                "datetime": 1,
                "gameToken": 1,
                "refund": 1,
            }
            bets_docs = list(bets_collection.find(finds, projection))
            for _doc in bets_docs:
                _roundid = _doc.get("round")
                if not _roundid:
                    bets_docs.remove(_doc)
                    continue

                _gamecode = _doc.get("gameCode")
                if not _gamecode:
                    bets_docs.remove(_doc)
                    continue
                cursor.execute(
                    "SELECT id FROM cypress.game_list WHERE game_code = %s",
                    (_gamecode,),
                )
                _doc["gid"] = cursor.fetchone()[0]
                if isinstance(_doc["datetime"], str):
                    _datetime = pendulum.parse(_doc["datetime"])
                    _doc["datetime"] = _datetime.in_tz("UTC").format(
                        "YYYY-MM-DD HH:mm:ss"
                    )
                else:
                    _doc["datetime"] = _doc["datetime"].strftime("%Y-%m-%d %H:%M:%S")

                if bool(_doc.get("refund", False)):
                    _doc["win_amount"] = "Refund"
                    continue

                wins_doc = {}

                finds = {"round": _roundid}
                projection = {"_id": 0, "amount": 1}
                try:
                    wins_doc = list(wins_collection.find(finds, projection))[0]
                except (TypeError, IndexError):
                    continue

                _doc["win_amount"] = wins_doc.get("amount", "Miss")

        transform_docs2summary(bets_docs, cursor, data_from_date, is_reload=True)

        cursor.close()
        mysql_cnx.close()

    reload_incomplete_round(load_infos_by_game.expand(game_code=extract_games()))


qtech_etl_dag = qtech_etl()
