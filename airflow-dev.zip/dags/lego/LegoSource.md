# QTech 

[![hackmd-github-sync-badge](https://hackmd.io/e2mqCDqoQ1uDOpuaXUxS9A/badge)](https://hackmd.io/e2mqCDqoQ1uDOpuaXUxS9A)

Lego RD project **QTech**  

### Future
* 20220902 gossip   
  1. 將加入endroundtime結算時間  
  2. round是否會維持Unique?  

### Structure
Only have transaction log.  
```mermaid
    graph LR;
    C -->|Game| B
    B[QTech] -->|Order| C
    C[Cq9 GS] -->|bets / wins| D[Cq9 lego]
```

### Collection
MongoDB qt. bets and wins can be linked by round(roundid). win=0 is also record in wins.  
* bets
    * example
    ```
    {
    "_id" : ObjectId("62e1d6991cb0fe11a3985dae"),
    "mtCode" : "pro-bet-579093",
    "round" : "579093",
    "id" : "1855-kauab068",
    "amount" : 3.52,
    "currency" : "THB",
    "gameCode" : "125",
    "datetime" : GS紀錄 bet行為當下紀錄的時間(目前是字串，未來會改為時間型態)
    "created" : "2022-07-27T20:21:45.028-04:00",
    "completed" : false,
    "createTime" : ISODate("2022-07-28T00:21:45.035Z"),
    "gameToken" : "1855-45fd726e-0feb-4462-8869-4cc95fd9b471",
    "bet" : true,
    "win" : true,
    "end" : true,
    "refund" : false,
    "integrators" : "QTech",
    "operatorId" : "qt_asia"
    }
    ```
    * datetime : GS紀錄 bet行為當下紀錄的時間(目前是字串，未來會改為時間型態)，不等於cypress.ordertime
    * createTime : 是資料從GS抄回 Leto 寫入 mongo的時間
    * created : 多於欄位會移除
    * gameCode共用  
    * end與refund其中一個是True的時候才結算
    * refund=True表示已退款，不會有wins；若要改成refund=False，則會走補單(成單)流程來產生
* wins
    * example
    ```
    {
    "_id" : ObjectId("62e1d69db7f28756716d88a9"),
    "mtCode" : "pro-win-579093",
    "betCode" : "pro-bet-579093",
    "round" : "579093",
    "id" : "1855-kauab068",
    "amount" : 0.2,
    "currency" : "THB",
    "gameCode" : "125",
    "datetime" : "2022-07-27T20:21:49.104-04:00",
    "created" : "2022-07-27T20:21:49.104-04:00",
    "completed" : true,
    "createTime" : ISODate("2022-07-28T00:21:49.109Z"),
    "gameToken" : "1855-45fd726e-0feb-4462-8869-4cc95fd9b471",
    "jppayouts" : null
    }
    ```
    * datetime : GS紀錄 bet行為當下紀錄的時間(目前是字串，未來會改為時間型態)
    * createTime : 是資料從GS抄回 Leto 寫入 mongo的時間
    * created : 多餘欄位會移除
