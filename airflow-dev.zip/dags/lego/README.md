# Lego Report 

[![hackmd-github-sync-badge](https://hackmd.io/ryCYi5IqQWSfrkC94z70ww/badge)](https://hackmd.io/ryCYi5IqQWSfrkC94z70ww)

Lego's porject now having  
| Project | short | PRO Start date | source |
| :-- | :-- | :-- | :-- |
| QTech | qt | 2022-06-26 | [qtech](https://hackmd.io/e2mqCDqoQ1uDOpuaXUxS9A) |
| Hub88 | | -Going | |  

### Principle  
以createtime來撈取單，並依datetime來作為統計基礎  

### MysqlDB 
Data warehouse(cypress-like) for QTech.       
* lego_user_list  
    User list with user from QTech
    | column | resource | description |
    | :-- | :-- | :-- |
    | id |  | **PK** Auto generate |
    | account | Mongo-qt.bets.id | User name |
    | currency | Mongo-qt_bets.currency | Currency name | 
    | project | | Project name | 
    | first | | First bet time |
    | update_time | | Auto generate |
  
* lego_user_active  
    User-game active record  
    | column | resource | description |
    | :-- | :-- | :-- |
    | uid | lego_user_list.id | **PK** |
    | gid |  | **PK** Mongo-qt.bets.gameCode trans by MySQL-cypress.game_list |
    | first | YYYY-MM-DD | First date playing the game |

* lego_hour_user_by_game  
    User-game hourly summary
    | column | resource | description |
    | :-- | :-- | :-- |
    | date | Mongo-qt.bets.datetime | **PK** Datetime (YYYY-MM-DD HH:00:00) playing the game |
    | uid | lego_user_list.id | **PK** |
    | gid |  | **PK** Mongo-qt.bets.gameCode trans by MySQL-cypress.game_list.id |
    | bets | Mongo-qt.bets.amount | Total bet |
    | wins | Mongo-qt.wins.amount | Total win |
    | rounds |  | Number of bets |
    | counts |  | Number of gametokens |
    | intervals |  | Seconds of playing |
    | update_time | | Auto generate |
    
* lego_hour_user_gametoken  
    User-gametoken hourly summary
    | column | resource | description |
    | :-- | :-- | :-- |
    | date | Mongo-qt.bets.datetime | **PK** Datetime (YYYY-MM-DD HH:00:00) playing the game |
    | uid | lego_user_list.id | |
    | gid |  | Mongo-qt.bets.gameCode trans by MySQL-cypress.game_list.id |
    | gametoken | Mongo-qt.bets.gameToken | **PK** |
    | first | Mongo-qt.bets.datetime | The first datetime in this hour |
    | last | Mongo-qt.bets.datetime | The last datetime in this hour |
    | update_time | | Auto generate |

* lego_incomplete_round  
    Incomplete roundid in Lego. Not finding wins, or failing.  
    | column | resource | description |
    | :-- | :-- | :-- |
    | roundid | Mongo-qt.bets.round | The roud-id base on bets |
    | status | | 0: (Default)Not finding wins. 1: Failing. | 
    | project | | Project name | 
    | create_time | | Auto generate |
    | update_time | | Auto generate |
  
statements  
```sql
USE ReportStore
CREATE TABLE `lego_user_list` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '流水號',
  `account` varbinary(50) NOT NULL COMMENT 'Lego會員帳號',
  `currency` varchar(50) NOT NULL DEFAULT 'CNY' COMMENT '幣別',
  `project` varchar(50) NOT NULL DEFAULT 'CNY' COMMENT '專案',
  `first` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '首次遊玩時間',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新時間',
  PRIMARY KEY (`id`),
  CONSTRAINT `account_project` UNIQUE (`account`, `project`)
) COMMENT='Lego會員列表'

CREATE TABLE `lego_hour_user_game` (
  `date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '下注時間(小時); Mongo-qt.bets.datetime',
  `uid` bigint unsigned NOT NULL COMMENT '玩家ID mapping lego_user_list.id',
  `gid` bigint unsigned NOT NULL COMMENT '遊戲ID mapping cypress.game_list.id',
  `bets` decimal(20,4) NOT NULL DEFAULT '0.0000' COMMENT '投注金額',
  `wins` decimal(20,4) NOT NULL DEFAULT '0.0000' COMMENT '贏分',
  `rounds` int unsigned NOT NULL DEFAULT '0' COMMENT '遊戲場次',
  `counts` int unsigned NOT NULL DEFAULT '0' COMMENT '遊玩次數',
  `intervals` int unsigned NOT NULL DEFAULT '0' COMMENT '遊戲秒數',
  `updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新時間',
  PRIMARY KEY (`date`,`uid`,`gid`),
  KEY `gid_date` (`gid`,`date`)
) COMMENT='Lego會員統計'

CREATE TABLE `lego_hour_user_gametoken` (
  `date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '下注時間(小時); MongoDB qt.bets.datetime',
  `uid` bigint unsigned NOT NULL COMMENT '玩家ID mapping lego_user_list.id',
  `gid` bigint unsigned NOT NULL COMMENT '遊戲ID mapping cypress.game_list.id',
  `gametoken` varchar(100) NOT NULL COMMENT 'Lego會員gametoken',
  `first` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '首次下注時間; MongoDB qt.bets.datetime',
  `last` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '最後下注時間(小時); MongoDB qt.bets.datetime',
  `updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新時間',
  PRIMARY KEY (`date`,`gametoken`),
  KEY `uid_gid_date` (`uid`, `gid`,`date`)
) COMMENT='Lego會員gametoken統計'

CREATE TABLE `lego_user_active` (
  `uid` bigint unsigned NOT NULL COMMENT '玩家ID mapping lego_user_list.id',
  `gid` bigint unsigned NOT NULL COMMENT '遊戲ID mapping cypress.game_list.id',
  `first` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '首次遊玩時間',
  PRIMARY KEY (`uid`,`gid`)
) COMMENT='Lego會員活躍'


CREATE TABLE `lego_incomplete_round` (
  `roundid` varchar(50) NOT NULL COMMENT '場次ID mapping MongoDB qt.bets.round',
  `status` tinyint NOT NULL DEFAULT 0 COMMENT '未完成狀態;0: (Default)Mongo-qt.bet.end=false. 1: Missing wins',
  `project` varchar(50) NOT NULL DEFAULT 'CNY' COMMENT '專案',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '建立時間',
  `updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新時間',
  PRIMARY KEY (`roundid`)
) COMMENT='Lego未完成注單'
```
