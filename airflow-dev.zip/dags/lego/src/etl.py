import logging
from mysql.connector.cursor import MySQLCursor
import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from datetime import timedelta

from airflow.decorators import task
from airflow.providers.mongo.hooks.mongo import MongoHook

logger = logging.getLogger("airflow.task")


def extract_games(data_interval_start: pendulum_datetime = pendulum.now()):
    """
    !!! NOT TEST !!!
    ### Extract played games
    """
    data_start_date = pendulum.datetime(
        data_interval_start.year,
        data_interval_start.month,
        data_interval_start.day,
        data_interval_start.hour,
        tz=data_interval_start.tz,
    )
    logger.info(
        f"Query on {data_start_date} and {data_start_date + timedelta(hours=1)}"
    )
    with MongoHook(conn_id="mongo_read") as mongo_cnx:
        collection = mongo_cnx.get_collection(mongo_collection="bets", mongo_db="qt")

        filter = {
            "createTime": {
                "$gte": data_start_date,
                "$lt": data_start_date + timedelta(hours=1),
            },
            "bet": True,
        }
        games = list(collection.distinct("gameCode", filter))

    logger.info(f"Get {games}")
    return games


def transform_docs2summary(
    docs: list[dict],
    cursor: MySQLCursor,
    data_from_date: pendulum_datetime,
    is_reload: bool = False,
):
    log_reload = " with reload" if is_reload else ""
    logger.info(f"Transform {len(docs)} docs to summary{log_reload}")
    cmp_rounds = []
    summary = {}
    stmt = (
        "INSERT INTO ReportStore.lego_incomplete_round (roundid, status) VALUES (%s, %s) "
        "ON DUPLICATE KEY UPDATE status = 1"
    )
    for _doc in docs:
        _roundid = _doc.get("round")
        if not _roundid:
            continue

        if _doc.get("win_amount", "None") == "None":
            cursor.execute(stmt, (_doc["round"], 0))
            continue
        elif _doc["win_amount"] == "Miss":
            cursor.execute(stmt, (_doc["round"], 1))
            continue
        elif is_reload and (_doc["win_amount"] == "Refund"):
            cmp_rounds.append(_roundid)
            continue

        _datetime = pendulum.parse(_doc["datetime"])
        _user = _doc["id"]
        _gid = _doc["gid"]
        _currency = _doc["currency"]
        _token = _doc["gameToken"]
        _key_summary = (
            _datetime.format("YYYY-MM-DD HH:00:00"),
            _user,
            _gid,
            _currency,
        )
        _summary = summary.setdefault(
            _key_summary,
            {
                "bets": 0,
                "wins": 0,
                "rounds": 0,
                "counter": set(),
                "record": {},
                "min_datetime": _datetime,
            },
        )
        _summary["bets"] += _doc["amount"]
        _summary["wins"] += _doc["win_amount"]
        _summary["rounds"] += 1
        _summary["counter"].add(_token)
        if _token not in _summary["record"]:
            _summary["record"] = {
                _token: [data_from_date + timedelta(hours=1), data_from_date]
            }

        if _datetime < _summary["record"][_token][0]:
            _summary["record"][_token][0] = _datetime
        if _datetime > _summary["record"][_token][1]:
            _summary["record"][_token][1] = _datetime
        if _datetime < _summary["min_datetime"]:
            _summary["min_datetime"] = _datetime

        if is_reload:
            cmp_rounds.append(_roundid)

    logger.info(f"{len(summary.keys())} summarys in this hour{log_reload}")
    token_stmt = (
        "INSERT INTO ReportStore.lego_hour_user_gametoken (date, uid, gid, gametoken, first, last) "
        "VALUES (%s, %s, %s, %s, %s, %s) "
        "ON DUPLICATE KEY UPDATE first = VALUES(first), last = VALUES(last) "
    )
    stmt = (
        "INSERT INTO ReportStore.lego_hour_user_game (date, uid, gid, bets, wins, rounds, counts, intervals) "
        "VALUES (%s, %s, %s, %s, %s, %s, %s, %s) "
        "ON DUPLICATE KEY UPDATE bets = bets + VALUES(bets), wins = wins + VALUES(wins), "
        "rounds = rounds + VALUES(rounds), counts = counts + VALUES(counts), intervals = VALUES(intervals) "
    )
    for _key, _summary in summary.items():
        _datetime, _user, _gid, _currency = _key
        _min_datetime = _summary["min_datetime"]
        cursor.execute(
            f"SELECT IFNULL(id, 0), DATE_FORMAT(first, '%Y-%m-%d %H:%i:%s') FROM ReportStore.lego_user_list WHERE account = '{_user}' AND project = 'qt'"
        )
        _uid_res = cursor.fetchone()
        if not _uid_res or _uid_res[0] == 0:
            cursor.execute(
                "INSERT INTO ReportStore.lego_user_list (account, currency, project, first) VALUES (%s, %s, %s, %s)",
                (_user, _currency, "qt", _min_datetime.format("YYYY-MM-DD HH:mm:ss")),
            )
            _uid = cursor.lastrowid
        else:
            _uid = _uid_res[0]
            _first = _uid_res[1]
            if _min_datetime < pendulum.parse(_first):
                cursor.execute(
                    "UPDATE ReportStore.lego_user_list SET first = %s WHERE id = %s",
                    (_min_datetime.format("YYYY-MM-DD HH:mm:ss"), _uid),
                )

        # Update user_active
        cursor.execute(
            f"SELECT DATE_FORMAT(first, '%Y-%m-%d %H:%i:%s') FROM ReportStore.lego_user_active WHERE uid = {_uid} AND gid = {_gid}"
        )
        _active_res = cursor.fetchone()
        if not _active_res:
            cursor.execute(
                "INSERT INTO ReportStore.lego_user_active (uid, gid, first) VALUES (%s, %s, %s)",
                (_uid, _gid, _min_datetime.format("YYYY-MM-DD HH:mm:ss")),
            )
        elif _min_datetime < pendulum.parse(_active_res[0]):
            cursor.execute(
                "UPDATE ReportStore.lego_user_active SET first = %s WHERE uid = %s AND gid = %s",
                (_min_datetime.format("YYYY-MM-DD HH:mm:ss"), _uid, _gid),
            )

        _intervals = 0
        _minus_counts = 0
        for _token, _record in _summary["record"].items():
            cursor.execute(
                "SELECT first, last FROM ReportStore.lego_hour_user_gametoken WHERE date = %s AND gametoken = %s",
                (_datetime, _token),
            )
            _result = cursor.fetchone()
            if _result:
                _minus_counts -= 1
                _first, _last = _result
                if isinstance(_first, str):
                    _first = pendulum.parse(_first)
                else:
                    _first = pendulum.parse(_first.strftime("%Y-%m-%d %H:%M:%S"))
                if isinstance(_last, str):
                    _last = pendulum.parse(_last)
                else:
                    _last = pendulum.parse(_last.strftime("%Y-%m-%d %H:%M:%S"))
                if _first < _record[0]:
                    _record[0] = _first
                if _last > _record[1]:
                    _record[1] = _last

            cursor.execute(
                token_stmt,
                (
                    _datetime,
                    _uid,
                    _gid,
                    _token,
                    _record[0].format("YYYY-MM-DD HH:mm:ss"),
                    _record[1].format("YYYY-MM-DD HH:mm:ss"),
                ),
            )
            if _record[0] <= _record[1]:
                _intervals += pendulum.period(_record[0], _record[1]).in_seconds()
        if is_reload:
            cursor.execute(
                "SELECT IFNULL(SUM(TIMESTAMPDIFF(SECOND, first, last)), 0) FROM ReportStore.lego_hour_user_gametoken WHERE date = %s AND uid = %s AND gid = %s",
                (_datetime, _uid, _gid),
            )
            try:
                _intervals = cursor.fetchone()[0]
            except (TypeError, IndexError):
                pass
        cursor.execute(
            stmt,
            (
                _datetime,
                _uid,
                _gid,
                _summary["bets"],
                _summary["wins"],
                _summary["rounds"],
                len(_summary["counter"]) + _minus_counts,
                _intervals,
            ),
        )

    if is_reload and cmp_rounds:
        cursor.execute(
            f"DELETE FROM ReportStore.lego_incomplete_round WHERE roundid IN ({str(cmp_rounds)[1:-1]})"
        )
