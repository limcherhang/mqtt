from typing import Optional

from pydantic import BaseModel


class GoogleToken(BaseModel):
    """
    Google oauth with idToken and client_id.
    """

    id_token: str
    client_id: str


class RefreshToken(BaseModel):
    refresh_token: str


class Token(RefreshToken):
    access_token: str


class TokenPayload(BaseModel):
    sub: Optional[str] = None
