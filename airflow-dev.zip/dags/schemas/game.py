from pydantic import BaseModel
from enum import Enum


class GameType(str, Enum):
    slot = "slot"
    fish = "fish"
    arcade = "arcade"
    table = "table"
    live = "live"
    lotto = "lotto"
    sport = "sport"


class GameInfo(BaseModel):
    name: str
    code: str
    game_type: GameType
