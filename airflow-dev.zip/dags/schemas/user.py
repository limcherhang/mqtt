from datetime import datetime
from typing import Optional, Union, List

from pydantic import BaseModel, EmailStr, Json

JSONstr = str


class AuthUserTasksCreate(BaseModel):
    user_id: int
    task_id: str
    extra: JSONstr


class AuthUserTasksUpdate(BaseModel):
    user_id: Optional[int] = None
    task_id: Optional[str] = None
    extra: Optional[JSONstr] = None


class AuthUserGroupsCreate(BaseModel):
    user_id: int
    group_id: int


class AuthUserGroupsUpdate(BaseModel):
    user_id: Optional[int] = None
    group_id: Optional[int] = None


class AuthGroupBase(BaseModel):
    name: str


class AuthGroupCreate(AuthGroupBase):
    pass


class AuthGroupUpdate(AuthGroupBase):
    pass


class GoogleAuthUserBase(BaseModel):
    uid: str  # sub "110169484474386276334"
    extra_data: Json
    last_login: Optional[datetime] = None
    date_joined: Optional[datetime] = datetime.utcnow()


class GoogleAuthUserCreate(GoogleAuthUserBase):
    user_id: int = 0  # Not set yet. AuthUser.id
    password: str  # For setting AuthUser.password


class GoogleAuthUserUpdate(BaseModel):
    extra_data: Optional[Json]
    last_login: Optional[datetime] = datetime.utcnow()


class GoogleTokenUser(BaseModel):
    # These six fields are included in all Google ID Tokens.
    iss: str  # "https://accounts.google.com",
    sub: str  # "110169484474386276334",
    azp: str  # "1008719970978-hb24n2dstb40o45d4feuo2ukqmcc6381.apps.googleusercontent.com",
    aud: str  # "1008719970978-hb24n2dstb40o45d4feuo2ukqmcc6381.apps.googleusercontent.com",
    iat: str  # "1433978353",
    exp: str  # "1433981953",
    # These seven fields are only included when the user has granted the "profile" and
    # "email" OAuth scopes to the application.
    email: EmailStr  # "testuser@gmail.com",
    email_verified: str  # "true",
    locale: str  # "en"
    hd: Optional[str] = "gmail.com"  # "adcrow.tech"
    # The following won't be given if the same idToken is verified for the second time.
    name: Optional[str]  # "Test User",
    picture: Optional[
        str
    ]  # "https://lh4.googleusercontent.com/-kYgzyAWpZzJ/ABCDEFGHI/AAAJKLMNOP/tIXL9Ir44LE/s99-c/photo.jpg",
    given_name: Optional[str]  # "Test",
    family_name: Optional[str]  # "User",


# Shared properties
class AuthUserBase(BaseModel):
    username: str
    email: Union[EmailStr, str] = ""
    is_superuser: bool = False
    is_staff: Optional[bool] = False
    is_active: Optional[bool] = True
    first_name: Optional[str] = ""
    last_name: Optional[str] = ""
    last_login: Optional[datetime] = None
    date_joined: Optional[datetime] = datetime.utcnow()


# Properties to receive via API on creation
class AuthUserCreate(AuthUserBase):
    password: str


# Properties to receive via API on update
class AuthUserUpdate(BaseModel):
    email: Optional[Union[EmailStr, str]] = None
    is_staff: Optional[bool] = False
    is_active: Optional[bool] = True
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    password: Optional[str] = None


class AuthUserInDBBase(AuthUserBase):
    id: Optional[int] = None

    class Config:
        orm_mode = True


# Additional properties to return via API
class AuthUser(AuthUserInDBBase):
    pass


# Additional properties stored in DB
class AuthUserInDB(AuthUserInDBBase):
    hashed_password: str


class AuthGroupInDBBase(AuthGroupBase):
    id: Optional[int] = None
    users: List[AuthUser]

    class Config:
        orm_mode = True


class AuthGroup(AuthGroupInDBBase):
    pass
