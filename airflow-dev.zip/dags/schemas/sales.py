from collections import namedtuple
from datetime import datetime, timezone
from typing import Optional
import pytz
from enum import Enum

from pydantic import BaseModel, Field, validator

TOP_RANGE = namedtuple("top_range", ["min", "max"])
sales_top_range = TOP_RANGE(1, 10)
_SPECIFY_GAME_SPAN_TYPE = ("day", "month")


class SalesAlarm(BaseModel):
    """
    Sales performance alarm on daily bet difference.
    The attribute should ALL in STRING for firebase messaging!
    """

    action: str = "SalesAlarm"
    title: str
    message: str
    brand: str
    date: str = Field(
        ...,
        description="Datetime in the string format like YYYY-MM-DD or YYYY-MM-DDTHH:mm:ss",
    )


class SalesSpecifyGame(str, Enum):
    Motivation = "Motivation"
    GenSports = "GenSports"


class SalesSpecifyProject(BaseModel):
    """
    Specify project including game or agent.
    Ex. game: GenSports, Motivation; project: lego-qt
    """

    date: datetime | str = Field(
        ...,
        description="Python datetime or string of YYYY-MM-DD or YYYY-MM-DDTHH:mm:ssZZ",
    )

    @validator("date")
    def validate_date_add_tzinfo(cls, value: datetime | str):
        if isinstance(value, str):
            # In the form of YYYY-MM-DD
            if len(value) == 10:
                try:
                    value = datetime.strptime(value, "%Y-%m-%d")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DD")
            else:
                try:
                    value = datetime.strptime(value, "%Y-%m-%dT%H:%M:%S%z")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DDTHH:mm:ssZZ")

        tz = value.tzinfo
        if tz:
            assert tz == pytz.UTC or tz == timezone.utc, "date should be UTC timezone"
        else:
            value = value.replace(tzinfo=pytz.UTC)
        return value

    brand: str = Field(...)
    currency: str = Field(...)
    project: str = Field(...)
    span: str = Field(
        ...,
        description=f"{_SPECIFY_GAME_SPAN_TYPE} only; YYYY-MM-01 with month stand for the month data",
    )

    @validator("span")
    def validate_span_type(cls, value: str):
        if value not in _SPECIFY_GAME_SPAN_TYPE:
            raise ValueError(f"span should be set in {_SPECIFY_GAME_SPAN_TYPE}")
        return value

    code: str = Field("", description="Game code or agent ssid")
    bet: float = Field(0)

    @validator("bet")
    def validate_bet_decimale_place(cls, value: float):

        return round(value, 2)

    net_win: float = Field(0)

    @validator("net_win")
    def validate_net_win_decimale_place(cls, value: float):

        return round(value, 2)

    player: int = Field(0)
    rounds: int = Field(0)


class SalesSpecifyProjectKey(BaseModel):
    date: datetime | str

    @validator("date")
    def validate_date_add_tzinfo(cls, value: datetime | str):
        if isinstance(value, str):
            # In the form of YYYY-MM-DD
            if len(value) == 10:
                try:
                    value = datetime.strptime(value, "%Y-%m-%d")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DD")
            else:
                try:
                    value = datetime.strptime(value, "%Y-%m-%dT%H:%M:%S%z")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DDTHH:mm:ssZZ")

        tz = value.tzinfo
        if tz:
            assert tz == pytz.UTC or tz == timezone.utc, "date should be UTC timezone"
        else:
            value = value.replace(tzinfo=pytz.UTC)
        return value

    brand: str
    currency: str
    project: str
    span: str = Field(
        ...,
        description=f"{_SPECIFY_GAME_SPAN_TYPE} only; YYYY-MM-01 with month stand for the month data",
    )

    @validator("span")
    def validate_span_type(cls, value: str):
        if value not in _SPECIFY_GAME_SPAN_TYPE:
            raise ValueError(f"span should be set in {_SPECIFY_GAME_SPAN_TYPE}")
        return value


class SalesSpecifyProjectUpdate(BaseModel):
    code: Optional[str]
    bet: Optional[float]

    @validator("bet")
    def validate_bet_decimale_place(cls, value: float):

        return round(value, 2)

    net_win: Optional[float]

    @validator("net_win")
    def validate_net_win_decimale_place(cls, value: float):

        return round(value, 2)

    player: Optional[int]
    rounds: Optional[int]


class TopType(str, Enum):
    agent = "agent"
    game = "game"


class SalesPerformanceTopBet(BaseModel):
    date: datetime | str = Field(
        ...,
        description="Python datetime or string of YYYY-MM-DD or YYYY-MM-DDTHH:mm:ssZZ",
    )

    @validator("date")
    def validate_date_add_tzinfo(cls, value: datetime | str):
        if isinstance(value, str):
            # In the form of YYYY-MM-DD
            if len(value) == 10:
                try:
                    value = datetime.strptime(value, "%Y-%m-%d")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DD")
            else:
                try:
                    value = datetime.strptime(value, "%Y-%m-%dT%H:%M:%S%z")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DDTHH:mm:ssZZ")

        tz = value.tzinfo
        if tz:
            assert tz == pytz.UTC or tz == timezone.utc, "date should be UTC timezone"
        else:
            value = value.replace(tzinfo=pytz.UTC)
        return value

    brand: str = Field(...)
    currency: str = Field(...)
    name: str = Field(...)
    top_type: TopType = Field(..., description="Type in [game, agent]")

    code: str = Field(
        "", description="Code for [game, agent], ex, game_code for game; ssid for agent"
    )
    rank: int = Field(
        sales_top_range.min,
        description="Rank by bet",
        ge=sales_top_range.min,
        le=sales_top_range.max,
    )

    bet: float = Field(0)

    @validator("bet")
    def validate_bet_decimale_place(cls, value: float):

        return round(value, 2)

    pre_bet: float = Field(0)

    @validator("pre_bet")
    def validate_pre_bet_decimale_place(cls, value: float):

        return round(value, 2)

    pre_month_avg_bet: float = Field(0)

    @validator("pre_month_avg_bet")
    def validate_pre_month_avg_bet_decimale_place(cls, value: float):

        return round(value, 2)

    # today bet - yesterday bet
    bet_day_diff: float = Field(0)

    @validator("bet_day_diff")
    def validate_bet_day_diff_decimale_place(cls, value: float):

        return round(value, 2)

    # today bet - last month average bet; ex: 5/25 bets - April average bet
    bet_month_avg_diff: float = Field(0)

    @validator("bet_month_avg_diff")
    def validate_bet_month_avg_diff_decimale_place(cls, value: float):

        return round(value, 2)

    rounds: int = Field(0)


class SalesPerformanceTopBetKey(BaseModel):
    date: datetime | str

    @validator("date")
    def validate_date_add_tzinfo(cls, value: datetime | str):
        if isinstance(value, str):
            # In the form of YYYY-MM-DD
            if len(value) == 10:
                try:
                    value = datetime.strptime(value, "%Y-%m-%d")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DD")
            else:
                try:
                    value = datetime.strptime(value, "%Y-%m-%dT%H:%M:%S%z")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DDTHH:mm:ssZZ")

        tz = value.tzinfo
        if tz:
            assert tz == pytz.UTC or tz == timezone.utc, "date should be UTC timezone"
        else:
            value = value.replace(tzinfo=pytz.UTC)
        return value

    brand: str
    currency: str
    name: str


class SalesPerformanceTopBetUpdate(BaseModel):
    rank: Optional[int]

    @validator("rank")
    def validate_rank(cls, value: Optional[int]):
        if value:
            if value > sales_top_range.max or value < sales_top_range.min:
                raise ValueError(f"The rank should in {sales_top_range}")
            else:
                return value

    bet: Optional[float]

    @validator("bet")
    def validate_bet_decimale_place(cls, value: float):

        return round(value, 2)

    pre_bet: Optional[float]

    @validator("pre_bet")
    def validate_pre_bet_decimale_place(cls, value: float):

        return round(value, 2)

    pre_month_avg_bet: Optional[float]

    @validator("pre_month_avg_bet")
    def validate_pre_month_avg_bet_decimale_place(cls, value: float):

        return round(value, 2)

    bet_day_diff: Optional[float]

    @validator("bet_day_diff")
    def validate_bet_day_diff_decimale_place(cls, value: float):

        return round(value, 2)

    bet_month_avg_diff: Optional[float]

    @validator("bet_month_avg_diff")
    def validate_bet_month_avg_diff_decimale_place(cls, value: float):

        return round(value, 2)

    rounds: Optional[int]


class SalesPerformanceCurrency(BaseModel):
    date: datetime | str = Field(
        ...,
        description="Python datetime or string of YYYY-MM-DD or YYYY-MM-DDTHH:mm:ssZZ",
    )

    @validator("date")
    def validate_date_add_tzinfo(cls, value: datetime | str):
        if isinstance(value, str):
            # In the form of YYYY-MM-DD
            if len(value) == 10:
                try:
                    value = datetime.strptime(value, "%Y-%m-%d")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DD")
            else:
                try:
                    value = datetime.strptime(value, "%Y-%m-%dT%H:%M:%S%z")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DDTHH:mm:ssZZ")

        tz = value.tzinfo
        if tz:
            assert tz == pytz.UTC or tz == timezone.utc, "date should be UTC timezone"
        else:
            value = value.replace(tzinfo=pytz.UTC)
        return value

    brand: str = Field(...)
    currency: str = Field(...)
    bet: float = Field(0)

    @validator("bet")
    def validate_bet_decimale_place(cls, value: float):

        return round(value, 2)

    pre_bet: float = Field(0)

    @validator("pre_bet")
    def validate_pre_bet_decimale_place(cls, value: float):

        return round(value, 2)

    pre_month_avg_bet: float = Field(0)

    @validator("pre_month_avg_bet")
    def validate_pre_month_avg_bet_decimale_place(cls, value: float):

        return round(value, 2)

    net_win: float = Field(0)

    @validator("net_win")
    def validate_net_win_decimale_place(cls, value: float):

        return round(value, 2)

    player: int = Field(0)
    rounds: int = Field(0)


class SalesPerformanceCurrencyKey(BaseModel):
    date: datetime | str

    @validator("date")
    def validate_date_add_tzinfo(cls, value: datetime | str):
        if isinstance(value, str):
            # In the form of YYYY-MM-DD
            if len(value) == 10:
                try:
                    value = datetime.strptime(value, "%Y-%m-%d")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DD")
            else:
                try:
                    value = datetime.strptime(value, "%Y-%m-%dT%H:%M:%S%z")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DDTHH:mm:ssZZ")

        tz = value.tzinfo
        if tz:
            assert tz == pytz.UTC or tz == timezone.utc, "date should be UTC timezone"
        else:
            value = value.replace(tzinfo=pytz.UTC)
        return value

    brand: str
    currency: str


class SalesPerformanceCurrencyUpdate(BaseModel):
    bet: Optional[float]

    @validator("bet")
    def validate_bet_decimale_place(cls, value: float):

        return round(value, 2)

    pre_bet: Optional[float]

    @validator("pre_bet")
    def validate_pre_bet_decimale_place(cls, value: float):

        return round(value, 2)

    pre_month_avg_bet: Optional[float]

    @validator("pre_month_avg_bet")
    def validate_pre_month_avg_bet_decimale_place(cls, value: float):

        return round(value, 2)

    net_win: Optional[float]

    @validator("net_win")
    def validate_net_win_decimale_place(cls, value: float):

        return round(value, 2)

    player: Optional[int]
    rounds: Optional[int]


class SalesPerformanceGametype(BaseModel):
    date: datetime | str = Field(
        ...,
        description="Python datetime or string of YYYY-MM-DD or YYYY-MM-DDTHH:mm:ssZZ",
    )

    @validator("date")
    def validate_date_add_tzinfo(cls, value: datetime | str):
        if isinstance(value, str):
            # In the form of YYYY-MM-DD
            if len(value) == 10:
                try:
                    value = datetime.strptime(value, "%Y-%m-%d")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DD")
            else:
                try:
                    value = datetime.strptime(value, "%Y-%m-%dT%H:%M:%S%z")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DDTHH:mm:ssZZ")

        tz = value.tzinfo
        if tz:
            assert tz == pytz.UTC or tz == timezone.utc, "date should be UTC timezone"
        else:
            value = value.replace(tzinfo=pytz.UTC)
        return value

    brand: str = Field(...)
    currency: str = Field(...)
    gametype: str = Field(...)
    bet: float = Field(0)

    @validator("bet")
    def validate_bet_decimale_place(cls, value: float):

        return round(value, 2)

    pre_bet: float = Field(0)

    @validator("pre_bet")
    def validate_pre_bet_decimale_place(cls, value: float):

        return round(value, 2)

    pre_month_avg_bet: float = Field(0)

    @validator("pre_month_avg_bet")
    def validate_pre_month_avg_bet_decimale_place(cls, value: float):

        return round(value, 2)

    bet_day_diff: float = Field(0)

    @validator("bet_day_diff")
    def validate_bet_day_diff_decimale_place(cls, value: float):

        return round(value, 2)

    bet_month_avg_diff: float = Field(0)

    @validator("bet_month_avg_diff")
    def validate_bet_month_avg_diff_decimale_place(cls, value: float):

        return round(value, 2)

    rounds: int = Field(0)
    player: int = Field(0)


class SalesPerformanceGametypeKey(BaseModel):
    date: datetime | str

    @validator("date")
    def validate_date_add_tzinfo(cls, value: datetime | str):
        if isinstance(value, str):
            # In the form of YYYY-MM-DD
            if len(value) == 10:
                try:
                    value = datetime.strptime(value, "%Y-%m-%d")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DD")
            else:
                try:
                    value = datetime.strptime(value, "%Y-%m-%dT%H:%M:%S%z")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DDTHH:mm:ssZZ")

        tz = value.tzinfo
        if tz:
            assert tz == pytz.UTC or tz == timezone.utc, "date should be UTC timezone"
        else:
            value = value.replace(tzinfo=pytz.UTC)
        return value

    brand: str
    currency: str
    gametype: str


class SalesPerformanceGametypeUpdate(BaseModel):
    bet: Optional[float]

    @validator("bet")
    def validate_bet_decimale_place(cls, value: float):

        return round(value, 2)

    pre_bet: Optional[float]

    @validator("pre_bet")
    def validate_pre_bet_decimale_place(cls, value: float):

        return round(value, 2)

    pre_month_avg_bet: Optional[float]

    @validator("pre_month_avg_bet")
    def validate_pre_month_avg_bet_decimale_place(cls, value: float):

        return round(value, 2)

    bet_day_diff: Optional[float]

    @validator("bet_day_diff")
    def validate_bet_day_diff_decimale_place(cls, value: float):

        return round(value, 2)

    bet_month_avg_diff: Optional[float]

    @validator("bet_month_avg_diff")
    def validate_bet_month_avg_diff_decimale_place(cls, value: float):

        return round(value, 2)

    rounds: Optional[int]
    player: Optional[int]


class SalesPerformance(BaseModel):
    date: datetime | str = Field(
        ...,
        description="Python datetime or string of YYYY-MM-DD or YYYY-MM-DDTHH:mm:ssZZ",
    )

    @validator("date")
    def validate_date_add_tzinfo(cls, value: datetime | str):
        if isinstance(value, str):
            # In the form of YYYY-MM-DD
            if len(value) == 10:
                try:
                    value = datetime.strptime(value, "%Y-%m-%d")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DD")
            else:
                try:
                    value = datetime.strptime(value, "%Y-%m-%dT%H:%M:%S%z")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DDTHH:mm:ssZZ")

        tz = value.tzinfo
        if tz:
            assert tz == pytz.UTC or tz == timezone.utc, "date should be UTC timezone"
        else:
            value = value.replace(tzinfo=pytz.UTC)
        return value

    brand: str = Field(...)
    bet: float = Field(0)

    @validator("bet")
    def validate_bet_decimale_place(cls, value: float):

        return round(value, 2)

    net_win: float = Field(0)

    @validator("net_win")
    def validate_net_win_decimale_place(cls, value: float):

        return round(value, 2)

    player: int = Field(0)
    registered_player: int = Field(0)
    played_registered_player: int = Field(0)
    rounds: int = Field(0)

    def dict(self, *args, **kwargs):
        """
        Add kwargs: is_firebase
        Firebase's Message.data must not contain non-string values
        """
        is_firebase = kwargs.pop("is_firebase", [])
        d = super().dict(*args, **kwargs)
        if is_firebase:
            _update_d = {}
            for _k, _v in d.items():
                if _k in ["date"]:
                    _update_d[_k] = _v.strftime("%Y-%m-%d")
                elif _k in ["bet", "net_win"]:
                    _update_d[_k] = str(round(_v, 2))
                elif _k in [
                    "player",
                    "registered_player",
                    "played_registered_player",
                    "rounds",
                ]:
                    _update_d[_k] = str(_v)
            d.update(_update_d)

        return d


class SalesPerformanceKey(BaseModel):
    date: datetime | str

    @validator("date")
    def validate_date_add_tzinfo(cls, value: datetime | str):
        if isinstance(value, str):
            # In the form of YYYY-MM-DD
            if len(value) == 10:
                try:
                    value = datetime.strptime(value, "%Y-%m-%d")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DD")
            else:
                try:
                    value = datetime.strptime(value, "%Y-%m-%dT%H:%M:%S%z")
                except ValueError:
                    raise ValueError("The string of date must be YYYY-MM-DDTHH:mm:ssZZ")

        tz = value.tzinfo
        if tz:
            assert tz == pytz.UTC or tz == timezone.utc, "date should be UTC timezone"
        else:
            value = value.replace(tzinfo=pytz.UTC)
        return value

    brand: str


class SalesPerformanceUpdate(BaseModel):
    bet: Optional[float]

    @validator("bet")
    def validate_bet_decimale_place(cls, value: float):

        return round(value, 2)

    net_win: Optional[float]

    @validator("net_win")
    def validate_net_win_decimale_place(cls, value: float):

        return round(value, 2)

    player: Optional[int]
    registered_player: Optional[int]
    played_registered_player: Optional[int]
    rounds: Optional[int]


class HighWinOrderAlert(BaseModel):
    cls: str = Field(..., alias="_cls")
    message: str = Field("")
    alertLevel: str = Field(...)
    alertTime: datetime = Field(...)
    ownerID: str = Field(...)
    parentID: str = Field(...)
    gameType: str = Field(...)
    gameCode: str = Field(...)
    account: str = Field(...)
    playerID: str = Field(...)
    roundID: str = Field(...)
    gameToken: str = Field(...)
    bet: float = Field(...)
    win: float = Field(...)
    jackpot: float = Field(...)
    balance: float = Field(...)


class HighWinOrderAlertKey(BaseModel):
    cls: str = Field(..., alias="_cls")

    def dict(self, *args, **kwargs):
        attr_need_dash = kwargs.pop("attr_need_dash", [])
        d = super().dict(*args, **kwargs)
        if attr_need_dash:
            for k in attr_need_dash:
                if k in d:
                    _v = d.pop(k)
                    d["_" + k] = _v
        return d


class HighWinOrderAlertUpdate(BaseModel):
    pass
