from datetime import datetime
from typing import Optional

from pydantic import BaseModel


class AlertMessage(BaseModel):
    key: str
    topic: str
    message: str


class AuthUserAlertInfo(BaseModel):
    id: Optional[int] = None
    user_id: int
    alert_id: int
    createtime: Optional[datetime] = None
    updatetime: Optional[datetime] = None

    class Config:
        orm_mode = True


class AuthUserAlertInfoCreate(BaseModel):
    user_id: int
    alert_id: int


class AuthUserAlertInfoUpdate(BaseModel):
    user_id: Optional[int]
    alert_id: Optional[int]


class AlertInfo(BaseModel):
    id: Optional[int] = None
    key: str
    name: str
    topic: str
    createtime: Optional[datetime] = None
    updatetime: Optional[datetime] = None

    class Config:
        orm_mode = True


class AlertInfoCreate(BaseModel):
    key: str
    name: str
    topic: str


class AlertInfoUpdate(BaseModel):
    key: Optional[str]
    name: Optional[str]
    topic: Optional[str]
