from typing import Any, Optional
from enum import Enum, IntEnum
from datetime import datetime
import pytz

from pydantic import BaseModel, Field, validator
from firebase_admin import messaging


class TeamgatewayResult(BaseModel):
    data: Optional[Any]
    message: str


class FirebaseBasicNotification(BaseModel):
    data: Optional[dict]
    notification: Optional[messaging.Notification]
    topic: Optional[str]

    class Config:
        arbitrary_types_allowed = True


class MongoSort(IntEnum):
    desc = -1  # descendind
    ascd = 1  # ascending


class QueryDate(BaseModel):
    from_date: datetime | str = Field(
        ...,
        description="Query from date with 'from_date' <= [date]; Using python datetime or string of date in YYYY-MM-DD",
    )

    @validator("from_date")
    def validate_from_date_add_tzinfo(cls, value: datetime | str):
        if isinstance(value, str):
            try:
                value = datetime.strptime(value, "%Y-%m-%d")
            except ValueError:
                raise ValueError("The string of date must be YYYY-MM-DD")

        if value.tzinfo:
            assert value.tzinfo == pytz.UTC
        else:
            value = value.replace(tzinfo=pytz.UTC)
        return value

    to_date: datetime | str = Field(
        ...,
        description="Query from date with [date] < 'to_date'; Using python datetime or string of date in YYYY-MM-DD",
    )

    @validator("to_date")
    def validate_to_date_add_tzinfo(cls, value: datetime | str):
        if isinstance(value, str):
            try:
                value = datetime.strptime(value, "%Y-%m-%d")
            except ValueError:
                raise ValueError("The string of date must be YYYY-MM-DD")

        if value.tzinfo:
            assert value.tzinfo == pytz.UTC
        else:
            value = value.replace(tzinfo=pytz.UTC)
        return value


class BaseSummaryInfo(BaseModel):
    format_date: str
    bet: float = 0
    net_win: float = 0
    round: int = 0


class SummaryInfo(BaseSummaryInfo):
    playtime_sec: int = 0
    players: int = 0


class TimeUnitType(str, Enum):
    month = "month"
    day = "day"
    hour = "hour"
