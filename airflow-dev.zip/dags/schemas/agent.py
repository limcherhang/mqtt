from enum import Enum
from pydantic import BaseModel


class AgentType(str, Enum):
    parent = "parent"
    owner = "owner"


class AgentInfo(BaseModel):
    id: int
    account: str
    ssid: str
    oid: int
    oaccount: str
    agent_type: AgentType
