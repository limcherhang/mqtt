from pydantic import BaseModel


class PlayerBaseInfo(BaseModel):
    uid: int
    accounts: str
    user_ssid: str
    # date format: YYYY-mm-dd
    registered_date: str
