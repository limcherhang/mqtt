from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel

JSONstr = str


class CommandTaskDetail(BaseModel):
    """
    Celery /command task detail
    """

    user: str
    task_id: str
    taskname: str
    taskstatus: str
    taskinfo: JSONstr
    tasktime: datetime


class TaskResult(BaseModel):
    """
    Celery task result
    """

    taskid: str
    status: str
    name: Optional[str]
    message: Optional[str]
    data: Any = None
