import logging
from mysql.connector.cursor import MySQLCursor

logger = logging.getLogger("airflow.task")


def insert_with_update(cursor: MySQLCursor, value: tuple) -> str:

    stmt = "INSERT INTO dataAnalysis.rtp_record "
    stmt += "(oid, pid, uid, account, rtp, create_time, update_time, note) "
    stmt += "VALUES (%s, %s, %s, %s, %s, %s, %s, %s) "

    if value[7] is not None:
        stmt += "ON DUPLICATE KEY UPDATE rtp = %s, update_time = %s, note = %s, note_time = %s"
        value += (value[4], value[6], value[7], value[6])
    else:
        stmt += "ON DUPLICATE KEY UPDATE rtp = %s, update_time = %s"
        value += (value[4], value[6])

    cursor.execute(stmt, value)
    return "SUCCESS"
