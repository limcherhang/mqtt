import logging
from typing import Dict
from mysql.connector.cursor import MySQLCursor

logger = logging.getLogger("airflow.task")


def get_info_by_ssid(cursor: MySQLCursor, user_ssid: str) -> Dict[str, str | float]:

    stmt = "SELECT UL.userid, CAST(PLO.account AS CHAR), CAST(PLP.account AS CHAR), CAST(UL.account AS CHAR), FR.rate, "
    stmt += "UL.id, UL.ownerid, UL.parentid "
    stmt += "FROM cypress.user_list UL "
    stmt += "JOIN cypress.parent_list PLP ON UL.parentid = PLP.id "
    stmt += "JOIN cypress.parent_list PLO ON UL.ownerid = PLO.id "
    stmt += "JOIN cypress.fx_rate FR ON UL.currency = FR.short_name "
    stmt += f"WHERE UL.userid = '{user_ssid}' "

    cursor.execute(stmt)
    _user_info: tuple = cursor.fetchone()  # type: ignore
    logger.debug(f"Get info dict FRom player(user_ssid) info SUCCESS!")

    return {
        "ssid": _user_info[0],
        "owner": _user_info[1],
        "parent": _user_info[2],
        "account": _user_info[3],
        "rate": float(_user_info[4]),
        "id": _user_info[5],
        "oid": _user_info[6],
        "pid": _user_info[7],
    }
