import logging
from typing import List
from pendulum.datetime import DateTime as pendulum_datetime
from pymongo import MongoClient

logger = logging.getLogger("airflow.task")


def get_records(
    mongo_cnx: MongoClient,
    start_time: pendulum_datetime,
    end_time: pendulum_datetime,
) -> List[dict]:
    """
    Origin cypress teamgateway rtp record.
    """

    pipeline = [
        {"$match": {"updated_at": {"$gte": start_time, "$lt": end_time}}},
        {"$unwind": "$rtps"},
        {
            "$project": {
                "_id": 0,
                "parentid": 1,
                "playerid": 1,
                "rtps": 1,
                "updated_at": 1,
                "created_at": 1,
            }
        },
    ]

    result = list(mongo_cnx.float_rtp.players.aggregate(pipeline, allowDiskUse=True))
    logger.info(f"Get float rtp players success from {start_time} tp {end_time}!")

    return result
