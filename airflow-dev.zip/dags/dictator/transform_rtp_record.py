import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from datetime import timedelta
import logging
from itertools import groupby

from airflow.providers.mongo.hooks.mongo import MongoHook
from utils.connection.mysql import mysql_cursor
from dictator.crud.mongo import float_rtp
from dictator.crud import rtp_record
from dictator.crud import user

from airflow.decorators import dag, task

logger = logging.getLogger("airflow.task")

default_args = {
    "depends_on_past": False,
    "email": ["rmpeter0474@adcrow.tech"],
    "email_on_failure": True,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(seconds=10),
}


@dag(
    start_date=pendulum.datetime(2023, 1, 11, tz="UTC"),
    schedule="*/15 * * * *",
    default_args=default_args,
    catchup=False,
    max_active_tasks=4,
    tags=["PRO", "cq9", "dictator"],
)
def transform_rtp_record():
    """
    ### Transform RTP record
    Transform rtp record from mongo to mysql
    """

    @task()
    def transform(
        data_interval_end: pendulum_datetime = pendulum.now(),
        data_interval_start: pendulum_datetime = pendulum.now(),
    ):
        with (
            mysql_cursor(mysql_conn_id="mysql_master_write") as cursor,
            MongoHook(conn_id="mongo_read") as mongo_hook,
        ):
            mongo_cnx = mongo_hook.get_conn()

            new_records = float_rtp.get_records(
                mongo_cnx, data_interval_start, data_interval_end
            )
            logger.debug(new_records[:10])

            if not new_records:
                return

            key_fn = lambda value: value["playerid"]
            for player_ssid, _records in groupby(
                sorted(new_records, key=key_fn), key=key_fn
            ):
                user_info = user.get_info_by_ssid(cursor, player_ssid)

                if user_info is None:
                    logger.error(f"Player {player_ssid} FAILED to find information!")
                    continue

                logger.debug(user_info)
                record1st = list(_records)[0]
                create_time = record1st["created_at"]
                update_time = record1st["updated_at"]

                if float(record1st["rtps"]) >= 100:
                    insert_value = (
                        user_info["oid"],
                        user_info["pid"],
                        user_info["id"],
                        user_info["account"],
                        float(record1st["rtps"]),
                        create_time.strftime("%Y-%m-%d %H-%M-%S"),
                        update_time.strftime("%Y-%m-%d %H-%M-%S"),
                        "updated",
                    )
                else:
                    insert_value = (
                        user_info["oid"],
                        user_info["pid"],
                        user_info["id"],
                        user_info["account"],
                        float(record1st["rtps"]),
                        create_time.strftime("%Y-%m-%d %H-%M-%S"),
                        update_time.strftime("%Y-%m-%d %H-%M-%S"),
                        None,
                    )

                rtp_record.insert_with_update(cursor, insert_value)
            logger.info("Finish transferring RTP records!")

    transform()


transform_rtp_record_dag = transform_rtp_record()
