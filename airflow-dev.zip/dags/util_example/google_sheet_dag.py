from datetime import timedelta
import logging
import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
import os
from pathlib import Path

from airflow.decorators import dag, task

from utils.connection.google import OauthGSheetHook

logger = logging.getLogger("airflow.task")

default_args = {
    "depends_on_past": False,
    "email": ["rmpeter0474@adcrow.tech"],
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}


@dag(
    start_date=pendulum.today("UTC").add(days=-3),
    schedule=None,
    default_args=default_args,
    catchup=True,
    max_active_tasks=4,
    tags=["example"],
)
def google_sheet_example():
    """
    ### Google Sheet Example
    """

    @task()
    def update_sheet_value(data_interval_start: pendulum_datetime = pendulum.now()):
        """
        ### Udate google sheet values
        """

        test_spreadsheetid = "1IHfMl7UI9N4LiLFRKNFLkBWHgQgK9BS2DRm7Wug_3xw"
        update_range = "A2:C2"
        update_values = [
            ["test", 12315454.59, data_interval_start.format("YYYY-MM-DD")]
        ]
        hook = OauthGSheetHook(gcp_conn_id="google_report")

        hook.update_values(
            spreadsheet_id=test_spreadsheetid, range_=update_range, values=update_values
        )

    update_sheet_value()


google_sheet_example_dag = google_sheet_example()
