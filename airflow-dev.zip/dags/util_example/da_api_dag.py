from datetime import timedelta
import logging
import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
import tenacity
import json

from airflow.decorators import dag, task

from utils.connection.da_api import DAAPIHook

logger = logging.getLogger("airflow.task")

default_args = {
    "depends_on_past": False,
    "email": ["rmpeter0474@adcrow.tech"],
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}


@dag(
    start_date=pendulum.today("UTC").add(days=-3),
    schedule=None,
    default_args=default_args,
    catchup=True,
    max_active_tasks=4,
    tags=["example"],
)
def da_api_example():
    """
    ### DA-API Example
    """

    @task()
    def add_performance(data_interval_start: pendulum_datetime = pendulum.now()):
        """
        ### Add performace
        """
        hook = DAAPIHook()
        retry_args = dict(
            wait=tenacity.wait_exponential(),  # pyright: ignore [reportPrivateImportUsage]
            stop=tenacity.stop_after_attempt(  # pyright: ignore [reportPrivateImportUsage]
                10
            ),
            retry=tenacity.retry_if_exception_type(  # pyright: ignore [reportPrivateImportUsage]
                Exception
            ),
        )
        perform_dict = dict(date="2022-04-01", brand="airflowTest")
        hook.run_with_advanced_retry(
            "add_performance",
            performance_in=json.dumps(perform_dict),
            _retry_args=retry_args,
        )

    add_performance()


da_api_example_dag = da_api_example()
