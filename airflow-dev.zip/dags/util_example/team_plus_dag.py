from datetime import timedelta
import logging
import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
import tenacity

from airflow.decorators import dag, task
from utils.connection.team_plus import RMBotTeamPlusMessageHook

logger = logging.getLogger("airflow.task")

default_args = {
    "depends_on_past": False,
    "email": ["rmpeter0474@adcrow.tech"],
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}


@dag(
    start_date=pendulum.today("UTC").add(days=-3),
    schedule=None,
    default_args=default_args,
    catchup=True,
    max_active_tasks=4,
    tags=["example"],
)
def team_plus_example():
    """
    ### Team+ Example

    This is a Team+ hook usage example.
    `send_team_plus_msg` utilize RMBotTeamPlusMessageHook to send message to chennal 832.
    RMBotTeamPlusMessageHook default using:
    1. Connection conn-id='team_plus'
    2. The RM-Robot(風控機器人) account to send team+ message
    3. Request timeout in 10 seconds
    RMBotTeamPlusMessageHook can be executed by `run_with_advanced_retry` with
    parameters:
    1. chat: team+ group-chat channel
    2. message: string message
    3. _retry_args: retry-arg based on tenacity
    """

    @task()
    def send_team_plus_msg(data_interval_start: pendulum_datetime = pendulum.now()):
        """
        ### Sending team+ message

        Please follow the retry_arg setting while using the hook!
        """
        hook = RMBotTeamPlusMessageHook()
        retry_args = dict(
            wait=tenacity.wait_exponential(),  # pyright: ignore [reportPrivateImportUsage]
            stop=tenacity.stop_after_attempt(  # pyright: ignore [reportPrivateImportUsage]
                10
            ),
            retry=tenacity.retry_if_exception_type(  # pyright: ignore [reportPrivateImportUsage]
                Exception
            ),
        )
        msg = f"Hello from Airflow at {data_interval_start}"
        hook.run_with_advanced_retry(chat=832, message=msg, _retry_args=retry_args)

    send_team_plus_msg()


team_plus_example_dag = team_plus_example()
