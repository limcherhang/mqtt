from datetime import timedelta
import logging
import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
import os
from pathlib import Path

from airflow.decorators import dag, task

from utils.connection.google import OauthGoogleDriveHook

logger = logging.getLogger("airflow.task")

default_args = {
    "depends_on_past": False,
    "email": ["rmpeter0474@adcrow.tech"],
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}


@dag(
    start_date=pendulum.today("UTC").add(days=-3),
    schedule=None,
    default_args=default_args,
    catchup=True,
    max_active_tasks=4,
    tags=["example"],
)
def google_example():
    """
    ### Google Example
    """

    @task()
    def upload_file(data_interval_start: pendulum_datetime = pendulum.now()):
        """
        ### Upload Local File to Google Drive
        """
        import pandas as pd

        hook = OauthGoogleDriveHook(gcp_conn_id="google_report")

        local_file = Path("test_airflow.csv")
        df = pd.DataFrame([{"title": "test", "time": data_interval_start}])
        df.to_csv(os.path.join(Path.cwd(), local_file), index=False)
        remote_file_ids = []

        for local_path in [local_file]:
            logger.info("Uploading file to Google Drive: %s", local_path)

            remote_file_id = hook.upload_file(
                local_location=os.path.join(Path.cwd(), local_path),
                remote_location=local_path.name,
                google_drive_parentid="1YLrDfOESaip3IExeiumcSrVGIIDuXsgm",
            )
            remote_file_ids.append(remote_file_id)

        logger.info(f"Upload files: {remote_file_ids}")

    upload_file()


google_example_dag = google_example()
