from datetime import timedelta
import logging
import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
import tenacity

from airflow.decorators import dag, task
from utils.connection.telegram import TelegramMessageHook

logger = logging.getLogger("airflow.task")

default_args = {
    "depends_on_past": False,
    "email": ["rmpeter0474@adcrow.tech"],
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 0,
    "retry_delay": timedelta(minutes=5),
}


@dag(
    start_date=pendulum.datetime(2023, 1, 16),
    schedule=None,
    default_args=default_args,
    catchup=False,
    max_active_tasks=4,
    tags=["example"],
)
def telegram_example():
    """
    ### Telegram Example

    This is a Telegram hook usage example.
    `send_telegram_msg` utilize TelegramMessageHook to send message to chennal -1001899761231.
    TelegramMessageHook default using:
    1. Connection conn-id='telegrame_send'
    2. The DA-bot account to send telegram message
    3. Request timeout in 10 seconds
    TelegramMessageHook can be executed by `run_with_advanced_retry` with
    parameters:
    1. chat_id: telegram group-chat channel
    2. message: string message
    3. _retry_args: retry-arg based on tenacity
    """

    @task()
    def send_telegram_msg(data_interval_start: pendulum_datetime = pendulum.now()):
        """
        ### Sending telegram message

        Please follow the retry_arg setting while using the hook!
        """
        hook = TelegramMessageHook()
        retry_args = dict(
            wait=tenacity.wait_exponential(),  # pyright: ignore [reportPrivateImportUsage]
            stop=tenacity.stop_after_attempt(  # pyright: ignore [reportPrivateImportUsage]
                1
            ),
            retry=tenacity.retry_if_exception_type(  # pyright: ignore [reportPrivateImportUsage]
                Exception
            ),
        )
        msg = f"Hello from Airflow at {data_interval_start}"
        hook.run_with_advanced_retry(
            chat_id=-1001899761231, message=msg, _retry_args=retry_args
        )

    send_telegram_msg()


telegram_example_dag = telegram_example()
