import logging
from typing import List
from mysql.connector.cursor import MySQLCursor

logger = logging.getLogger("airflow.task")


def insert_win_multiple_stats(cursor: MySQLCursor, values: List[tuple]):
    stmt = "REPLACE INTO dataAnalysis.win_multiple_stats (date, oid, pid, gid, mulRange, players, rounds, bets, wins) "
    stmt += "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"

    cursor.executemany(stmt, values)
    logger.info("Insert win multiple stats SUCCESS!")


def insert_bet_distribution(cursor: MySQLCursor, values: List[tuple]):
    stmt = "REPLACE INTO dataAnalysis.bet_distribution (date, oid, pid, gid, bet, rounds, bets, wins) "
    stmt += "VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"

    cursor.executemany(stmt, values)
    logger.info("Insert bet distribution SUCCESS!")
