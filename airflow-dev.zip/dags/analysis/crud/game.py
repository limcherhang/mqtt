import logging
from mysql.connector.cursor import MySQLCursor

logger = logging.getLogger("airflow.task")


def code2id(cursor: MySQLCursor) -> dict:

    stmt = "SELECT game_code, id "
    stmt += "FROM cypress.game_list "

    logger.debug(stmt)
    cursor.execute(stmt)
    results = {str(gcode): gid for (gcode, gid) in list(cursor)}

    return results


def get_online_gid(cursor: MySQLCursor, brand: str = "cq9") -> list:

    stmt = "SELECT gid "
    stmt += "FROM MaReport.game_info "
    stmt += f"WHERE brand = '{brand}' AND status = 1 "

    logger.debug(stmt)
    cursor.execute(stmt)
    results = [gid for (gid,) in list(cursor)]

    return results
