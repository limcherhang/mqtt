import logging
from typing import List
from mysql.connector.cursor import MySQLCursor

logger = logging.getLogger("airflow.task")


def store_owners(cursor: MySQLCursor, rows: List[tuple]):
    stmt = "REPLACE INTO ReportStore.owner_grade_results "
    stmt += "(date, oid, avgDayBets, avgBetByRound, players, oneShotBetsRatio, avgDuration, vipPlayersRatio) "
    stmt += "VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"

    cursor.executemany(stmt, rows)


def store_games(cursor: MySQLCursor, rows: List[tuple]):
    stmt = "REPLACE INTO ReportStore.game_grade_results "
    stmt += "(date, gid, avgDayBets, avgBetByRound, players, oneShotBetsRatio, avgDuration, vipPlayersRatio, currency) "
    stmt += "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"

    cursor.executemany(stmt, rows)
