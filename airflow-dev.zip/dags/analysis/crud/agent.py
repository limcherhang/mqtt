import logging
from mysql.connector.cursor import MySQLCursor

logger = logging.getLogger("airflow.task")


def ssid2id(cursor: MySQLCursor) -> dict:

    stmt = "SELECT ssid, id "
    stmt += "FROM cypress.parent_list "

    logger.debug(stmt)
    cursor.execute(stmt)
    results = {ssid: id for (ssid, id) in list(cursor)}

    return results
