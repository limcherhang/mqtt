import logging
from typing import List
from pendulum.datetime import DateTime as pendulum_datetime
from pymongo import MongoClient

logger = logging.getLogger("airflow.task")


def get_win_multiple_stat(
    mongo_cnx: MongoClient,
    start_time: pendulum_datetime,
    end_time: pendulum_datetime,
) -> List[dict]:
    """
    Get grouped win-multiple-statistics from analysis.gameDetail
    """
    pipeline = [
        {"$match": {"startTime": {"$gte": start_time, "$lt": end_time}}},
        {
            "$project": {
                "startDate": {
                    "$dateToString": {"format": "%Y-%m-%d", "date": "$startTime"}
                },
                "ownerID": 1,
                "parentID": 1,
                "gameCode": 1,
                "playerID": 1,
                "multipleWinStats.mulRange": 1,
                "multipleWinStats.rounds": 1,
                "multipleWinStats.bets": 1,
                "multipleWinStats.wins": 1,
            }
        },
        {"$unwind": "$multipleWinStats"},
        {
            "$group": {
                "_id": {
                    "startDate": "$startDate",
                    "parentID": "$parentID",
                    "mulRange": "$multipleWinStats.mulRange",
                    "gameCode": "$gameCode",
                },
                "ownerID": {"$first": "$ownerID"},
                "bets": {"$sum": "$multipleWinStats.bets"},
                "wins": {"$sum": "$multipleWinStats.wins"},
                "rounds": {"$sum": "$multipleWinStats.rounds"},
                "players": {"$addToSet": "$playerID"},
            }
        },
        {
            "$project": {
                "_id": 0,
                "startDate": "$_id.startDate",
                "ownerID": 1,
                "parentID": "$_id.parentID",
                "gameCode": "$_id.gameCode",
                "mulRange": "$_id.mulRange",
                "playerCount": {"$size": "$players"},
                "rounds": 1,
                "bets": 1,
                "wins": 1,
            }
        },
    ]
    result = list(mongo_cnx.analysis.gameDetail.aggregate(pipeline, allowDiskUse=True))
    logger.info("Get day multiple stats SUCCESS!")

    return result


def get_bet_distribution(
    mongo_cnx: MongoClient,
    start_time: pendulum_datetime,
    end_time: pendulum_datetime,
) -> List[dict]:
    """
    Get grouped bet-distribution from analysis.gameDetail
    """
    pipeline = [
        {"$match": {"startTime": {"$gte": start_time, "$lt": end_time}}},
        {
            "$project": {
                "startDate": {
                    "$dateToString": {"format": "%Y-%m-%d", "date": "$startTime"}
                },
                "ownerID": 1,
                "parentID": 1,
                "gameCode": 1,
                "betInfos.bet": 1,
                "betInfos.rounds": 1,
                "betInfos.bets": 1,
                "betInfos.wins": 1,
            }
        },
        {"$unwind": "$betInfos"},
        {
            "$group": {
                "_id": {
                    "startDate": "$startDate",
                    "parentID": "$parentID",
                    "bet": {"$toInt": "$betInfos.bet"},
                    "gameCode": "$gameCode",
                },
                "ownerID": {"$first": "$ownerID"},
                "bets": {"$sum": "$betInfos.bets"},
                "wins": {"$sum": "$betInfos.wins"},
                "rounds": {"$sum": "$betInfos.rounds"},
            }
        },
        {
            "$project": {
                "_id": 0,
                "startDate": "$_id.startDate",
                "ownerID": 1,
                "parentID": "$_id.parentID",
                "gameCode": "$_id.gameCode",
                "bet": "$_id.bet",
                "rounds": 1,
                "bets": 1,
                "wins": 1,
            }
        },
    ]

    result = list(mongo_cnx.analysis.gameDetail.aggregate(pipeline, allowDiskUse=True))
    logger.info(f"Get day bet distribution from {start_time} to {end_time} SUCCESS!")

    return result
