import logging
from mysql.connector.cursor import MySQLCursor
from collections import namedtuple

logger = logging.getLogger("airflow.task")
GameBaseSummary = namedtuple(
    "GameBaseSummary", ("date", "gid", "bets", "rounds", "players")
)
GameUserDurationNTimes = namedtuple(
    "GameUserDurationNTimes", ("date", "gid", "uid", "times", "duration")
)
GameUsersTotalBet = namedtuple("GameUsersTotalBet", ("date", "gid", "bets"))
GameVIPSummary = namedtuple("GameVIPSummary", ("date", "gid", "counts", "bets"))
OwnerBaseSummary = namedtuple(
    "OwnerBaseSummary", ("date", "oid", "bets", "rounds", "players")
)
OwnerUserDurationNTimes = namedtuple(
    "OwnerUserDurationNTimes", ("date", "oid", "uid", "times", "duration")
)
OwnerUsersTotalBet = namedtuple("OwnerUsersTotalBet", ("date", "oid", "bets"))
OwnerVIPSummary = namedtuple("OwnerVIPSummary", ("date", "oid", "counts", "bets"))


def get_vip_info_with_games(
    cursor: MySQLCursor,
    from_time: str,
    to_time: str,
    vip_bet_threshold: int,
    currency: str,
    gids: list,
) -> list[GameVIPSummary]:
    """
    For game grade resource vip info.
    'date', 'gid', 'countsVIP', 'betsVIP'
    """

    stmt = f"SELECT '{from_time}', o.gid, COUNT(DISTINCT o.uid), SUM(o.bets) "
    stmt += "FROM ( "
    stmt += "  SELECT ug.gid, ug.uid, DATE(ug.date) d_date, SUM(ug.total_bet/rpl.rate) bets "
    stmt += "  FROM cypress.statistic_user_by_game ug "
    stmt += "  JOIN cypress.user_list ul ON ug.uid = ul.id"
    stmt += "  JOIN MaReport.report_parent_list rpl ON ul.parentid = rpl.pid "
    stmt += f"   AND FIND_IN_SET(rpl.currency, '{currency}') "
    stmt += f" WHERE ug.date >= '{from_time}' AND ug.date < DATE_SUB('{to_time}', INTERVAL 1 SECOND) "
    stmt += f"   AND ug.gid IN ({','.join(gids)}) "
    stmt += "  GROUP BY ug.gid, ug.uid, d_date "
    stmt += "  UNION ALL "
    stmt += "  SELECT ug.gid, ug.uid, DATE(ug.date) d_date, SUM(ug.total_bet/rpl.rate) bets "
    stmt += "  FROM cypress.statistic_user_by_tablegame ug "
    stmt += "  JOIN cypress.user_list ul ON ug.uid = ul.id"
    stmt += "  JOIN MaReport.report_parent_list rpl ON ul.parentid = rpl.pid "
    stmt += f"   AND FIND_IN_SET(rpl.currency, '{currency}') "
    stmt += f" WHERE ug.date >= '{from_time}' AND ug.date < DATE_SUB('{to_time}', INTERVAL 1 SECOND) "
    stmt += f"   AND ug.gid IN ({','.join(gids)}) "
    stmt += "  GROUP BY ug.gid, ug.uid, d_date "
    stmt += "  UNION ALL "
    stmt += "  SELECT ug.gid, ug.uid, DATE(ug.date) d_date, SUM(ug.total_bet/rpl.rate) bets "
    stmt += "  FROM cypress.statistic_user_by_lottogame ug "
    stmt += "  JOIN cypress.user_list ul ON ug.uid = ul.id"
    stmt += "  JOIN MaReport.report_parent_list rpl ON ul.parentid = rpl.pid "
    stmt += f"   AND FIND_IN_SET(rpl.currency, '{currency}') "
    stmt += f" WHERE ug.date >= '{from_time}' AND ug.date < DATE_SUB('{to_time}', INTERVAL 1 SECOND) "
    stmt += f"   AND ug.gid IN ({','.join(gids)}) "
    stmt += "  GROUP BY ug.gid, ug.uid, d_date) o "
    stmt += f"WHERE o.bets >= {vip_bet_threshold} "
    stmt += "GROUP BY o.gid "

    logger.debug(stmt)
    cursor.execute(stmt)
    result = [
        GameVIPSummary(_info[0], _info[1], _info[2], _info[3]) for _info in list(cursor)
    ]
    logger.debug("Get VIP info SUCCESS!")

    return result


def get_users_bet_with_games(
    cursor: MySQLCursor, from_time: str, to_time: str, uids: list[str], gid: int
) -> list[GameUsersTotalBet]:
    """
    For game grade resources one shot info.
    'date', 'gid', 'bets'
    """

    stmt = f"SELECT '{from_time}', {gid}, SUM(o.bets) "
    stmt += "FROM ( "
    stmt += "  SELECT SUM(ug.total_bet/fr.rate) bets "
    stmt += "  FROM cypress.statistic_user_by_game ug "
    stmt += (
        f' JOIN cypress.user_list ul ON ug.uid = ul.id AND ul.id IN ({",".join(uids)}) '
    )
    stmt += "  JOIN cypress.fx_rate fr ON ul.currency = fr.short_name "
    stmt += f" WHERE ug.date >= '{from_time}' AND ug.date < DATE_SUB('{to_time}', INTERVAL 1 SECOND) "
    stmt += f"   AND ug.gid = {gid} "
    stmt += "  UNION ALL "
    stmt += "  SELECT SUM(ug.total_bet/fr.rate) bets "
    stmt += "  FROM cypress.statistic_user_by_tablegame ug "
    stmt += (
        f' JOIN cypress.user_list ul ON ug.uid = ul.id AND ul.id IN ({",".join(uids)}) '
    )
    stmt += "  JOIN cypress.fx_rate fr ON ul.currency = fr.short_name "
    stmt += f" WHERE ug.date >= '{from_time}' AND ug.date < DATE_SUB('{to_time}', INTERVAL 1 SECOND) "
    stmt += f"   AND ug.gid = {gid} "
    stmt += "  UNION ALL "
    stmt += "  SELECT SUM(ug.total_bet/fr.rate) bets "
    stmt += "  FROM cypress.statistic_user_by_lottogame ug "
    stmt += (
        f' JOIN cypress.user_list ul ON ug.uid = ul.id AND ul.id IN ({",".join(uids)}) '
    )
    stmt += "  JOIN cypress.fx_rate fr ON ul.currency = fr.short_name "
    stmt += f" WHERE ug.date >= '{from_time}' AND ug.date < DATE_SUB('{to_time}', INTERVAL 1 SECOND) "
    stmt += f"   AND ug.gid = {gid}) o "

    cursor.execute(stmt)
    result = [GameUsersTotalBet(_info[0], _info[1], _info[2]) for _info in list(cursor)]
    logger.debug(f"Get players bet by game({gid}) SUCCESS!")

    return result


def get_duration_n_play_times_with_games(
    cursor: MySQLCursor, from_time: str, to_time: str, currency: str, gids: list[str]
) -> list[GameUserDurationNTimes]:
    """
    For game grade resources duration and played-times.
    'date', 'gid', 'uid', 'times', 'duration'
    """

    stmt = f"SELECT '{from_time}', gi.gid, ul.id, COUNT(DISTINCT DATE(ugl.date)), "
    stmt += "  (CASE SUM(TIMESTAMPDIFF(MINUTE,starttime,endtime)) WHEN 0 "
    stmt += "  THEN 1 ELSE SUM(TIMESTAMPDIFF(MINUTE,starttime,endtime)) END) "
    stmt += "FROM MaReport.user_gametoken_log ugl "
    stmt += "JOIN cypress.user_list ul ON ugl.userid = ul.userid "
    stmt += f"JOIN MaReport.report_parent_list rpl ON ul.parentid = rpl.pid "
    stmt += f"  AND ugl.date >= rpl.onlinetime_t AND FIND_IN_SET(rpl.currency, '{currency}') "
    stmt += "JOIN MaReport.game_info gi ON ugl.game_code = gi.game_code "
    stmt += f"  AND gi.gid IN ({','.join(gids)}) AND ugl.date >= gi.onlinetime_t "
    stmt += f"WHERE ugl.date >= '{from_time}' AND ugl.date < DATE_SUB('{to_time}', INTERVAL 1 SECOND) "
    stmt += "GROUP BY ugl.userid, ugl.game_code "

    logger.debug(stmt)
    cursor.execute(stmt)

    result = [
        GameUserDurationNTimes(_info[0], _info[1], _info[2], _info[3], _info[4])
        for _info in list(cursor)
    ]
    logger.info("Get players duration and times with game SUCCESS!")

    return result


def get_with_games(
    cursor: MySQLCursor, from_time: str, to_time: str, currency: str, gids: list
) -> list[GameBaseSummary]:
    """
    For game grade resources first step data.
    'date', 'gid', 'bets', 'rounds', 'players'
    """

    stmt = f"SELECT '{from_time}', O.gid, SUM(O.bets), SUM(O.rounds), COUNT(DISTINCT O.uid) "
    stmt += "FROM ( "
    stmt += "  SELECT UG.gid, UG.uid, SUM(UG.total_bet/RPL.rate) bets, SUM(UG.total_round) rounds "
    stmt += "  FROM cypress.statistic_user_by_game UG "
    stmt += "  JOIN cypress.user_list UL ON UG.uid = UL.id "
    stmt += f" JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid "
    stmt += f"   AND FIND_IN_SET(RPL.currency, '{currency}') "
    stmt += f" WHERE UG.date >= '{from_time}' AND UG.date < DATE_SUB('{to_time}', INTERVAL 1 SECOND) "
    stmt += f'   AND UG.gid IN ({",".join(gids)}) '
    stmt += "  GROUP BY UG.uid, UG.gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT UG.gid, UG.uid, SUM(UG.total_bet/RPL.rate) bets, SUM(UG.total_round) rounds "
    stmt += "  FROM cypress.statistic_user_by_tablegame UG "
    stmt += "  JOIN cypress.user_list UL ON UG.uid = UL.id "
    stmt += f" JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid "
    stmt += f"   AND FIND_IN_SET(RPL.currency, '{currency}') "
    stmt += f" WHERE UG.date >= '{from_time}' AND UG.date < DATE_SUB('{to_time}', INTERVAL 1 SECOND) "
    stmt += f'   AND UG.gid IN ({",".join(gids)}) '
    stmt += "  GROUP BY UG.uid, UG.gid "
    stmt += "  UNION ALL "
    stmt += "  SELECT UG.gid, UG.uid, SUM(UG.total_bet/RPL.rate) bets, SUM(UG.total_bet_count) rounds "
    stmt += "  FROM cypress.statistic_user_by_lottogame UG "
    stmt += "  JOIN cypress.user_list UL ON UG.uid = UL.id"
    stmt += f" JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid "
    stmt += f"   AND FIND_IN_SET(RPL.currency, '{currency}') "
    stmt += f" WHERE UG.date >= '{from_time}' AND UG.date < DATE_SUB('{to_time}', INTERVAL 1 SECOND) "
    stmt += f'   AND UG.gid IN ({",".join(gids)}) '
    stmt += "  GROUP BY UG.uid, UG.gid) O "
    stmt += "GROUP BY O.gid "

    logger.debug(stmt)
    cursor.execute(stmt)

    _result = [
        GameBaseSummary(_info[0], _info[1], _info[2], _info[3], _info[4])
        for _info in list(cursor)
    ]
    logger.info("Get summary with game SUCCESS!")

    return _result


def get_currency_grade_game(cursor: MySQLCursor, from_time: str, to_time: str) -> list:

    stmt = "SELECT display_currency, GROUP_CONCAT(currency) AS query_currency "
    stmt += "FROM ( "
    stmt += "  SELECT CASE WHEN currency = 'MMKP1' THEN 'MMK' "
    stmt += "          ELSE REGEXP_REPLACE(currency, '([(].*[)])', '') END AS display_currency, "
    stmt += "      currency "
    stmt += "  FROM ( "
    stmt += "    SELECT DISTINCT currency "
    stmt += "    FROM cypress.statistic_parent_by_game PG "
    stmt += "    JOIN MaReport.report_parent_list RPL ON PG.pid = RPL.pid "
    stmt += "    JOIN MaReport.game_info GI ON PG.gid = GI.gid AND GI.status = 1 AND PG.date >= GI.onlinetime "
    stmt += f"   WHERE PG.date >= '{from_time}' AND PG.date < '{to_time}' "
    stmt += "    UNION ALL "
    stmt += "    SELECT DISTINCT currency "
    stmt += "    FROM cypress.statistic_parent_by_tablegame PG "
    stmt += "    JOIN MaReport.report_parent_list RPL ON PG.pid = RPL.pid "
    stmt += "    JOIN MaReport.game_info GI ON PG.gid = GI.gid AND GI.status = 1 AND PG.date >= GI.onlinetime "
    stmt += f"   WHERE PG.date >= '{from_time}' AND PG.date < '{to_time}' "
    stmt += "    UNION ALL "
    stmt += "    SELECT DISTINCT currency "
    stmt += "    FROM cypress.statistic_parent_by_lottogame PG "
    stmt += "    JOIN MaReport.report_parent_list RPL ON PG.pid = RPL.pid "
    stmt += "    JOIN MaReport.game_info GI ON PG.gid = GI.gid AND GI.status = 1 AND PG.date >= GI.onlinetime "
    stmt += f"   WHERE PG.date >= '{from_time}' AND PG.date < '{to_time}' "
    stmt += "  ) ALL_CURRENCY "
    stmt += "  GROUP BY currency) QUERY_CUR "
    stmt += "GROUP BY display_currency "
    logger.debug(stmt)

    cursor.execute(stmt)
    result = list(cursor)
    logger.info("Get currency for grading games SUCCESS!")

    return result


def get_vip_info_with_owners(
    cursor: MySQLCursor,
    from_time: str,
    to_time: str,
    big_bet_ratio: float,
    vip_bet_threshold: int,
) -> list[OwnerVIPSummary]:
    """
    For owner grade resource vip info.
    columns=['date', 'oid', 'counts', 'bets']
    """

    stmt = f"SELECT '{from_time}', OAUG.oid, (COUNT(DISTINCT (CASE WHEN (OAUG.bets >= RO.bets*{big_bet_ratio:.2f} OR OAUG.bets >= {vip_bet_threshold}) THEN OAUG.uid ELSE 0 END)) - 1), "
    stmt += f"SUM(CASE WHEN (OAUG.bets >= RO.bets*{big_bet_ratio:.2f} OR  OAUG.bets >= {vip_bet_threshold}) THEN OAUG.bets ELSE 0 END) FROM ( "
    stmt += "SELECT DATE_FORMAT(OUG.d_date, '%Y-%m-%d') dt, OUG.oid, OUG.uid, SUM(OUG.bets) bets "
    stmt += "FROM ( "
    stmt += "  SELECT UL.ownerid oid, UG.uid, DATE(UG.date) d_date, SUM(UG.total_bet/RPL.rate) bets "
    stmt += "  FROM cypress.statistic_user_by_game UG "
    stmt += "  JOIN cypress.user_list UL ON UG.uid = UL.id"
    stmt += "  JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid "
    stmt += f" WHERE (UG.date BETWEEN '{from_time}' AND DATE_SUB('{to_time}', INTERVAL 1 SECOND)) "
    stmt += "    AND EXISTS (SELECT 1 FROM MaReport.game_info GI WHERE UG.gid = GI.gid AND GI.brand = 'cq9') "
    stmt += "  GROUP BY UG.uid, d_date "
    stmt += "  UNION ALL "
    stmt += "  SELECT UL.ownerid oid, UG.uid, DATE(UG.date) d_date, SUM(UG.total_bet/RPL.rate) bets "
    stmt += "  FROM cypress.statistic_user_by_tablegame UG "
    stmt += "  JOIN cypress.user_list UL ON UG.uid = UL.id"
    stmt += "  JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid "
    stmt += f" WHERE (UG.date BETWEEN '{from_time}' AND DATE_SUB('{to_time}', INTERVAL 1 SECOND)) "
    stmt += "    AND EXISTS (SELECT 1 FROM MaReport.game_info GI WHERE UG.gid = GI.gid AND GI.brand = 'cq9') "
    stmt += "  GROUP BY UG.uid, d_date "
    stmt += "  UNION ALL "
    stmt += "  SELECT UL.ownerid oid, UG.uid, DATE(UG.date) d_date, SUM(UG.total_bet/RPL.rate) bets "
    stmt += "  FROM cypress.statistic_user_by_lottogame UG "
    stmt += "  JOIN cypress.user_list UL ON UG.uid = UL.id"
    stmt += "  JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid "
    stmt += f" WHERE (UG.date BETWEEN '{from_time}' AND DATE_SUB('{to_time}', INTERVAL 1 SECOND)) "
    stmt += "    AND EXISTS (SELECT 1 FROM MaReport.game_info GI WHERE UG.gid = GI.gid AND GI.brand = 'cq9') "
    stmt += "  GROUP BY UG.uid, d_date) OUG "
    stmt += "GROUP BY OUG.uid, OUG.d_date) OAUG "
    stmt += "JOIN MaReport.owner_info OI ON OAUG.oid = OI.id "
    stmt += f"JOIN MaReport.report_by_owner_daily RO ON OI.owner = RO.owner AND OAUG.dt = RO.date AND RO.date >= '{from_time}' AND RO.date < '{to_time}' AND RO.currency = 'ALL' "
    stmt += "GROUP BY OAUG.oid "

    logger.debug(stmt)
    cursor.execute(stmt)
    result = [
        OwnerVIPSummary(_info[0], _info[1], _info[2], _info[3])
        for _info in list(cursor)
    ]
    logger.debug("Get VIP info SUCCESS!")

    return result


def get_users_bet_with_owners(
    cursor: MySQLCursor, from_time: str, to_time: str, uids: list
) -> list[OwnerUsersTotalBet]:
    """
    For owner grade resources one shot info.
    columns=['date', 'oid', 'bets']
    """

    stmt = f"SELECT '{from_time}', OUG.oid, SUM(OUG.bets) "
    stmt += "FROM ( "
    stmt += "  SELECT UL.ownerid oid, SUM(UG.total_bet/FR.rate) bets "
    stmt += "  FROM cypress.statistic_user_by_game UG "
    stmt += (
        f" JOIN cypress.user_list UL ON UG.uid = UL.id AND UL.id IN ({','.join(uids)}) "
    )
    stmt += "  JOIN cypress.fx_rate FR ON UL.currency = FR.short_name "
    stmt += f" WHERE (UG.date BETWEEN '{from_time}' AND DATE_SUB('{to_time}', INTERVAL 1 SECOND)) "
    stmt += "    AND EXISTS (SELECT 1 FROM MaReport.game_info GI WHERE UG.gid = GI.gid AND GI.brand = 'cq9') "
    stmt += "  GROUP BY UL.ownerid "
    stmt += "  UNION ALL "
    stmt += "  SELECT UL.ownerid oid, SUM(UG.total_bet/FR.rate) bets "
    stmt += "  FROM cypress.statistic_user_by_tablegame UG "
    stmt += (
        f" JOIN cypress.user_list UL ON UG.uid = UL.id AND UL.id IN ({','.join(uids)}) "
    )
    stmt += "  JOIN cypress.fx_rate FR ON UL.currency = FR.short_name "
    stmt += f" WHERE (UG.date BETWEEN '{from_time}' AND DATE_SUB('{to_time}', INTERVAL 1 SECOND)) "
    stmt += "    AND EXISTS (SELECT 1 FROM MaReport.game_info GI WHERE UG.gid = GI.gid AND GI.brand = 'cq9') "
    stmt += "  GROUP BY UL.ownerid "
    stmt += "  UNION ALL "
    stmt += "  SELECT UL.ownerid oid, SUM(UG.total_bet/FR.rate) bets "
    stmt += "  FROM cypress.statistic_user_by_lottogame UG "
    stmt += (
        f" JOIN cypress.user_list UL ON UG.uid = UL.id AND UL.id IN ({','.join(uids)}) "
    )
    stmt += "  JOIN cypress.fx_rate FR ON UL.currency = FR.short_name "
    stmt += f" WHERE (UG.date BETWEEN '{from_time}' AND DATE_SUB('{to_time}', INTERVAL 1 SECOND)) "
    stmt += "    AND EXISTS (SELECT 1 FROM MaReport.game_info GI WHERE UG.gid = GI.gid AND GI.brand = 'cq9') "
    stmt += "  GROUP BY UL.ownerid) OUG "
    stmt += "GROUP BY OUG.oid;"

    cursor.execute(stmt)

    result = [
        OwnerUsersTotalBet(_info[0], _info[1], _info[2]) for _info in list(cursor)
    ]
    logger.debug(
        f"Get selected players bet with owner from {from_time} to {to_time} SUCCESS!"
    )

    return result


def get_user_duration_n_times_with_owners(
    cursor: MySQLCursor, from_time: str, to_time: str
) -> list[OwnerUserDurationNTimes]:
    """
    For owner grade resources duration and played-times.
    columns=['date', 'oid', 'uid', 'times', 'duration']
    """

    stmt = f"SELECT '{from_time}', UL.ownerid, UL.id, COUNT(DISTINCT DATE(UGL.date)), "
    stmt += "  (CASE SUM(TIMESTAMPDIFF(MINUTE,starttime,endtime)) WHEN 0 "
    stmt += "  THEN 1 ELSE SUM(TIMESTAMPDIFF(MINUTE,starttime,endtime)) END) "
    stmt += "FROM MaReport.user_gametoken_log UGL "
    stmt += "JOIN cypress.user_list UL ON UGL.userid = UL.userid "
    stmt += "JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid AND UGL.date >= RPL.onlinetime_t "
    stmt += f"WHERE (UGL.date BETWEEN '{from_time}' AND DATE_SUB('{to_time}', INTERVAL 1 SECOND)) "
    stmt += "  AND EXISTS (SELECT 1 FROM MaReport.game_info GI "
    stmt += "  WHERE UGL.game_code = GI.game_code AND GI.brand = 'cq9' AND UGL.date >= GI.onlinetime_t) "
    stmt += "GROUP BY UGL.userid "

    logger.debug(stmt)
    cursor.execute(stmt)

    result = [
        OwnerUserDurationNTimes(_info[0], _info[1], _info[2], _info[3], _info[4])
        for _info in list(cursor)
    ]
    logger.info(
        f"Get owners-players duration and times from {from_time} to {to_time} SUCCESS!"
    )

    return result


def get_with_owners(
    cursor: MySQLCursor, from_time: str, to_time: str
) -> list[OwnerBaseSummary]:
    """
    For owner grade resources first step data.
    columns=['date', 'oid', 'bets', 'rounds', 'players']
    """

    stmt = f"SELECT '{from_time}', OG.oid, SUM(OG.bets), SUM(OG.rounds), COUNT(DISTINCT OG.uid) "
    stmt += "FROM ( "
    stmt += "  SELECT UL.ownerid oid, UG.uid, SUM(UG.total_bet/RPL.rate) bets, SUM(UG.total_round) rounds "
    stmt += "  FROM cypress.statistic_user_by_game UG "
    stmt += "  JOIN cypress.user_list UL ON UG.uid = UL.id"
    stmt += "  JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid"
    stmt += f" WHERE (UG.date BETWEEN '{from_time}' AND DATE_SUB('{to_time}', INTERVAL 1 SECOND)) "
    stmt += "    AND EXISTS (SELECT 1 FROM MaReport.game_info GI WHERE UG.gid = GI.gid AND GI.brand = 'cq9') "
    stmt += "  GROUP BY UG.uid "
    stmt += "  UNION ALL "
    stmt += "  SELECT UL.ownerid oid, UG.uid, SUM(UG.total_bet/RPL.rate) bets, SUM(UG.total_round) rounds "
    stmt += "  FROM cypress.statistic_user_by_tablegame UG "
    stmt += "  JOIN cypress.user_list UL ON UG.uid = UL.id"
    stmt += "  JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid"
    stmt += f" WHERE (UG.date BETWEEN '{from_time}' AND DATE_SUB('{to_time}', INTERVAL 1 SECOND)) "
    stmt += "    AND EXISTS (SELECT 1 FROM MaReport.game_info GI WHERE UG.gid = GI.gid AND GI.brand = 'cq9') "
    stmt += "  GROUP BY UG.uid "
    stmt += "  UNION ALL "
    stmt += "  SELECT UL.ownerid oid, UG.uid, SUM(UG.total_bet/RPL.rate) bets, SUM(UG.total_bet_count) rounds "
    stmt += "  FROM cypress.statistic_user_by_lottogame UG "
    stmt += "  JOIN cypress.user_list UL ON UG.uid = UL.id"
    stmt += "  JOIN MaReport.report_parent_list RPL ON UL.parentid = RPL.pid"
    stmt += f" WHERE (UG.date BETWEEN '{from_time}' AND DATE_SUB('{to_time}', INTERVAL 1 SECOND)) "
    stmt += "    AND EXISTS (SELECT 1 FROM MaReport.game_info GI WHERE UG.gid = GI.gid AND GI.brand = 'cq9') "
    stmt += "  GROUP BY UG.uid) OG "
    stmt += "GROUP BY OG.oid;"

    logger.debug(stmt)
    cursor.execute(stmt)

    result = [
        OwnerBaseSummary(_info[0], _info[1], _info[2], _info[3], _info[4])
        for _info in list(cursor)
    ]
    logger.info(f"Get summary with owners from {from_time} to {to_time} SUCCESS!")

    return result
