import logging
from mysql.connector.cursor import MySQLCursor

logger = logging.getLogger("airflow.task")


def get_game_info_by_currency(
    cursor: MySQLCursor, from_time: str, to_time: str, currency: str
) -> list:
    """
    'date', 'gid',
    'bets', 'avgBetByRound', 'players',
    'oneShotBetsRatio', 'avgDuration', 'vipPlayersRatio',
    'onlinetime'
    """
    stmt = "SELECT GG.date, GG.gid, GG.bets, "
    stmt += "GG.bets/GG.rounds, GG.players, GG.oneShotBets/GG.bets, "
    stmt += "GG.avgDuration, GG.vipPlayers/GG.players, GI.onlinetime "
    stmt += "FROM ReportStore.game_grade_resources GG "
    stmt += "JOIN MaReport.game_info GI ON GG.gid = GI.gid AND GI.brand = 'cq9' "
    stmt += f"WHERE GG.date >= '{from_time}' AND GG.date < '{to_time}' "
    stmt += f"AND GG.bets > 0 AND FIND_IN_SET(GG.currency, '{currency}'); "

    cursor.execute(stmt)

    result = list(cursor)
    logger.info(f"Get {currency} game grade resources SUCCESS!")

    return result


def insert_game_vip(cursor: MySQLCursor, rows: list[tuple]):

    stmt = "INSERT INTO ReportStore.game_grade_resources "
    stmt += "(date, gid, vipPlayers, vipBets, currency) "
    stmt += "VALUES (%s, %s, %s, %s, %s) "
    stmt += "ON DUPLICATE KEY UPDATE vipPlayers=VALUES(vipPlayers),  vipBets=VALUES(vipBets) "

    cursor.executemany(stmt, rows)


def insert_game_one_shots(cursor: MySQLCursor, rows: list[tuple]):

    stmt = "INSERT INTO ReportStore.game_grade_resources "
    stmt += "(date, gid, oneShotPlayers, oneShotBets, currency) "
    stmt += "VALUES (%s, %s, %s, %s, %s) "
    stmt += "ON DUPLICATE KEY UPDATE oneShotPlayers=VALUES(oneShotPlayers),  oneShotBets=VALUES(oneShotBets) "

    cursor.executemany(stmt, rows)


def insert_game_duration(cursor: MySQLCursor, rows: list[tuple]):

    stmt = "INSERT INTO ReportStore.game_grade_resources "
    stmt += "(date, gid, avgDuration, currency) "
    stmt += "VALUES (%s, %s, %s, %s) "
    stmt += "ON DUPLICATE KEY UPDATE avgDuration=VALUES(avgDuration) "

    cursor.executemany(stmt, rows)


def insert_game_summary(cursor: MySQLCursor, rows: list[tuple]):
    """
    Game grading on summary including: bets, rounds, players
    """

    stmt = "INSERT INTO ReportStore.game_grade_resources "
    stmt += "(date, gid, bets, rounds, players, currency) "
    stmt += "VALUES (%s, %s, %s, %s, %s, %s) "
    stmt += "ON DUPLICATE KEY UPDATE bets=VALUES(bets), rounds=VALUES(rounds), players=VALUES(players) "

    cursor.executemany(stmt, rows)


def get_owner_info(cursor: MySQLCursor, from_time: str, to_time: str) -> list:
    """
    'date', 'oid',
    'bets', 'avgBetByRound', 'players',
    'oneShotBetsRatio', 'avgDuration', 'vipPlayersRatio',
    'onlinetime'
    """

    stmt = "SELECT OG.date, OG.oid, OG.bets, "
    stmt += "OG.bets/OG.rounds, OG.players, OG.oneShotBets/OG.bets, "
    stmt += "OG.avgDuration, OG.vipPlayers/OG.players, OI.onlinetime "
    stmt += "FROM ReportStore.owner_grade_resources OG "
    stmt += "JOIN MaReport.owner_info OI ON OG.oid = OI.id "
    stmt += (
        f"WHERE OG.date >= '{from_time}' AND OG.date < '{to_time}' AND OG.bets > 0; "
    )

    cursor.execute(stmt)
    result = list(cursor)
    logger.info("Get owners grade resources SUCCESS!")

    return result


def insert_owner_vip(cursor: MySQLCursor, rows: list[tuple]):

    stmt = "INSERT INTO ReportStore.owner_grade_resources "
    stmt += "(date, oid, vipPlayers, vipBets) "
    stmt += "VALUES (%s, %s, %s, %s) "
    stmt += "ON DUPLICATE KEY UPDATE vipPlayers=VALUES(vipPlayers),  vipBets=VALUES(vipBets) "

    cursor.executemany(stmt, rows)


def insert_owner_one_shots(cursor: MySQLCursor, rows: list[tuple]):

    stmt = "INSERT INTO ReportStore.owner_grade_resources "
    stmt += "(date, oid, oneShotPlayers, oneShotBets) "
    stmt += "VALUES (%s, %s, %s, %s) "
    stmt += "ON DUPLICATE KEY UPDATE oneShotPlayers=VALUES(oneShotPlayers),  oneShotBets=VALUES(oneShotBets) "

    cursor.executemany(stmt, rows)


def insert_owner_duration(cursor: MySQLCursor, rows: list[tuple]):

    stmt = "INSERT INTO ReportStore.owner_grade_resources "
    stmt += "(date, oid, avgDuration) "
    stmt += "VALUES (%s, %s, %s) "
    stmt += "ON DUPLICATE KEY UPDATE avgDuration=VALUES(avgDuration) "

    cursor.executemany(stmt, rows)


def insert_owner_summary(cursor: MySQLCursor, rows: list[tuple]):
    """
    Onwer grading on summary including: bets, rounds, players
    """

    stmt = "INSERT INTO ReportStore.owner_grade_resources "
    stmt += "(date, oid, bets, rounds, players) "
    stmt += "VALUES (%s, %s, %s, %s, %s) "
    stmt += "ON DUPLICATE KEY UPDATE bets=VALUES(bets), rounds=VALUES(rounds), players=VALUES(players) "

    cursor.executemany(stmt, rows)
