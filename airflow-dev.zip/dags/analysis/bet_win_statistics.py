import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from datetime import timedelta
import logging

from airflow.decorators import dag, task
from airflow.providers.mongo.hooks.mongo import MongoHook
from utils.connection.mysql import mysql_cursor

from analysis.crud.bet_win_statistics import (
    insert_bet_distribution,
    insert_win_multiple_stats,
)
from analysis.crud.mongo import gamedetail
from analysis.crud import game, agent

logger = logging.getLogger("airflow.task")

default_args = {
    "depends_on_past": False,
    "email": ["rmpeter0474@adcrow.tech"],
    "email_on_failure": True,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(seconds=10),
}


@dag(
    start_date=pendulum.datetime(2023, 2, 14, tz="UTC"),
    schedule="21 9 * * *",
    default_args=default_args,
    catchup=False,
    max_active_tasks=4,
    tags=["PRO", "cq9", "tracker"],
)
def bet_win_statistics():
    """
    ### Transform bet/win statistics
    """

    @task()
    def bet_distribution(
        data_interval_end: pendulum_datetime = pendulum.now(),
    ):
        to_time = pendulum.datetime(
            data_interval_end.year, data_interval_end.month, data_interval_end.day
        )
        from_time = to_time.add(days=-1)
        # startDate, ownerID, parentID, gameCode, bet, rounds, bets, wins
        with MongoHook(conn_id="mongo_read") as mongo_hook:
            mongo_cnx = mongo_hook.get_conn()
            bet_distris = gamedetail.get_bet_distribution(mongo_cnx, from_time, to_time)

        if not bet_distris:
            logger.error("Get Nothing from bet distribution.")

        with mysql_cursor(mysql_conn_id="mysql_master_read") as cursor:
            gid_finder = game.code2id(cursor)
            pid_finder = agent.ssid2id(cursor)
        logger.info(f"Bet distribution amount:{len(bet_distris)}.")

        values = list()
        for bet_distri in bet_distris:
            # date, oid, pid, gid, bet, rounds, bets, wins
            values.append(
                (
                    bet_distri.get("startDate"),
                    pid_finder.get(bet_distri.get("ownerID"), ""),
                    pid_finder.get(bet_distri.get("parentID"), ""),
                    gid_finder.get(str(bet_distri.get("gameCode", "0")), 0),
                    bet_distri.get("bet"),
                    bet_distri.get("rounds"),
                    bet_distri.get("bets"),
                    bet_distri.get("wins"),
                )
            )
        with mysql_cursor(mysql_conn_id="mysql_master_write") as cursor:
            insert_bet_distribution(cursor, values=values)

    @task()
    def win_multiple_stats(
        data_interval_end: pendulum_datetime = pendulum.now(),
    ):

        to_time = pendulum.datetime(
            data_interval_end.year, data_interval_end.month, data_interval_end.day
        )
        from_time = to_time.add(days=-1)
        # startDate, ownerID, parentID, gameCode, mulRange, rounds, bets, wins
        with MongoHook(conn_id="mongo_read") as mongo_hook:
            mongo_cnx = mongo_hook.get_conn()
            win_stats = gamedetail.get_win_multiple_stat(mongo_cnx, from_time, to_time)

        if not win_stats:
            logger.error("Get Nothing from win multiple stats.")

        with mysql_cursor(mysql_conn_id="mysql_master_read") as cursor:
            gid_finder = game.code2id(cursor)
            pid_finder = agent.ssid2id(cursor)
        logger.info(f"Win mutiple stats amount:{len(win_stats)}.")

        values = list()
        for win_stat in win_stats:
            # date, oid, pid, gid, mulRange, rounds, bets, wins
            values.append(
                (
                    win_stat.get("startDate"),
                    pid_finder.get(win_stat.get("ownerID"), ""),
                    pid_finder.get(win_stat.get("parentID"), ""),
                    gid_finder.get(str(win_stat.get("gameCode", "0")), 0),
                    win_stat.get("mulRange"),
                    win_stat.get("playerCount"),
                    win_stat.get("rounds"),
                    win_stat.get("bets"),
                    win_stat.get("wins"),
                )
            )
        with mysql_cursor(mysql_conn_id="mysql_master_write") as cursor:
            insert_win_multiple_stats(cursor, values=values)

    bet_distribution() >> win_multiple_stats()  # type: ignore


bet_win_statistics_dag = bet_win_statistics()
