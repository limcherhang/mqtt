import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from datetime import datetime
import logging
from itertools import groupby

from airflow.decorators import task
from utils.connection.mysql import mysql_cursor
from utils import tools
from airflow.models import Variable

from analysis.crud import summary, grade_resources, grade_results, game

logger = logging.getLogger("airflow.task")


@task()
def collect_interval_summary(data_interval_end: pendulum_datetime = pendulum.now()):
    """
    First step: get basic summary for resources
    """

    _CFG = Variable.get("GRADING", deserialize_json=True)
    to_time = data_interval_end.format("YYYY-MM-DD")
    _GRADING_CFG = _CFG.get("GAME_GRADING", {})
    CHECK_DAY_INTERVAL = _GRADING_CFG.get("CHECK_DAY_INTERVAL", 7)
    from_time = data_interval_end.add(days=-1 * CHECK_DAY_INTERVAL).format("YYYY-MM-DD")

    with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
        currencys = summary.get_currency_grade_game(cursor, from_time, to_time)
        games = game.get_online_gid(cursor)

    for (display_currency, query_currency) in currencys:
        log_label = display_currency + str(games)
        logger.info(f"Start collect interval summary \n{log_label}")
        with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
            _summary = summary.get_with_games(
                cursor,
                from_time,
                to_time,
                query_currency,
                [str(gid) for gid in games],
            )

        if not _summary:
            logger.error(f"Empty {log_label} collect interval summary")
            continue

        with mysql_cursor(mysql_conn_id="mysql_master_write") as cursor:
            grade_resources.insert_game_summary(
                cursor,
                rows=[_info + (display_currency,) for _info in _summary],
            )
        logger.info(f"Finish collect interval summary")


@task()
def collect_duration_n_one_shot_info(
    data_interval_end: pendulum_datetime = pendulum.now(),
):
    """
    Second step: grab duration info, and get one shot info base on each game's basic summary
    """

    _CFG = Variable.get("GRADING", deserialize_json=True)
    to_time = data_interval_end.format("YYYY-MM-DD")
    _GRADING_CFG = _CFG.get("GAME_GRADING", {})
    CHECK_DAY_INTERVAL = _GRADING_CFG.get("CHECK_DAY_INTERVAL", 7)
    from_time = data_interval_end.add(days=-1 * CHECK_DAY_INTERVAL).format("YYYY-MM-DD")

    with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
        currencys = summary.get_currency_grade_game(cursor, from_time, to_time)
        games = game.get_online_gid(cursor)
    for (display_currency, query_currency) in currencys:
        log_label = display_currency + str(games)
        logger.info(f"Start collect duration/one-shot \n{log_label}")

        with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
            player_infos = summary.get_duration_n_play_times_with_games(
                cursor,
                from_time,
                to_time,
                query_currency,
                [str(gid) for gid in games],
            )
        if not player_infos:
            logger.warning(
                f"Grading game from {from_time} to {to_time} not have any duration or one-shot infos"
            )
            return

        def key_func(_info: summary.GameUserDurationNTimes):
            return str(_info.date) + ":" + str(_info.gid)

        # for duration
        games_durations = []
        # groupby assumes that the elements in the same group appear consecutively
        for key_str, infos in groupby(sorted(player_infos, key=key_func), key=key_func):
            infos = list(infos)
            logger.debug(key_str + "<> " + str(infos[:5]))
            player_count = len(infos)
            total_duration = sum([info.duration / info.times for info in infos])
            key = tuple(i for i in key_str.split(":"))
            key += (total_duration / player_count,)
            games_durations.append(key)

        logger.info(f"Grading game resource duration(top10): {games_durations[:10]}")
        if games_durations:
            with mysql_cursor(mysql_conn_id="mysql_master_write") as cursor:
                grade_resources.insert_game_duration(
                    cursor,
                    rows=[_info + (display_currency,) for _info in games_durations],
                )

        # for one-shot info. should base on game-(uid, gid)
        games_one_shot = []
        query_limit_num = 1000
        one_shots = [_info for _info in player_infos if _info.times == 1]
        for key_str, infos in groupby(sorted(one_shots, key=key_func), key=key_func):
            infos = list(infos)
            key = tuple(i for i in key_str.split(":"))
            _bets = 0
            for i in range(0, len(infos), query_limit_num):
                with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
                    _bet_infos = summary.get_users_bet_with_games(
                        cursor,
                        from_time,
                        to_time,
                        [str(u.uid) for u in one_shots[i : i + query_limit_num]],
                        int(key[1]),
                    )
                if not _bet_infos:
                    continue
                _bets += _bet_infos[0].bets if _bet_infos[0].bets else 0
            key += (len(infos), _bets, display_currency)
            games_one_shot.append(key)

        logger.info(f"Grading game resource one-shots(top10): {one_shots[:10]}")
        if games_one_shot:
            with mysql_cursor(mysql_conn_id="mysql_master_write") as cursor:
                grade_resources.insert_game_one_shots(cursor, rows=games_one_shot)
        logger.info("Finish collect duration/one-shot")


@task()
def collect_vip(
    data_interval_end: pendulum_datetime = pendulum.now(),
):
    """
    Third step: find vips situation under each game.
    """

    _CFG = Variable.get("GRADING", deserialize_json=True)
    to_time = data_interval_end.format("YYYY-MM-DD")
    _GRADING_CFG = _CFG.get("GAME_GRADING", {})
    CHECK_DAY_INTERVAL = _GRADING_CFG.get("CHECK_DAY_INTERVAL", 7)
    from_time = data_interval_end.add(days=-1 * CHECK_DAY_INTERVAL).format("YYYY-MM-DD")
    VIP_BET_THRESHOLD = _GRADING_CFG.get("VIP_BET_THRESHOLD", 10_000)

    with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
        currencys = summary.get_currency_grade_game(cursor, from_time, to_time)
        games = game.get_online_gid(cursor)
    for (display_currency, query_currency) in currencys:
        log_label = display_currency + str(games)
        logger.info(f"Start collect vip \n{log_label}")

        with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
            game_vip_infos = summary.get_vip_info_with_games(
                cursor,
                from_time,
                to_time,
                VIP_BET_THRESHOLD,
                query_currency,
                [str(gid) for gid in games],
            )

        logger.info(f"Grading game resource vip(top10): {game_vip_infos[:10]}")
        if game_vip_infos:
            with mysql_cursor(mysql_conn_id="mysql_master_write") as cursor:
                grade_resources.insert_game_vip(
                    cursor,
                    rows=[tuple(i) + (display_currency,) for i in game_vip_infos],
                )
        logger.info("Finish collect vip")


@task()
def give_grade(
    data_interval_end: pendulum_datetime = pendulum.now(),
):
    """
    Final step: grading each game by resources.
    """

    _CFG = Variable.get("GRADING", deserialize_json=True)
    _GRADING_CFG = _CFG.get("GAME_GRADING", {})
    GRADE_CORRESPOND_SIZE = _GRADING_CFG.get("GRADE_CORRESPOND_SIZE", 12)
    CHECK_DAY_INTERVAL = _GRADING_CFG.get("CHECK_DAY_INTERVAL", 7)
    GRADE_INTERVAL = _GRADING_CFG.get("GRADE_INTERVAL", [])

    to_time = pendulum.datetime(
        data_interval_end.year, data_interval_end.month, data_interval_end.day
    )
    from_time = to_time.add(
        days=-1 * (CHECK_DAY_INTERVAL * (GRADE_CORRESPOND_SIZE + 1))
    )
    grade_time = to_time.add(days=-1 * CHECK_DAY_INTERVAL)
    compare_time = to_time.add(days=-2 * CHECK_DAY_INTERVAL)

    import pandas as pd
    import numpy as np

    with mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor:
        currencys = summary.get_currency_grade_game(
            cursor,
            from_time.format("YYYY-MM-DD"),
            to_time.format("YYYY-MM-DD"),
        )
    for (display_currency, query_currency) in currencys:
        logger.info(f"Start graging game on {display_currency}")
        try:
            with mysql_cursor(mysql_conn_id="mysql_master_read") as cursor:
                resources = grade_resources.get_game_info_by_currency(
                    cursor,
                    from_time.format("YYYY-MM-DD"),
                    to_time.format("YYYY-MM-DD"),
                    query_currency,
                )
            if not resources:
                logger.info(
                    f"Get nothing from game resources from {from_time} to {to_time} with {display_currency}"
                )
                continue

            # preparing for grading
            resources_df = pd.DataFrame(
                resources,
                columns=[
                    "date",
                    "gid",
                    "bets",
                    "avgBetByRound",
                    "players",
                    "oneShotBetsRatio",
                    "avgDuration",
                    "vipPlayersRatio",
                    "onlinetime",
                ],
            )
            logger.debug("------game grade resources------")
            logger.debug(resources_df.head(10))

            resources_df.bets = pd.to_numeric(resources_df.bets)
            resources_df.avgBetByRound = pd.to_numeric(resources_df.avgBetByRound)
            resources_df.oneShotBetsRatio = pd.to_numeric(resources_df.oneShotBetsRatio)
            resources_df.avgDuration = pd.to_numeric(resources_df.avgDuration)
            resources_df.vipPlayersRatio = pd.to_numeric(resources_df.vipPlayersRatio)
            resources_df.date = pd.to_datetime(resources_df.date)
            resources_df.onlinetime = pd.to_datetime(resources_df.onlinetime)
            index_res_df = resources_df.set_index(["gid", "date"])

            grade_cols = [
                "bets",
                "avgBetByRound",
                "players",
                "oneShotBetsRatio",
                "avgDuration",
                "vipPlayersRatio",
            ]
            grade_result_df = pd.DataFrame(
                index=resources_df.gid.unique(),
                data=0,
                dtype="int8",
                columns=grade_cols,
            )
            grade_result_df = grade_result_df.join(resources_df.groupby("gid").agg({"onlinetime": "first"}))  # type: ignore
            logger.info("Complete preparing game grade")

            # calculating growth point
            index_grade_time = datetime(
                grade_time.year, grade_time.month, grade_time.day
            )
            index_compare_time = datetime(
                compare_time.year, compare_time.month, compare_time.day
            )
            for col in grade_cols:
                for gid in grade_result_df.index:
                    if col != "oneShotBetsRatio":
                        if index_res_df[col].get(
                            (gid, index_grade_time), 0
                        ) > index_res_df[col].get((gid, index_compare_time), 0):
                            grade_result_df.at[gid, col] = 1
                        elif index_res_df[col].get(
                            (gid, index_grade_time), 0
                        ) < index_res_df[col].get((gid, index_compare_time), 0):
                            grade_result_df.at[gid, col] = -1
                    else:
                        if index_res_df[col].get(
                            (gid, index_grade_time), 0
                        ) > index_res_df[col].get((gid, index_compare_time), 0):
                            grade_result_df.at[gid, col] = -1
                        elif index_res_df[col].get(
                            (gid, index_grade_time), 0
                        ) < index_res_df[col].get((gid, index_compare_time), 0):
                            grade_result_df.at[gid, col] = 1
            logger.debug("------game growth point------")
            logger.debug(grade_result_df.head(10))
            logger.info("complete game growth point")

            # calaulating growth point
            np.seterr(
                divide="ignore", invalid="ignore"
            )  # Ignore: divide by zero, and invalid nan
            for gid in grade_result_df.index:
                res_df = resources_df.query(f"gid == {gid}")

                the_onlinetime = grade_result_df.at[gid, "onlinetime"]
                default_size = (
                    datetime(grade_time.year, grade_time.month, grade_time.day)
                    - the_onlinetime
                ).days // CHECK_DAY_INTERVAL
                # only calculate owner whose number of data have at least half of compare size
                if default_size < (GRADE_CORRESPOND_SIZE // 2):
                    continue

                for col in grade_cols:

                    # fill the missing value as 0. dep_% as dependency_%
                    dep_arr = res_df[
                        res_df.date
                        <= datetime(
                            compare_time.year, compare_time.month, compare_time.day
                        )
                    ][col].values
                    dep_count = len(dep_arr)
                    if default_size > GRADE_CORRESPOND_SIZE:
                        while dep_count < GRADE_CORRESPOND_SIZE:
                            dep_arr = np.append(dep_arr, 0)
                            dep_count += 1
                    else:
                        while dep_count < default_size:
                            dep_arr = np.append(dep_arr, 0)
                            dep_count += 1

                    # remove the maximum and minimum
                    cleared_len = len(
                        dep_arr[
                            (dep_arr != np.max(dep_arr)) & (dep_arr != np.min(dep_arr))
                        ]
                    )
                    if cleared_len >= (GRADE_CORRESPOND_SIZE // 2):
                        dep_arr = dep_arr[
                            (dep_arr != np.max(dep_arr)) & (dep_arr != np.min(dep_arr))
                        ]

                    # Calculating the grade level
                    dep_avg = dep_arr.mean()
                    dep_std = dep_arr.std(ddof=1)
                    grade_dep = (
                        index_res_df[col].get((gid, index_grade_time), 0) - dep_avg
                    ) / dep_std
                    if np.isnan(grade_dep):
                        grade_dep = 0

                    # Giving fluctuate grade to result
                    if col != "oneShotBetsRatio":
                        fluctuate_lvl = tools.get_level(grade_dep, GRADE_INTERVAL)
                        grade_result_df.at[gid, col] += int(fluctuate_lvl)
                    else:
                        fluctuate_lvl = tools.get_level(
                            grade_dep, GRADE_INTERVAL, directly=False
                        )
                        grade_result_df.at[gid, col] += int(fluctuate_lvl)
            logger.debug("------owner growth point + fluctuate point------")
            logger.debug(grade_result_df.head(10))
            logger.info("complete owner fluctuate point")

            # store grades
            grade_result_df.drop(columns=["onlinetime"], inplace=True)
            grade_result_df.reset_index(inplace=True)
            grade_result_df.columns = pd.Index(["gid"] + grade_cols)
            grade_result_df["date"] = grade_time.strftime("%Y-%m-%d")

            insert_rows = list()
            for i in grade_result_df.index:
                insert_rows.append(
                    (
                        grade_result_df.at[i, "date"],
                        int(grade_result_df.at[i, "gid"]),
                        int(grade_result_df.at[i, "bets"]),
                        int(grade_result_df.at[i, "avgBetByRound"]),
                        int(grade_result_df.at[i, "players"]),
                        int(grade_result_df.at[i, "oneShotBetsRatio"]),
                        int(grade_result_df.at[i, "avgDuration"]),
                        int(grade_result_df.at[i, "vipPlayersRatio"]),
                        display_currency,
                    )
                )
            with mysql_cursor(mysql_conn_id="mysql_master_write") as cursor:
                grade_results.store_games(cursor, insert_rows)
            logger.info(f"Insert {display_currency} into game_grade_resources success!")
        except:
            logger.exception(f"Error {display_currency} game_grade_resources!")
