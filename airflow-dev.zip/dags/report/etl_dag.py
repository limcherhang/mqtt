import pendulum
from pendulum.datetime import DateTime as pendulum_datetime
from datetime import timedelta
import logging

from airflow.decorators import dag, task

# from airflow.utils.trigger_rule import TriggerRule
from airflow.providers.mongo.hooks.mongo import MongoHook
from airflow.models import Variable
from utils.connection.mysql import mysql_cursor

from report.crud.mongo import order
from report.crud.mysql import parent

logger = logging.getLogger("airflow.task")

default_args = {
    "depends_on_past": False,
    "email": ["rmpeter0474@adcrow.tech"],
    "email_on_failure": True,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
}


@dag(
    start_date=pendulum.today("UTC").add(days=-1),
    schedule="1 * * * *",
    default_args=default_args,
    catchup=False,
    max_active_tasks=4,
    tags=["PRO", "qt"],
)
def report_etl():
    """
    ### Report ETL
    """

    @task()
    def collect_playtime_n_rounds(
        data_interval_start: pendulum_datetime = pendulum.now(),
    ):
        """
        Collecting playtime and rounds
        """

        _CFG = Variable.get("REPORT", deserialize_json=True)
        insert_date = pendulum.datetime(
            data_interval_start.year,
            data_interval_start.month,
            data_interval_start.day,
            data_interval_start.hour,
            tz=data_interval_start.tz,
        )
        with (
            mysql_cursor(mysql_conn_id="mysql_slave_read") as cursor,
            MongoHook(conn_id="mongo_read") as mongo_hook,
        ):
            mongo_cnx = mongo_hook.get_conn()
            all_parents = parent.get_not_test_parents(cursor)
            _unique_playing_parents = order.get_interval_unique_parents(
                mongo_cnx,
                insert_date,
                insert_date.add(hours=1),
                use_createtime=_CFG.get("USE_CREATETIME", False),
            )
            _unique_lotto_playing_parents = order.get_interval_unique_parents(
                mongo_cnx,
                insert_date,
                insert_date.add(hours=1),
                is_lotto=True,
                use_createtime=_CFG.get("USE_CREATETIME", False),
            )
            unique_playing_parents = set(_unique_playing_parents).union(
                set(_unique_lotto_playing_parents)
            )
        query_parents = unique_playing_parents.intersection(set(all_parents))
        logger.info(
            f"Start collecting from {len(query_parents)} parents on {insert_date}."
        )
