from pendulum.datetime import DateTime as pendulum_datetime
import logging

logger = logging.getLogger("airflow.task")


def collect_playtime_n_round_by_parent(insert_date: pendulum_datetime, pssid: str):
    pass
