import logging
from typing import List
from bson.objectid import ObjectId
from pendulum.datetime import DateTime as pendulum_datetime
from pymongo import MongoClient

logger = logging.getLogger("airflow.task")


def get_interval_orders_4report(
    mongo_cnx: MongoClient,
    start_time: pendulum_datetime,
    end_time: pendulum_datetime,
    parentid: str,
    is_lotto: bool = False,
    use_createtime: bool = False,
) -> List[dict]:
    """
    The data sources for operation report on:
    mobile rounds and playtime by parents and games.
    """
    start_id = ObjectId.from_datetime(start_time)
    end_id = ObjectId.from_datetime(end_time)

    if use_createtime:
        pipeline = [
            {
                "$match": {
                    "createtime": {"$gte": start_time, "$lt": end_time},
                    "parentid": parentid,
                }
            },
            {
                "$project": {
                    "_id": 0,
                    "ownerid": 1,
                    "gamecode": 1,
                    "parentid": 1,
                    "platform": 1,
                    "roundid": 1,
                    "playerid": 1,
                    "gametoken": 1,
                    "eventlist": 1,
                }
            },
        ]
    else:
        pipeline = [
            {
                "$match": {
                    "_id": {"$gte": start_id, "$lt": end_id},
                    "parentid": parentid,
                }
            },
            {
                "$project": {
                    "_id": 0,
                    "ownerid": 1,
                    "gamecode": 1,
                    "parentid": 1,
                    "platform": 1,
                    "roundid": 1,
                    "playerid": 1,
                    "gametoken": 1,
                    "eventlist": 1,
                }
            },
        ]

    if is_lotto:
        _result = list(
            mongo_cnx.order.orderlotto.aggregate(pipeline, allowDiskUse=True)  # type: ignore
        )
        logger.info(f"Get report hour lotto-orders from {start_time} SUCCESS!")
    else:
        _result = list(mongo_cnx.order.order.aggregate(pipeline, allowDiskUse=True))  # type: ignore
        logger.info(f"Get report hour orders from {start_time} SUCCESS!")

    return _result


def get_interval_unique_parents(
    mongo_cnx: MongoClient,
    start_time: pendulum_datetime,
    end_time: pendulum_datetime,
    is_lotto: bool = False,
    use_createtime: bool = False,
) -> List[str]:
    """
    Get interval distinct playing parents for query orders.
    """
    start_id = ObjectId.from_datetime(start_time)
    end_id = ObjectId.from_datetime(end_time)

    field = "parentid"
    if use_createtime:
        query = {"createtime": {"$gte": start_time, "$lt": end_time}}
    else:
        query = {"_id": {"$gte": start_id, "$lt": end_id}}

    if is_lotto:
        _result = list(mongo_cnx.order.orderlotto.distinct(field, query))  # type: ignore
    else:
        _result = list(mongo_cnx.order.order.distinct(field, query))  # type: ignore
    logger.debug(f"Get distinct parents from {start_time} SUCCESS!")

    return _result
