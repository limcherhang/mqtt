import logging
from typing import List
from mysql.connector.cursor import MySQLCursor

logger = logging.getLogger("airflow.task")


def get_not_test_parents(cursor: MySQLCursor) -> List[str]:

    stmt = "SELECT plp.ssid "
    stmt += "FROM cypress.parent_list plp "
    stmt += "WHERE plp.istestss = 0 AND EXISTS "
    stmt += "  (SELECT 1 FROM cypress.parent_list plo "
    stmt += "   WHERE plo.istestss = 0 AND plo.id != 6423 AND plp.owner = plo.ssid);"

    cursor.execute(stmt)
    result = [pssid for (pssid,) in list(cursor)]

    return result
