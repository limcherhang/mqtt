from typing import List, Optional
import tenacity
from datetime import datetime, timedelta
import pytz

from utils.connection.team_plus import RMBotTeamPlusMessageHook
from utils.connection.telegram import TelegramMessageHook


def get_level(value: float, levels: List[dict], directly: bool = True) -> int:
    import numpy as np

    if directly:
        for level in levels:
            range_from = level.get("RANGE_FROM", -np.inf)
            range_to = level.get("RANGE_TO", np.inf)
            if range_from < value <= range_to:
                return level.get("LEVEL", 0)
            elif value == -np.inf:
                return -3
            else:
                continue
    else:
        for level in levels:
            range_from = level.get("RANGE_FROM", -np.inf)
            range_to = level.get("RANGE_TO", np.inf)
            if range_from < value <= range_to:
                return -1 * (level.get("LEVEL", 0))
            elif value == -np.inf:
                return 3
            else:
                continue
    return 0


def telegram_message(
    telegram_chats: List[int], message: str, retry_args: Optional[dict] = None
):
    """
    Given a list of Telegram chats to send messages.
    """
    hook = TelegramMessageHook()
    if not retry_args:
        retry_args = dict(
            wait=tenacity.wait_exponential(),  # pyright: ignore [reportPrivateImportUsage]
            stop=tenacity.stop_after_attempt(  # pyright: ignore [reportPrivateImportUsage]
                10
            ),
            retry=tenacity.retry_if_exception_type(  # pyright: ignore [reportPrivateImportUsage]
                Exception
            ),
        )
    for chat_id in telegram_chats:
        hook.run_with_advanced_retry(
            chat_id=chat_id,
            message=message,
            _retry_args=retry_args,
        )


def get_excel_timestamp(date_time: datetime) -> float:
    time_diff = timedelta(days=0)
    if date_time.tzinfo:
        init_date = datetime(1899, 12, 30, tzinfo=pytz.UTC)
        if date_time.tzinfo == pytz.UTC:
            time_diff = date_time - init_date
        else:
            time_diff = date_time - init_date + date_time.utcoffset()
    else:
        init_date = datetime(1899, 12, 30)
        time_diff = date_time - init_date

    return float(time_diff.days) + (float(time_diff.seconds) / 86400)


def teamplus_message(
    teamplus_chats: List[int], message: str, retry_args: Optional[dict] = None
):
    """
    Given a list of Team+ chats to send messages.
    """
    hook = RMBotTeamPlusMessageHook()
    if not retry_args:
        retry_args = dict(
            wait=tenacity.wait_exponential(),  # pyright: ignore [reportPrivateImportUsage]
            stop=tenacity.stop_after_attempt(  # pyright: ignore [reportPrivateImportUsage]
                10
            ),
            retry=tenacity.retry_if_exception_type(  # pyright: ignore [reportPrivateImportUsage]
                Exception
            ),
        )
    for chat in teamplus_chats:
        hook.run_with_advanced_retry(
            chat=chat,
            message=message,
            _retry_args=retry_args,
        )


def trans_num_type_prevent_none(trans2type, num):
    if num is None:
        return 0
    else:
        return trans2type(num)
