# Airflow util

### Connection
* Google  
  This use the Google OAuth token(not the airflow origin way), but use the same filelds.  
  Use the `google_oauth_json_generator.json` to get the JSON-format token.  
  Store credential(JSON) in keyfile_dict.  
  Store token(JSON) in key_path.  
* TeamPlus  
  The API-token was stored in file, so just setup the connection.  
* DA-API  
  Store the API-token in the **password** field, and remember to specify the expire time in description.   

