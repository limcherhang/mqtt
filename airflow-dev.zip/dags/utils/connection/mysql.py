from contextlib import contextmanager
from typing import Optional, Generator
from mysql.connector.cursor import MySQLCursor
from mysql.connector.connection import MySQLConnection

from airflow.providers.mysql.hooks.mysql import MySqlHook


@contextmanager
def mysql_cursor(
    mysql_conn_id: str, autocommit: bool = True, time_zone: Optional[str] = None
) -> Generator[MySQLCursor, None, None]:
    mysql_cnx: MySQLConnection = MySqlHook(mysql_conn_id=mysql_conn_id).get_conn()  # type: ignore
    mysql_cnx.autocommit = autocommit
    cursor: MySQLCursor = mysql_cnx.cursor()  # type: ignore
    if not time_zone:
        cursor.execute("SET time_zone = '+00:00'")
    else:
        cursor.execute(f"SET time_zone = '{time_zone}'")

    try:
        yield cursor
    finally:
        cursor.close()
        mysql_cnx.close()
