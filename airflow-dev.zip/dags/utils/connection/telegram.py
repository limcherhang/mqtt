from airflow.providers.http.hooks.http import HttpHook

import requests
from requests_toolbelt.adapters.socket_options import TCPKeepAliveAdapter
from typing import Any, Optional, Dict


class TelegramMessageHook(HttpHook):
    def __init__(
        self,
        tcp_keep_alive: bool = True,
        tcp_keep_alive_idle: int = 120,
        tcp_keep_alive_count: int = 20,
        tcp_keep_alive_interval: int = 30,
    ) -> None:
        super().__init__(
            "POST",
            "telegram_send",
            None,
            tcp_keep_alive,
            tcp_keep_alive_idle,
            tcp_keep_alive_count,
            tcp_keep_alive_interval,
        )

    def run(
        self,
        chat_id: int,
        message: str,
        headers: Optional[Dict[str, Any]] = None,
        **request_kwargs: Any
    ) -> Any:
        session = self.get_conn(headers)

        url = self.url_from_endpoint("/sendMessage")

        if self.tcp_keep_alive:
            keep_alive_adapter = TCPKeepAliveAdapter(
                idle=self.keep_alive_idle,
                count=self.keep_alive_count,
                interval=self.keep_alive_interval,
            )
            session.mount(url, keep_alive_adapter)

        data = {
            "chat_id": chat_id,
            "text": message,
        }
        # POST only
        req = requests.Request(
            self.method, url, data=data, headers=headers, **request_kwargs
        )

        prepped_request = session.prepare_request(req)
        self.log.info("Sending '%s' to url: %s", self.method, url)
        return self.run_and_check(session, prepped_request, {"timeout": 10})

    def get_conn(self, headers: Optional[Dict[Any, Any]] = None) -> requests.Session:
        """
        Returns http session for use with requests

        :param headers: additional headers to be passed through as a dictionary
        """
        session = requests.Session()

        if self.http_conn_id:
            conn = self.get_connection(self.http_conn_id)
            self.base_url = conn.schema + "://" + conn.host + conn.password

        if headers:
            session.headers.update(headers)

        return session
