import json
from airflow.exceptions import AirflowException
from airflow.providers.http.hooks.http import HttpHook

import requests
import tenacity
from requests_toolbelt.adapters.socket_options import TCPKeepAliveAdapter
from typing import Any, Optional, Dict

JSONstr = str


class DAAPIHook(HttpHook):
    """
    DA-API hook. Store api-key to password
    """

    def __init__(
        self,
        tcp_keep_alive: bool = True,
        tcp_keep_alive_idle: int = 120,
        tcp_keep_alive_count: int = 20,
        tcp_keep_alive_interval: int = 30,
    ) -> None:
        super().__init__(
            "POST",
            "da_api",
            None,
            tcp_keep_alive,
            tcp_keep_alive_idle,
            tcp_keep_alive_count,
            tcp_keep_alive_interval,
        )

    # headers may be passed through directly or in the "extra" field in the connection
    # definition
    def get_conn(self, headers: Optional[Dict[Any, Any]] = None) -> requests.Session:
        """
        Returns http session for use with requests

        :param headers: additional headers to be passed through as a dictionary
        """
        session = requests.Session()
        conn = self.get_connection(self.http_conn_id)

        if conn.host and "://" in conn.host:
            self.base_url = conn.host  # pyright: ignore
        else:
            # schema defaults to HTTP
            schema = conn.schema if conn.schema else "http"
            host = conn.host if conn.host else ""
            self.base_url = schema + "://" + host  # pyright: ignore

        if conn.port:
            self.base_url = self.base_url + ":" + str(conn.port)  # pyright: ignore
        if conn.login:
            session.auth = self.auth_type(conn.login, conn.password)
        if conn.extra:
            try:
                session.headers.update(conn.extra_dejson)
            except TypeError:
                self.log.warning("Connection to %s has invalid extra field.", conn.host)
        auth_header = {"Authorization": f"Bearer {conn.password}"}
        session.headers.update(auth_header)

        if headers:
            session.headers.update(headers)

        return session

    def run_with_advanced_retry(
        self, func: str, _retry_args: Dict[Any, Any], *args: Any, **kwargs: Any
    ) -> requests.Response:
        """
        Runs Hook.run() with a Tenacity decorator attached to it. This is useful for
        connectors which might be disturbed by intermittent issues and should not
        instantly fail.

        :param func: The functions of DAAPI.
        :param _retry_args: Arguments which define the retry behaviour.
            See Tenacity documentation at https://github.com/jd/tenacity


        .. code-block:: python

            hook = HttpHook(http_conn_id="my_conn", method="GET")
            retry_args = dict(
                wait=tenacity.wait_exponential(),
                stop=tenacity.stop_after_attempt(10),
                retry=tenacity.retry_if_exception_type(Exception),
            )
            hook.run_with_advanced_retry(endpoint="v1/test", _retry_args=retry_args)

        """
        self._retry_obj = tenacity.Retrying(**_retry_args)
        _function = getattr(self, func, None)
        if not _function:
            raise AirflowException(f"DAAPI do not have function: {func}!")

        return self._retry_obj(_function, *args, **kwargs)

    def broadcast_alert(
        self,
        data: dict,
        is_test: bool = False,
        request_kwargs: Dict[Any, Any] = {},
        timeout: int = 10,
        check_response: bool = True,
    ) -> requests.Response:
        session = self.get_conn()

        url = self.url_from_endpoint("alert/broadcast")
        data.update({"is_test": is_test})

        if self.tcp_keep_alive:
            keep_alive_adapter = TCPKeepAliveAdapter(
                idle=self.keep_alive_idle,
                count=self.keep_alive_count,
                interval=self.keep_alive_interval,
            )
            session.mount(url, keep_alive_adapter)

        # GET only
        req = requests.Request(
            "POST",
            url,
            data=json.dumps(data),
            params={"is_test": is_test},
            **request_kwargs,
        )

        prepped_request = session.prepare_request(req)
        self.log.info("DA-API broadcast_alert url: %s, is_test: %s", url, is_test)
        self.log.debug(f"Data: {data}")
        return self.run_and_check(
            session,
            prepped_request,
            {"timeout": timeout, "check_response": check_response},
        )

    def notify_performance_alarm(
        self,
        alarm: dict,
        action: str = "SalesAlarm",
        topic: str = "performance-alarm",
        request_kwargs: Dict[Any, Any] = {},
        timeout: int = 10,
        check_response: bool = True,
    ) -> requests.Response:
        session = self.get_conn()

        url = self.url_from_endpoint("notify/sales/alarm")
        params = {"topic": topic}
        params.update(alarm)
        params["action"] = action

        if self.tcp_keep_alive:
            keep_alive_adapter = TCPKeepAliveAdapter(
                idle=self.keep_alive_idle,
                count=self.keep_alive_count,
                interval=self.keep_alive_interval,
            )
            session.mount(url, keep_alive_adapter)

        # GET only
        req = requests.Request("GET", url, params=params, **request_kwargs)

        prepped_request = session.prepare_request(req)
        self.log.info("DA-API notify_performance_alarm url: %s, topic: %s", url, topic)
        self.log.debug(f"Alarm: {alarm}")
        return self.run_and_check(
            session,
            prepped_request,
            {"timeout": timeout, "check_response": check_response},
        )

    def maintain_performance_size(
        self,
        request_kwargs: Dict[Any, Any] = {},
        timeout: int = 10,
        check_response: bool = True,
    ) -> requests.Response:
        session = self.get_conn()

        url = self.url_from_endpoint("inquiry/sales/maintain/size")

        if self.tcp_keep_alive:
            keep_alive_adapter = TCPKeepAliveAdapter(
                idle=self.keep_alive_idle,
                count=self.keep_alive_count,
                interval=self.keep_alive_interval,
            )
            session.mount(url, keep_alive_adapter)

        # GET only
        req = requests.Request("GET", url, **request_kwargs)

        prepped_request = session.prepare_request(req)
        self.log.info("DA-API maintaim_performance_size url: %s", url)
        return self.run_and_check(
            session,
            prepped_request,
            {"timeout": timeout, "check_response": check_response},
        )

    def notify_performance_update(
        self,
        topic: str = "performance",
        request_kwargs: Dict[Any, Any] = {},
        timeout: int = 10,
        check_response: bool = True,
    ) -> requests.Response:
        session = self.get_conn()

        url = self.url_from_endpoint("notify/performance")
        params = {"topic": topic}

        if self.tcp_keep_alive:
            keep_alive_adapter = TCPKeepAliveAdapter(
                idle=self.keep_alive_idle,
                count=self.keep_alive_count,
                interval=self.keep_alive_interval,
            )
            session.mount(url, keep_alive_adapter)

        # GET only
        req = requests.Request("GET", url, params=params, **request_kwargs)

        prepped_request = session.prepare_request(req)
        self.log.info("DA-API notify_performance_update url: %s, topic: %s", url, topic)
        return self.run_and_check(
            session,
            prepped_request,
            {"timeout": timeout, "check_response": check_response},
        )

    def update_specify_project(
        self,
        key: JSONstr,
        performance_in: JSONstr,
        request_kwargs: Dict[Any, Any] = {},
        timeout: int = 10,
        check_response: bool = True,
    ) -> requests.Response:
        session = self.get_conn()

        url = self.url_from_endpoint("inquiry/sales/specify/project")
        dataJSON = '{{"key": {key}, "performance_in": {performance_in}}}'
        dataJSON = dataJSON.format(key=key, performance_in=performance_in)

        if self.tcp_keep_alive:
            keep_alive_adapter = TCPKeepAliveAdapter(
                idle=self.keep_alive_idle,
                count=self.keep_alive_count,
                interval=self.keep_alive_interval,
            )
            session.mount(url, keep_alive_adapter)

        req = requests.Request("PUT", url, data=dataJSON, **request_kwargs)

        prepped_request = session.prepare_request(req)
        self.log.info("DA-API update_specify_project url: %s", url)
        self.log.debug("DA-API update_specify_project data: %s", dataJSON)
        return self.run_and_check(
            session,
            prepped_request,
            {"timeout": timeout, "check_response": check_response},
        )

    def update_specify_game(
        self,
        key: JSONstr,
        performance_in: JSONstr,
        request_kwargs: Dict[Any, Any] = {},
        timeout: int = 10,
        check_response: bool = True,
    ) -> requests.Response:
        session = self.get_conn()

        url = self.url_from_endpoint("inquiry/sales/specify/game")
        dataJSON = '{{"key": {key}, "performance_in": {performance_in}}}'
        dataJSON = dataJSON.format(key=key, performance_in=performance_in)

        if self.tcp_keep_alive:
            keep_alive_adapter = TCPKeepAliveAdapter(
                idle=self.keep_alive_idle,
                count=self.keep_alive_count,
                interval=self.keep_alive_interval,
            )
            session.mount(url, keep_alive_adapter)

        req = requests.Request("PUT", url, data=dataJSON, **request_kwargs)

        prepped_request = session.prepare_request(req)
        self.log.info("DA-API update_specify_game url: %s", url)
        self.log.debug("DA-API update_specify_game data: %s", dataJSON)
        return self.run_and_check(
            session,
            prepped_request,
            {"timeout": timeout, "check_response": check_response},
        )

    def get_specify_project(
        self,
        params: dict,
        request_kwargs: Dict[Any, Any] = {},
        timeout: int = 10,
        check_response: bool = True,
    ) -> requests.Response:
        session = self.get_conn()

        url = self.url_from_endpoint("inquiry/sales/specify/project")

        if self.tcp_keep_alive:
            keep_alive_adapter = TCPKeepAliveAdapter(
                idle=self.keep_alive_idle,
                count=self.keep_alive_count,
                interval=self.keep_alive_interval,
            )
            session.mount(url, keep_alive_adapter)

        req = requests.Request("GET", url, params=params, **request_kwargs)

        prepped_request = session.prepare_request(req)
        self.log.info("DA-API get_specify_project url: %s", url)
        self.log.debug("DA-API get_specify_project params: %s", params)
        return self.run_and_check(
            session,
            prepped_request,
            {"timeout": timeout, "check_response": check_response},
        )

    def add_specify_project(
        self,
        performance_in: JSONstr,
        request_kwargs: Dict[Any, Any] = {},
        timeout: int = 10,
        check_response: bool = True,
    ) -> requests.Response:
        session = self.get_conn()

        url = self.url_from_endpoint("inquiry/sales/specify/project")

        if self.tcp_keep_alive:
            keep_alive_adapter = TCPKeepAliveAdapter(
                idle=self.keep_alive_idle,
                count=self.keep_alive_count,
                interval=self.keep_alive_interval,
            )
            session.mount(url, keep_alive_adapter)

        # POST only
        req = requests.Request(self.method, url, data=performance_in, **request_kwargs)

        prepped_request = session.prepare_request(req)
        self.log.info("DA-API add_specify_project url: %s", url)
        self.log.debug("DA-API add_specify_project data: %s", performance_in)
        return self.run_and_check(
            session,
            prepped_request,
            {"timeout": timeout, "check_response": check_response},
        )

    def add_specify_game(
        self,
        performance_in: JSONstr,
        request_kwargs: Dict[Any, Any] = {},
        timeout: int = 10,
        check_response: bool = True,
    ) -> requests.Response:
        session = self.get_conn()

        url = self.url_from_endpoint("inquiry/sales/specify/game")

        if self.tcp_keep_alive:
            keep_alive_adapter = TCPKeepAliveAdapter(
                idle=self.keep_alive_idle,
                count=self.keep_alive_count,
                interval=self.keep_alive_interval,
            )
            session.mount(url, keep_alive_adapter)

        # POST only
        req = requests.Request(self.method, url, data=performance_in, **request_kwargs)

        prepped_request = session.prepare_request(req)
        self.log.info("DA-API add_specify_game url: %s", url)
        self.log.debug("DA-API add_specify_game data: %s", performance_in)
        return self.run_and_check(
            session,
            prepped_request,
            {"timeout": timeout, "check_response": check_response},
        )

    def add_performance_by_top_bet(
        self,
        performance_in: JSONstr,
        request_kwargs: Dict[Any, Any] = {},
        timeout: int = 10,
        check_response: bool = True,
    ) -> requests.Response:
        session = self.get_conn()

        url = self.url_from_endpoint("inquiry/sales/performance/top/bet")

        if self.tcp_keep_alive:
            keep_alive_adapter = TCPKeepAliveAdapter(
                idle=self.keep_alive_idle,
                count=self.keep_alive_count,
                interval=self.keep_alive_interval,
            )
            session.mount(url, keep_alive_adapter)

        # POST only
        req = requests.Request(self.method, url, data=performance_in, **request_kwargs)

        prepped_request = session.prepare_request(req)
        self.log.info("DA-API add_performance_by_top_bet url: %s", url)
        self.log.debug("DA-API add_performance_by_top_bet data: %s", performance_in)
        return self.run_and_check(
            session,
            prepped_request,
            {"timeout": timeout, "check_response": check_response},
        )

    def add_performance_by_currency(
        self,
        performance_in: JSONstr,
        request_kwargs: Dict[Any, Any] = {},
        timeout: int = 10,
        check_response: bool = True,
    ) -> requests.Response:
        session = self.get_conn()

        url = self.url_from_endpoint("inquiry/sales/performance/currency")

        if self.tcp_keep_alive:
            keep_alive_adapter = TCPKeepAliveAdapter(
                idle=self.keep_alive_idle,
                count=self.keep_alive_count,
                interval=self.keep_alive_interval,
            )
            session.mount(url, keep_alive_adapter)

        # POST only
        req = requests.Request(self.method, url, data=performance_in, **request_kwargs)

        prepped_request = session.prepare_request(req)
        self.log.info("DA-API add_performance_by_currency url: %s", url)
        self.log.debug("DA-API add_performance_by_currency data: %s", performance_in)
        return self.run_and_check(
            session,
            prepped_request,
            {"timeout": timeout, "check_response": check_response},
        )

    def add_performance_by_gametype(
        self,
        performance_in: JSONstr,
        request_kwargs: Dict[Any, Any] = {},
        timeout: int = 10,
        check_response: bool = True,
    ) -> requests.Response:
        session = self.get_conn()

        url = self.url_from_endpoint("inquiry/sales/performance/gametype")

        if self.tcp_keep_alive:
            keep_alive_adapter = TCPKeepAliveAdapter(
                idle=self.keep_alive_idle,
                count=self.keep_alive_count,
                interval=self.keep_alive_interval,
            )
            session.mount(url, keep_alive_adapter)

        # POST only
        req = requests.Request(self.method, url, data=performance_in, **request_kwargs)

        prepped_request = session.prepare_request(req)
        self.log.info("DA-API add_performance_by_gametype url: %s", url)
        self.log.debug("DA-API add_performance_by_gametype data: %s", performance_in)
        return self.run_and_check(
            session,
            prepped_request,
            {"timeout": timeout, "check_response": check_response},
        )

    def add_performance(
        self,
        performance_in: JSONstr,
        request_kwargs: Dict[Any, Any] = {},
        timeout: int = 10,
        check_response: bool = True,
    ) -> requests.Response:
        session = self.get_conn()

        url = self.url_from_endpoint("inquiry/sales/performance")

        if self.tcp_keep_alive:
            keep_alive_adapter = TCPKeepAliveAdapter(
                idle=self.keep_alive_idle,
                count=self.keep_alive_count,
                interval=self.keep_alive_interval,
            )
            session.mount(url, keep_alive_adapter)

        # POST only
        req = requests.Request(self.method, url, data=performance_in, **request_kwargs)

        prepped_request = session.prepare_request(req)
        self.log.info("DA-API add_performance url: %s", url)
        self.log.debug("DA-API add_performance data: %s", performance_in)
        return self.run_and_check(
            session,
            prepped_request,
            {"timeout": timeout, "check_response": check_response},
        )

    def check_response(self, response: requests.Response) -> None:
        """
        Checks the status code and raise an AirflowException exception on non 2XX or 3XX
        status codes

        :param response: A requests response object
        """
        try:
            response.raise_for_status()
        except requests.exceptions.HTTPError:
            self.log.error("HTTP error: %s", response.reason)
            self.log.error(response.text)
            raise AirflowException(
                str(response.status_code) + ":" + response.reason + "\n" + response.text
            )

    def run_and_check(
        self,
        session: requests.Session,
        prepped_request: requests.PreparedRequest,
        extra_options: Dict[Any, Any],
    ) -> Any:
        """
        Grabs extra options like timeout and actually runs the request,
        checking for the result

        :param session: the session to be used to execute the request
        :param prepped_request: the prepared request generated in run()
        :param extra_options: additional options to be used when executing the request
            i.e. ``{'check_response': False}`` to avoid checking raising exceptions on non 2XX
            or 3XX status codes
        """
        extra_options = extra_options or {}

        settings = session.merge_environment_settings(
            prepped_request.url,
            proxies=extra_options.get("proxies", {}),
            stream=extra_options.get("stream", False),
            verify=extra_options.get("verify"),
            cert=extra_options.get("cert"),
        )

        # Send the request.
        send_kwargs: Dict[str, Any] = {
            "timeout": extra_options.get("timeout"),
            "allow_redirects": extra_options.get("allow_redirects", True),
        }
        send_kwargs.update(settings)

        try:
            response = session.send(prepped_request, **send_kwargs)
            self.log.info(
                f"Response<{str(response.status_code)}>:"
                + response.reason
                + "\n"
                + response.text
            )

            if extra_options.get("check_response", True):
                self.check_response(response)
            return response

        except requests.exceptions.ConnectionError as ex:
            if extra_options.get("check_response", True):
                self.log.warning("%s Tenacity will retry to execute the operation", ex)
            raise ex
