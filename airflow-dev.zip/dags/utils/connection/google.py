from airflow.providers.google.suite.hooks.drive import GoogleDriveHook
from airflow.providers.google.suite.hooks.sheets import GSheetsHook
from airflow.exceptions import AirflowException
from airflow.utils.session import create_session

from googleapiclient.http import MediaFileUpload
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from typing import Optional, Any
import json
from datetime import datetime


class OauthGSheetHook(GSheetsHook):
    def get_conn(self) -> Any:
        """
        Retrieves the connection to Google Drive.

        :return: Google Drive services object.
        """
        if not self._conn:
            oauth_authorized = self._authorize()
            self._conn = build(
                "sheets",
                self.api_version,
                credentials=oauth_authorized,
                cache_discovery=False,
            )
        return self._conn

    def _authorize(self) -> Credentials:
        """
        Autherized by OAuth2 client secret and store the token.
        """
        cred_info: Optional[str] = self._get_field("key_path", None)
        if not cred_info:
            raise AirflowException(
                f"Google conn_id={self.gcp_conn_id} do not have keyfile JSON(token)"
            )
        cred_info_dict = json.loads(cred_info)
        cred_info_dict["expiry"] = datetime.fromisoformat(
            cred_info_dict["expiry"].replace("Z", "")
        )
        cred = Credentials(**cred_info_dict)
        if not cred or not cred.valid:
            if cred and cred.expired and cred.refresh_token:
                cred.refresh(Request())
            else:
                secret_info: Optional[str] = self._get_field("keyfile_dict", None)
                if not secret_info:
                    raise AirflowException(
                        f"Google conn_id={self.gcp_conn_id} do not have keyfile path(secret)"
                    )
                flow = InstalledAppFlow.from_client_config(
                    json.loads(secret_info), scopes=self.scopes
                )
                cred = flow.run_local_server(port=0)
            # Save the credentials for the next run
            cred_info_long_f = "extra__google_cloud_platform__key_path"
            self.extras[cred_info_long_f] = cred.to_json()
            self_cnx = self.get_connection(self.gcp_conn_id)
            self_cnx.set_extra(json.dumps(self.extras))

            with create_session() as session:
                session.add(self_cnx)

        return cred


class OauthGoogleDriveHook(GoogleDriveHook):
    def upload_file(
        self,
        local_location: str,
        remote_location: str,
        google_drive_parentid: Optional[str] = None,
        local_mimetype: Optional[str] = None,
        remote_mimetype: Optional[str] = None,
        chunk_size: int = 100 * 1024 * 1024,
        resumable: bool = False,
    ) -> str:
        """
        Uploads a file that is available locally to a Google Drive service.

        :param local_location: The path where the file is available.
        :param remote_location: The path where the file will be send
        :param google_drive_parentid: The google drive folder's id.
        :param local_mimetype: The mimetype of local file; ex, text/csv, application/vnd.ms-excel
        :param remote_mimetype: The mimetype of remote google file; ex, application/vnd.google-apps.spreadsheet
        :param chunk_size: File will be uploaded in chunks of this many bytes. Only
            used if resumable=True. Pass in a value of -1 if the file is to be
            uploaded as a single chunk. Note that Google App Engine has a 5MB limit
            on request size, so you should never set your chunk size larger than 5MB,
            or to -1.
        :param resumable: True if this is a resumable upload. False means upload
            in a single request.
        :return: File ID
        :rtype: str
        """
        service = self.get_conn()
        directory_path, _, file_name = remote_location.rpartition("/")
        if google_drive_parentid:
            remote_location = f"folders/{google_drive_parentid}"
            parent = google_drive_parentid
        elif directory_path:
            parent = self._ensure_folders_exists(directory_path)
        else:
            parent = "root"

        file_metadata = {"name": file_name, "parents": [parent]}
        if remote_mimetype:
            file_metadata["mimeType"] = remote_mimetype
        media = MediaFileUpload(
            local_location, chunksize=chunk_size, resumable=resumable
        )
        if local_mimetype:
            media = MediaFileUpload(
                local_location,
                chunksize=chunk_size,
                resumable=resumable,
                mimetype=local_mimetype,
            )

        file = (
            service.files()
            .create(
                body=file_metadata,
                media_body=media,
                fields="id",
                supportsAllDrives=True,
            )
            .execute(num_retries=self.num_retries)
        )
        self.log.info(
            "File %s uploaded to gdrive://%s.", local_location, remote_location
        )
        return file.get("id")

    def _ensure_folders_exists(self, path: str) -> str:
        service = self.get_conn()
        current_parent = "root"
        folders = path.split("/")
        depth = 0
        # First tries to enter directories
        for current_folder in folders:
            self.log.debug(
                "Looking for %s directory with %s parent",
                current_folder,
                current_parent,
            )
            conditions = [
                "mimeType = 'application/vnd.google-apps.folder'",
                f"name='{current_folder}'",
                f"'{current_parent}' in parents",
                "trashed=false",
            ]
            result = (
                service.files()
                .list(
                    q=" and ".join(conditions),
                    spaces="drive",
                    fields="files(id, name)",
                    supportsAllDrives=True,
                )
                .execute(num_retries=self.num_retries)
            )
            files = result.get("files", [])
            if not files:
                self.log.info("Not found %s directory", current_folder)
                # If the directory does not exist, break loops
                break
            depth += 1
            current_parent = files[0].get("id")

        # Check if there are directories to process
        if depth != len(folders):
            # Create missing directories
            for current_folder in folders[depth:]:
                file_metadata = {
                    "name": current_folder,
                    "mimeType": "application/vnd.google-apps.folder",
                    "parents": [current_parent],
                }
                file = (
                    service.files()
                    .create(body=file_metadata, fields="id", supportsAllDrives=True)
                    .execute(num_retries=self.num_retries)
                )
                self.log.info("Created %s directory", current_folder)

                current_parent = file.get("id")
        # Return the ID of the last directory
        return current_parent

    def get_conn(self) -> Any:
        """
        Retrieves the connection to Google Drive.

        :return: Google Drive services object.
        """
        if not self._conn:
            oauth_authorized = self._authorize()
            self._conn = build(
                "drive",
                self.api_version,
                credentials=oauth_authorized,
                cache_discovery=False,
            )
        return self._conn

    def _authorize(self) -> Credentials:
        """
        Autherized by OAuth2 client secret and store the token.
        """
        cred_info: Optional[str] = self._get_field("key_path", None)
        if not cred_info:
            raise AirflowException(
                f"Google conn_id={self.gcp_conn_id} do not have keyfile JSON"
            )
        cred_info_dict = json.loads(cred_info)
        cred_info_dict["expiry"] = datetime.fromisoformat(
            cred_info_dict["expiry"].replace("Z", "")
        )
        cred = Credentials(**cred_info_dict)
        if not cred or not cred.valid:
            if cred and cred.expired and cred.refresh_token:
                cred.refresh(Request())
            else:
                secret_info: Optional[str] = self._get_field("keyfile_dict", None)
                if not secret_info:
                    raise AirflowException(
                        f"Google conn_id={self.gcp_conn_id} do not have keyfile path(secret)"
                    )
                flow = InstalledAppFlow.from_client_config(
                    json.loads(secret_info), scopes=self.scopes
                )
                cred = flow.run_local_server(port=0)
            # Save the credentials for the next run
            cred_info_long_f = "extra__google_cloud_platform__key_path"
            self.extras[cred_info_long_f] = cred.to_json()
            self_cnx = self.get_connection(self.gcp_conn_id)
            self_cnx.set_extra(json.dumps(self.extras))

            with create_session() as session:
                session.add(self_cnx)

        return cred
