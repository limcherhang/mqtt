"""
This file is to create the Google OAuth token.
1. Put the credential in the same directory of this file
2. Execute this file
3. Get the JSON-format token
"""
import os
from pathlib import Path

from google_auth_oauthlib.flow import InstalledAppFlow

DEFAULT_NAME: str = "client_secret.json"
scopes = ["spreadsheets", "drive", "drive.file"]
SCOPES = [f"https://www.googleapis.com/auth/{scope}" for scope in scopes]

if __name__ == "__main__":
    secret_path = os.path.join(Path.cwd(), Path(DEFAULT_NAME))
    # Use local-broweser for authentication
    flow = InstalledAppFlow.from_client_secrets_file(secret_path, SCOPES)
    _cred = flow.run_local_server(port=0)

    print(_cred.to_json())
