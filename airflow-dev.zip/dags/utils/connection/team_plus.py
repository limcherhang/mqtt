from airflow.providers.http.hooks.http import HttpHook

import requests
from requests_toolbelt.adapters.socket_options import TCPKeepAliveAdapter
from typing import Any, Optional, Dict


class RMBotTeamPlusMessageHook(HttpHook):
    def __init__(
        self,
        tcp_keep_alive: bool = True,
        tcp_keep_alive_idle: int = 120,
        tcp_keep_alive_count: int = 20,
        tcp_keep_alive_interval: int = 30,
    ) -> None:
        super().__init__(
            "POST",
            "team_plus",
            None,
            tcp_keep_alive,
            tcp_keep_alive_idle,
            tcp_keep_alive_count,
            tcp_keep_alive_interval,
        )

    def run(
        self,
        chat: int,
        message: str,
        headers: Optional[Dict[str, Any]] = None,
        **request_kwargs: Any
    ) -> Any:
        session = self.get_conn(headers)

        url = self.url_from_endpoint("API/IMService.ashx")

        if self.tcp_keep_alive:
            keep_alive_adapter = TCPKeepAliveAdapter(
                idle=self.keep_alive_idle,
                count=self.keep_alive_count,
                interval=self.keep_alive_interval,
            )
            session.mount(url, keep_alive_adapter)

        params = {"ask": "sendChatMessage"}
        data = {
            "account": "rmrobot",
            "api_key": "497D809D-9A9E-0E18-B4A8-83876C86DB27",
            "chat_sn": chat,
            "content_type": 1,
            "msg_content": message,
        }
        # POST only
        req = requests.Request(
            self.method,
            url,
            data=data,
            headers=headers,
            params=params,
            **request_kwargs
        )

        prepped_request = session.prepare_request(req)
        self.log.info("Sending '%s' to url: %s", self.method, url)
        return self.run_and_check(session, prepped_request, {"timeout": 10})
