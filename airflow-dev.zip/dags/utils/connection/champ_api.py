from airflow.exceptions import AirflowException
from airflow.providers.http.hooks.http import HttpHook

import requests
import tenacity
from requests_toolbelt.adapters.socket_options import TCPKeepAliveAdapter
from typing import Any, Optional, Dict

JSONstr = str


class ChampAPIHook(HttpHook):
    """
    Champ-API hook. Store account-password in login-password
    """

    def __init__(
        self,
        tcp_keep_alive: bool = True,
        tcp_keep_alive_idle: int = 120,
        tcp_keep_alive_count: int = 20,
        tcp_keep_alive_interval: int = 30,
    ) -> None:
        super().__init__(
            "GET",
            "champ_api",
            None,
            tcp_keep_alive,
            tcp_keep_alive_idle,
            tcp_keep_alive_count,
            tcp_keep_alive_interval,
        )

    # headers may be passed through directly or in the "extra" field in the connection
    # definition
    def get_conn(self, headers: Optional[Dict[Any, Any]] = None) -> requests.Session:
        """
        Returns http session for use with requests

        :param headers: additional headers to be passed through as a dictionary
        """
        session = requests.Session()
        conn = self.get_connection(self.http_conn_id)

        if conn.host and "://" in conn.host:
            self.base_url = conn.host  # pyright: ignore
        else:
            # schema defaults to HTTP
            schema = conn.schema if conn.schema else "http"
            host = conn.host if conn.host else ""
            self.base_url = schema + "://" + host  # pyright: ignore

        if conn.port:
            self.base_url = self.base_url + ":" + str(conn.port)  # pyright: ignore
        if conn.extra:
            try:
                session.headers.update(conn.extra_dejson)
            except TypeError:
                self.log.warning("Connection to %s has invalid extra field.", conn.host)
        auth_header = {"account": conn.login, "password": conn.password}
        session.headers.update(auth_header)

        if headers:
            session.headers.update(headers)

        return session

    def run_with_advanced_retry(
        self, func: str, _retry_args: Dict[Any, Any], *args: Any, **kwargs: Any
    ) -> requests.Response:
        """
        Runs Hook.run() with a Tenacity decorator attached to it. This is useful for
        connectors which might be disturbed by intermittent issues and should not
        instantly fail.

        :param func: The functions of DAAPI.
        :param _retry_args: Arguments which define the retry behaviour.
            See Tenacity documentation at https://github.com/jd/tenacity


        .. code-block:: python

            hook = HttpHook(http_conn_id="my_conn", method="GET")
            retry_args = dict(
                wait=tenacity.wait_exponential(),
                stop=tenacity.stop_after_attempt(10),
                retry=tenacity.retry_if_exception_type(Exception),
            )
            hook.run_with_advanced_retry(endpoint="v1/test", _retry_args=retry_args)

        """
        self._retry_obj = tenacity.Retrying(**_retry_args)
        _function = getattr(self, func, None)
        if not _function:
            raise AirflowException(f"ChampAPI do not have function: {func}!")

        return self._retry_obj(_function, *args, **kwargs)

    def run_and_check(
        self,
        session: requests.Session,
        prepped_request: requests.PreparedRequest,
        extra_options: Dict[Any, Any],
    ) -> Any:
        """
        Grabs extra options like timeout and actually runs the request,
        checking for the result

        :param session: the session to be used to execute the request
        :param prepped_request: the prepared request generated in run()
        :param extra_options: additional options to be used when executing the request
            i.e. ``{'check_response': False}`` to avoid checking raising exceptions on non 2XX
            or 3XX status codes
        """
        extra_options = extra_options or {}

        settings = session.merge_environment_settings(
            prepped_request.url,
            proxies=extra_options.get("proxies", {}),
            stream=extra_options.get("stream", False),
            verify=extra_options.get("verify"),
            cert=extra_options.get("cert"),
        )

        # Send the request.
        send_kwargs: Dict[str, Any] = {
            "timeout": extra_options.get("timeout"),
            "allow_redirects": extra_options.get("allow_redirects", True),
        }
        send_kwargs.update(settings)

        try:
            response = session.send(prepped_request, **send_kwargs)
            self.log.info(
                f"Response<{str(response.status_code)}>:"
                + response.reason
                + "\n"
                + response.text
            )

            if extra_options.get("check_response", True):
                self.check_response(response)
            return response

        except requests.exceptions.ConnectionError as ex:
            if extra_options.get("check_response", True):
                self.log.warning("%s Tenacity will retry to execute the operation", ex)
            raise ex

    def get_member_bet(
        self,
        check_date: str,
        request_kwargs: Dict[Any, Any] = {},
        timeout: int = 30,
        check_response: bool = True,
    ) -> requests.Response:
        """
        API analysisMemberBet
        check_date: YYYYMMDD
        """
        session = self.get_conn()

        url = self.url_from_endpoint("analysis/member/bets")
        params = {"date": check_date}

        if self.tcp_keep_alive:
            keep_alive_adapter = TCPKeepAliveAdapter(
                idle=self.keep_alive_idle,
                count=self.keep_alive_count,
                interval=self.keep_alive_interval,
            )
            session.mount(url, keep_alive_adapter)

        # GET only
        req = requests.Request("GET", url, params=params, **request_kwargs)

        prepped_request = session.prepare_request(req)
        self.log.info("Champ-API get_member_bet url: %s, date: %s", url, check_date)
        return self.run_and_check(
            session,
            prepped_request,
            {"timeout": timeout, "check_response": check_response},
        )
