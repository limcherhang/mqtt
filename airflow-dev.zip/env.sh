# Set these env vars so that:
# 1. airflow commands locally are run against the SIT mysql
# 2. `airflow test` runs properly

AIRFLOW_HOME=$(pwd)

# Note: env vars set here should be printed out in the print statement below
export AIRFLOW_HOME
export AIRFLOW__CORE__EXECUTOR=CeleryExecutor
export AIRFLOW__CORE__SQL_ALCHEMY_CONN=mysql+mysqlconnector://IMairflow_keep:p3Jx6in7P_ship@10.30.2.144:3306/airflow_db 
export AIRFLOW__DATABASE__SQL_ALCHEMY_CONN=$AIRFLOW__CORE__SQL_ALCHEMY_CONN
export AIRFLOW__CELERY__RESULT_BACKEND=db+mysql+mysqlconnector://IMairflow_keep:p3Jx6in7P_ship@10.30.2.144:3306/airflow_db 
export AIRFLOW__CELERY__BROKER_URL=redis://:redis4SYS@10.30.3.52:3002/0
export AIRFLOW__CORE__FERNET_KEY=''
export AIRFLOW__CORE__DAGS_FOLDER=$AIRFLOW_HOME/dags
export AIRFLOW__CORE__PLUGINS_FOLDER=$AIRFLOW_HOME/plugins
export AIRFLOW__CORE__BASE_LOG_FOLDER=/tmp/log_airflow
export AIRFLOW__CORE__DAG_PROCESSOR_MANAGER_LOG_LOCATION=/tmp/log_airflow/dag_processor_manager/dag_processor_manager.log
export AIRFLOW__SCHEDULER__CHILD_PROCESS_LOG_DIRECTORY=/tmp/log_airflow/scheduler
export AIRFLOW__CORE__LOAD_EXAMPLES='false'
export AIRFLOW__CORE__UNIT_TEST_MODE='true'

echo \
"===================================================================
Environment Variables for Local Execution (vs execution in Docker)
===================================================================
AIRFLOW_HOME=$AIRFLOW_HOME
AIRFLOW__CORE__EXECUTOR=$AIRFLOW__CORE__EXECUTOR
AIRFLOW__CORE__SQL_ALCHEMY_CONN=$AIRFLOW__CORE__SQL_ALCHEMY_CONN
AIRFLOW__CORE__FERNET_KEY=$AIRFLOW__CORE__FERNET_KEY
AIRFLOW__CORE__DAGS_FOLDER=$AIRFLOW__CORE__DAGS_FOLDER
AIRFLOW__CORE__PLUGINS_FOLDER=$AIRFLOW__CORE__PLUGINS_FOLDER
AIRFLOW__CORE__BASE_LOG_FOLDER=$AIRFLOW__CORE__BASE_LOG_FOLDER
AIRFLOW__CORE__DAG_PROCESSOR_MANAGER_LOG_LOCATION=$AIRFLOW__CORE__DAG_PROCESSOR_MANAGER_LOG_LOCATION
AIRFLOW__SCHEDULER__CHILD_PROCESS_LOG_DIRECTORY=$AIRFLOW__SCHEDULER__CHILD_PROCESS_LOG_DIRECTORY
"
